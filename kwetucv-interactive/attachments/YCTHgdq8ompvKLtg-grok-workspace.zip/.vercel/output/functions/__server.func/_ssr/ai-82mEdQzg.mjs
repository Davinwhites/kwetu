import { n as TSS_SERVER_FUNCTION, t as createServerFn } from "./ssr.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/ai-82mEdQzg.js
var createServerRpc = (serverFnMeta, splitImportFn) => {
	const url = "/_serverFn/" + serverFnMeta.id;
	return Object.assign(splitImportFn, {
		url,
		serverFnMeta,
		[TSS_SERVER_FUNCTION]: true
	});
};
function compactCv(cv) {
	return {
		name: cv.personal.fullName,
		title: cv.personal.title,
		summary: cv.summary.slice(0, 800),
		experience: cv.experience.slice(0, 5).map((e) => ({
			id: e.id,
			role: e.role,
			company: e.company,
			dates: `${e.start}–${e.current ? "now" : e.end}`,
			bullets: e.bullets.filter(Boolean).slice(0, 6)
		})),
		education: cv.education.slice(0, 3).map((e) => ({
			school: e.school,
			degree: `${e.degree} ${e.field}`.trim()
		})),
		skills: cv.skills.map((s) => `${s.category}: ${s.items}`).slice(0, 6),
		projects: cv.projects.slice(0, 3).map((p) => ({
			name: p.name,
			summary: p.summary,
			bullets: p.bullets.filter(Boolean).slice(0, 3)
		}))
	};
}
async function chat(system, user, maxTokens) {
	const apiKey = process.env.XAI_API_KEY;
	if (!apiKey) return {
		ok: false,
		error: "AI is not available in this environment"
	};
	const res = await fetch("https://api.x.ai/v1/chat/completions", {
		method: "POST",
		headers: {
			"Content-Type": "application/json",
			Authorization: `Bearer ${apiKey}`
		},
		body: JSON.stringify({
			model: "grok-4.5",
			temperature: .4,
			max_tokens: maxTokens,
			messages: [{
				role: "system",
				content: system
			}, {
				role: "user",
				content: user
			}]
		})
	});
	if (!res.ok) return {
		ok: false,
		error: `xAI API error ${res.status}`
	};
	const text = (await res.json()).choices?.[0]?.message?.content?.trim() ?? "";
	if (!text) return {
		ok: false,
		error: "Empty model response"
	};
	return {
		ok: true,
		text
	};
}
function extractJson(text) {
	const raw = (text.match(/```(?:json)?\s*([\s\S]*?)```/)?.[1] ?? text).trim();
	const start = raw.indexOf("{");
	const end = raw.lastIndexOf("}");
	if (start < 0 || end < start) throw new Error("No JSON object");
	return JSON.parse(raw.slice(start, end + 1));
}
var runCvAi_createServerFn_handler = createServerRpc({
	id: "1be6176a60b3d029b1ed2bec0355ddf85206076a341c5c4e83928505bba3c3c7",
	name: "runCvAi",
	filename: "src/lib/ai.ts"
}, (opts) => runCvAi.__executeServer(opts));
var runCvAi = createServerFn({ method: "POST" }).validator((input) => input).handler(runCvAi_createServerFn_handler, async ({ data }) => {
	if (data.task === "rewrite") {
		const text = data.text.trim().slice(0, 600);
		if (!text) return {
			ok: false,
			error: "Nothing to rewrite"
		};
		const job = data.job?.trim().slice(0, 800) ?? "";
		const result = await chat("You are a precise résumé editor. Rewrite one bullet or summary. Rules: start with a strong action verb; quantify only using numbers already present — never invent metrics; one or two sentences max; no first person; no quotes; return only the rewritten text.", [
			data.role ? `Role: ${data.role}` : "",
			data.company ? `Company: ${data.company}` : "",
			job ? `Target role notes: ${job}` : "",
			`Text:\n${text}`
		].filter(Boolean).join("\n"), 220);
		if (!result.ok) return result;
		return {
			ok: true,
			text: result.text.replace(/^["']|["']$/g, "")
		};
	}
	if (data.task === "review") {
		const job = data.job?.trim().slice(0, 1200) ?? "";
		const result = await chat("You are a hiring manager and ATS coach. Return JSON only: {\"score\":0-100,\"summary\":\"2 sentences\",\"issues\":[{\"severity\":\"high|med|low\",\"title\":\"short\",\"fix\":\"actionable\"}]} . Be specific to this CV. Max 6 issues. Never invent facts.", JSON.stringify({
			cv: compactCv(data.cv),
			job: job || void 0
		}), 900);
		if (!result.ok) return result;
		try {
			const parsed = extractJson(result.text);
			return {
				ok: true,
				review: {
					score: Math.max(0, Math.min(100, Number(parsed.score) || 0)),
					summary: String(parsed.summary ?? "").slice(0, 600),
					issues: Array.isArray(parsed.issues) ? parsed.issues.slice(0, 6).map((i) => ({
						severity: i.severity === "high" || i.severity === "low" ? i.severity : "med",
						title: String(i.title ?? "").slice(0, 80),
						fix: String(i.fix ?? "").slice(0, 240)
					})) : []
				}
			};
		} catch {
			return {
				ok: false,
				error: "Could not parse the review"
			};
		}
	}
	const job = data.job.trim().slice(0, 1400);
	if (!job) return {
		ok: false,
		error: "Paste a job description first"
	};
	const compact = compactCv(data.cv);
	const result = await chat("You retarget a CV toward a job without inventing experience. Return JSON only: {\"note\":\"1 sentence\",\"summary\":\"rewritten summary\",\"bullets\":[{\"id\":\"experience id\",\"index\":0,\"suggested\":\"bullet\"}]} . Only rewrite existing bullets (use their id and 0-based index). Max 8 bullets. Keep true facts.", JSON.stringify({
		cv: compact,
		job
	}), 1100);
	if (!result.ok) return result;
	try {
		const parsed = extractJson(result.text);
		return {
			ok: true,
			tailor: {
				note: String(parsed.note ?? "").slice(0, 280),
				summary: String(parsed.summary ?? "").slice(0, 700),
				bullets: Array.isArray(parsed.bullets) ? parsed.bullets.slice(0, 8).map((b) => ({
					id: String(b.id ?? ""),
					index: Number(b.index) || 0,
					suggested: String(b.suggested ?? "").slice(0, 280)
				})) : []
			}
		};
	} catch {
		return {
			ok: false,
			error: "Could not parse the tailor result"
		};
	}
});
//#endregion
export { runCvAi_createServerFn_handler };
