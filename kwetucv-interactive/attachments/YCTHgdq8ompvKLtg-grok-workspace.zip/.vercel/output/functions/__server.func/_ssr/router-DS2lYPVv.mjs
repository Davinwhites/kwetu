import { i as __toESM } from "../_runtime.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { f as createRouter, g as createRootRoute, h as createFileRoute, l as Scripts, m as lazyRouteComponent, p as Outlet, u as HeadContent, y as useRouter } from "../_libs/@tanstack/react-router+[...].mjs";
import { o as require_jsx_runtime } from "../_libs/@radix-ui/react-collection+[...].mjs";
import { n as TriangleAlert } from "../_libs/lucide-react.mjs";
import { a as union, i as string, n as number, r as object, t as literal } from "../_libs/zod.mjs";
import { n as create, t as persist } from "../_libs/zustand.mjs";
import { n as clsx } from "../_libs/class-variance-authority+clsx.mjs";
import { t as twMerge } from "../_libs/tailwind-merge.mjs";
import { t as Toaster } from "../_libs/sonner.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/router-DS2lYPVv.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var __defProp = Object.defineProperty;
var __exportAll = (all, no_symbols) => {
	let target = {};
	for (var name in all) __defProp(target, name, {
		get: all[name],
		enumerable: true
	});
	if (!no_symbols) __defProp(target, Symbol.toStringTag, { value: "Module" });
	return target;
};
var FALLBACK_MESSAGE = "An unexpected error occurred. Try reloading the page.";
function errorMessage(error) {
	if (error instanceof Error && error.message) return error.message;
	if (typeof error === "string" && error) return error;
	return FALLBACK_MESSAGE;
}
function AppErrorComponent({ error }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		className: "flex min-h-screen flex-col items-center justify-center gap-3 px-6 text-center bg-zinc-50 text-zinc-900 dark:bg-zinc-950 dark:text-zinc-50",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "text-red-500",
				"aria-hidden": "true",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TriangleAlert, {
					className: "size-10",
					strokeWidth: 2
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "text-lg font-semibold",
				children: "Something went wrong"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "max-w-md text-sm break-words text-zinc-500 dark:text-zinc-400",
				children: errorMessage(error)
			})
		]
	});
}
/**
* App-wide client provider mounted once near the root (in `src/routes/__root.tsx`):
*
*   <AuthProvider><Outlet /></AuthProvider>
*
* Better Auth's React client (`@/lib/auth/client`) needs NO context provider —
* its `useSession()` works standalone — so this is a passthrough today. It's
* kept as the single, stable mount point for any future client-side providers
* (e.g. a toast or theme provider) without churning the root shell.
*/
function AuthProvider({ children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(import_jsx_runtime.Fragment, { children });
}
var CONNECTOR_TOKEN_READY_EVENT = "grok:connector-token-ready";
function isGrokEmbedderOrigin(origin) {
	try {
		const url = new URL(origin);
		if (url.protocol !== "https:" && url.protocol !== "http:") return false;
		const host = url.hostname.toLowerCase();
		if (host === "grok.com" || host.endsWith(".grok.com")) return true;
		if (host === "localhost" || host === "127.0.0.1" || host === "[::1]") return true;
		return false;
	} catch {
		return false;
	}
}
function isSandboxPreviewGuestHost(hostname) {
	const host = hostname.toLowerCase();
	return host === "grok-sandbox.com" || host.endsWith(".grok-sandbox.com");
}
function isRemintPreviewPair(guestHost, parentHost) {
	const guest = guestHost.toLowerCase();
	const parent = parentHost.toLowerCase();
	const i = guest.indexOf(".preview.");
	if (i <= 0) return false;
	const label = guest.slice(0, i);
	const rest = guest.slice(i + 9);
	if (label.includes(".") || !rest.includes(".")) return false;
	return parent === rest || parent === `grok.${rest}`;
}
function resolveParentEmbedderOrigin(parentIsSelf, referrer, ancestorOrigin, guestHostname = "") {
	if (parentIsSelf) return null;
	for (const candidate of [referrer, ancestorOrigin ?? ""].filter(Boolean)) try {
		const url = new URL(candidate.includes("://") ? candidate : `https://${candidate}`);
		if (url.protocol !== "https:" && url.protocol !== "http:") continue;
		if (isGrokEmbedderOrigin(url.origin)) return url.origin;
		if (isSandboxPreviewGuestHost(guestHostname) || isRemintPreviewPair(guestHostname, url.hostname)) return url.origin;
	} catch {}
	return null;
}
/**
* Guest side of the grok-web ↔ sandbox preview postMessage bridge.
*
* Activates only when this page is framed by an allowlisted Grok embedder.
* Top-level runs (download/export, local `npm run dev`, deployed sites) noop.
*/
var PREVIEW_BRIDGE_CHANNEL = "grok-preview-bridge";
var EnvelopeSchema = object({
	channel: literal(PREVIEW_BRIDGE_CHANNEL),
	version: number().int().positive(),
	type: string().min(1)
});
var HelloSchema = EnvelopeSchema.extend({ type: literal("hello") });
var NavigateSchema = EnvelopeSchema.extend({
	type: literal("navigate"),
	path: string().min(1)
});
var HistorySchema = EnvelopeSchema.extend({
	type: literal("history"),
	delta: union([literal(-1), literal(1)])
});
var ConnectorTokenReadySchema = EnvelopeSchema.extend({ type: literal("connector-token-ready") });
function isSafeBridgePath(path) {
	if (!path.startsWith("/") || path.startsWith("//") || path.includes("\\")) return false;
	try {
		return new URL(path, "https://preview.invalid").origin === "https://preview.invalid";
	} catch {
		return false;
	}
}
/**
* Origin of the Grok embedder framing this page, or null when the page runs
* top-level (download/export, local `npm run dev`, deployed sites) or under a
* non-Grok parent. Client-only; null during SSR.
*/
function resolveCurrentEmbedderOrigin() {
	if (typeof window === "undefined") return null;
	const ancestorOrigin = typeof location.ancestorOrigins !== "undefined" && location.ancestorOrigins.length > 0 ? location.ancestorOrigins[0] : null;
	return resolveParentEmbedderOrigin(window.parent === window, document.referrer, ancestorOrigin, window.location.hostname);
}
/**
* Install host↔guest messaging. Returns a dispose function.
* Noops (returns a no-op dispose) when not embedded under a Grok parent.
*/
function installPreviewHostBridge(options = {}) {
	const parentOrigin = resolveCurrentEmbedderOrigin();
	if (parentOrigin === null) return () => {};
	const ROOT_STATE_KEY = "__grokPreviewBridgeRoot";
	const originalPushState = window.history.pushState.bind(window.history);
	const originalReplaceState = window.history.replaceState.bind(window.history);
	const isAtHistoryRoot = () => {
		const state = window.history.state;
		return Boolean(state && typeof state === "object" && state[ROOT_STATE_KEY] === true);
	};
	try {
		const current = window.history.state;
		if (!(current !== null && typeof current === "object" && Object.prototype.hasOwnProperty.call(current, ROOT_STATE_KEY))) {
			const isRoot = window.history.length <= 1;
			originalReplaceState(current && typeof current === "object" ? {
				...current,
				[ROOT_STATE_KEY]: isRoot
			} : { [ROOT_STATE_KEY]: isRoot }, "", window.location.href);
		}
	} catch {}
	const post = (message) => {
		window.parent.postMessage(message, parentOrigin);
	};
	const reportLocation = () => {
		post({
			channel: PREVIEW_BRIDGE_CHANNEL,
			version: 1,
			type: "location",
			path: window.location.pathname || "/",
			search: window.location.search,
			hash: window.location.hash
		});
	};
	const reportRoutes = () => {
		const paths = options.getRoutePaths?.() ?? [];
		post({
			channel: PREVIEW_BRIDGE_CHANNEL,
			version: 1,
			type: "routes",
			paths
		});
	};
	const defaultNavigate = (path) => {
		if (!isSafeBridgePath(path)) return;
		try {
			const url = new URL(path, window.location.origin);
			if (url.origin !== window.location.origin) return;
			const next = `${url.pathname}${url.search}${url.hash}`;
			window.history.pushState(window.history.state, "", next);
			window.dispatchEvent(new PopStateEvent("popstate", { state: window.history.state }));
		} catch {}
	};
	const navigate = (path) => {
		if (!isSafeBridgePath(path)) return;
		if (options.navigate) {
			options.navigate(path);
			return;
		}
		defaultNavigate(path);
	};
	const announce = () => {
		reportLocation();
		reportRoutes();
		post({
			channel: PREVIEW_BRIDGE_CHANNEL,
			version: 1,
			type: "ready"
		});
	};
	const onHello = (data) => {
		if (!HelloSchema.safeParse(data).success) return;
		announce();
	};
	const onNavigate = (data) => {
		const parsed = NavigateSchema.safeParse(data);
		if (!parsed.success) return;
		navigate(parsed.data.path);
		queueMicrotask(reportLocation);
	};
	const onHistory = (data) => {
		const parsed = HistorySchema.safeParse(data);
		if (!parsed.success) return;
		if (parsed.data.delta === -1 && isAtHistoryRoot()) return;
		window.history.go(parsed.data.delta);
	};
	const onConnectorTokenReady = (data) => {
		if (!ConnectorTokenReadySchema.safeParse(data).success) return;
		window.dispatchEvent(new Event(CONNECTOR_TOKEN_READY_EVENT));
	};
	const hostMessageHandlers = /* @__PURE__ */ new Map([
		["hello", onHello],
		["navigate", onNavigate],
		["history", onHistory],
		["connector-token-ready", onConnectorTokenReady]
	]);
	const onMessage = (event) => {
		if (event.source !== window.parent) return;
		if (event.origin !== parentOrigin) return;
		const envelope = EnvelopeSchema.safeParse(event.data);
		if (!envelope.success || envelope.data.version !== 1) return;
		hostMessageHandlers.get(envelope.data.type)?.(event.data);
	};
	const onPopState = () => {
		reportLocation();
	};
	const onHashChange = () => {
		reportLocation();
	};
	window.history.pushState = (data, unused, url) => {
		const next = data && typeof data === "object" ? {
			...data,
			[ROOT_STATE_KEY]: false
		} : data;
		originalPushState(next, unused, url);
		reportLocation();
	};
	window.history.replaceState = (data, unused, url) => {
		const next = isAtHistoryRoot() ? {
			...data && typeof data === "object" ? data : {},
			[ROOT_STATE_KEY]: true
		} : data;
		originalReplaceState(next, unused, url);
		reportLocation();
	};
	window.addEventListener("message", onMessage);
	window.addEventListener("popstate", onPopState);
	window.addEventListener("hashchange", onHashChange);
	announce();
	return () => {
		window.removeEventListener("message", onMessage);
		window.removeEventListener("popstate", onPopState);
		window.removeEventListener("hashchange", onHashChange);
		window.history.pushState = originalPushState;
		window.history.replaceState = originalReplaceState;
	};
}
/** Collect static path patterns from a TanStack route tree (best-effort). */
function collectRoutePathsFromTree(routeTree) {
	const paths = /* @__PURE__ */ new Set();
	const walk = (node) => {
		if (!node || typeof node !== "object") return;
		const record = node;
		const full = typeof record.fullPath === "string" ? record.fullPath : typeof record.path === "string" ? record.path : null;
		if (full !== null && full !== "") paths.add(full.startsWith("/") ? full : `/${full}`);
		else if (full === "") paths.add("/");
		const children = record.children;
		if (Array.isArray(children)) for (const child of children) walk(child);
		else if (children && typeof children === "object") for (const child of Object.values(children)) walk(child);
	};
	walk(routeTree);
	return [...paths];
}
/**
* Mount once in `__root.tsx` so the Grok preview chrome can drive navigation
* (and later receive registered routes). Noops when the app is not embedded.
*/
function PreviewHostBridge() {
	const router = useRouter();
	(0, import_react.useEffect)(() => {
		return installPreviewHostBridge({
			navigate: (path) => {
				router.history.push(path);
			},
			getRoutePaths: () => collectRoutePathsFromTree(router.routeTree)
		});
	}, [router]);
	return null;
}
function cn(...inputs) {
	return twMerge(clsx(inputs));
}
function uid() {
	if (typeof crypto !== "undefined" && "randomUUID" in crypto) return crypto.randomUUID();
	return `id_${Math.random().toString(36).slice(2, 11)}`;
}
function formatEdited(ts) {
	const delta = Date.now() - ts;
	const mins = Math.floor(delta / 6e4);
	if (mins < 1) return "Just now";
	if (mins < 60) return `${mins}m ago`;
	const hours = Math.floor(mins / 60);
	if (hours < 24) return `${hours}h ago`;
	const days = Math.floor(hours / 24);
	if (days < 14) return `${days}d ago`;
	return new Date(ts).toLocaleDateString(void 0, {
		month: "short",
		day: "numeric"
	});
}
var SAMPLE_CV = {
	id: "sample",
	name: "Leila Okonkwo — Staff Product Engineer",
	template: "editorial",
	updatedAt: Date.now(),
	personal: {
		fullName: "Leila Okonkwo",
		title: "Staff Product Engineer",
		email: "leila.okonkwo@pm.me",
		phone: "+254 711 482 190",
		location: "Nairobi · Remote",
		website: "leila.codes",
		linkedin: "linkedin.com/in/leilaokonkwo",
		github: "github.com/lokonkwo"
	},
	summary: "Staff product engineer who ships payment and logistics systems used by millions. Leads cross-functional squads from discovery through production, with a bias for measurable reliability, clear writing, and mentoring the next layer of staff talent.",
	experience: [
		{
			id: "exp-1",
			company: "Kibo Payments",
			role: "Staff Product Engineer",
			location: "Nairobi",
			start: "2022",
			end: "",
			current: true,
			bullets: [
				"Led a 9-person squad that rebuilt checkout, cutting failed payments 38% and lifting conversion 11% across 14 markets.",
				"Designed the merchant risk engine now scoring 4.2M transactions daily with p95 latency under 90ms.",
				"Wrote the incident review standard adopted company-wide; mean time to mitigate dropped from 3.4h to 48m in two quarters.",
				"Mentored four senior engineers to staff-track promotions; two now run their own product areas."
			]
		},
		{
			id: "exp-2",
			company: "Atlas Freight",
			role: "Senior Engineer",
			location: "London",
			start: "2019",
			end: "2022",
			current: false,
			bullets: [
				"Shipped a routing service that reduced empty miles 17% and saved $6.4M in annual carrier spend.",
				"Replaced a weekly ops spreadsheet with a live capacity board used by 120 dispatchers.",
				"Owned on-call for the tracking stack; drove a 99.95% monthly uptime after a year of 99.4%."
			]
		},
		{
			id: "exp-3",
			company: "Northwind Labs",
			role: "Product Engineer",
			location: "Lagos",
			start: "2016",
			end: "2019",
			current: false,
			bullets: ["Built the first self-serve onboarding for a B2B analytics product, shrinking time-to-value from 11 days to 9 hours.", "Partnered with design on a component library still in use across three product lines."]
		}
	],
	education: [{
		id: "edu-1",
		school: "University of Lagos",
		degree: "B.Sc.",
		field: "Computer Science",
		start: "2012",
		end: "2016",
		details: "First class · Systems & HCI"
	}],
	projects: [{
		id: "proj-1",
		name: "Ledgerlight",
		url: "ledgerlight.dev",
		summary: "Open-source reconciler for multi-currency ledgers.",
		bullets: ["Used by 800+ finance teams; 4.9k GitHub stars.", "Wrote the matching algorithm and the public audit trail format."]
	}],
	skills: [
		{
			id: "sk-1",
			category: "Build",
			items: "TypeScript, React, Node, Go, Postgres, Kafka"
		},
		{
			id: "sk-2",
			category: "Lead",
			items: "Staff coaching, incident command, product discovery, RFC writing"
		},
		{
			id: "sk-3",
			category: "Domain",
			items: "Payments, risk, logistics, multi-region systems"
		}
	],
	extras: [{
		id: "ex-1",
		label: "Languages",
		value: "English, Yoruba, French"
	}, {
		id: "ex-2",
		label: "Speaking",
		value: "QCon London 2025 · Strange Loop 2023"
	}]
};
function blankCv(partial) {
	return {
		id: partial?.id ?? uid(),
		name: partial?.name ?? "Untitled CV",
		template: partial?.template ?? "editorial",
		updatedAt: Date.now(),
		personal: {
			fullName: "",
			title: "",
			email: "",
			phone: "",
			location: "",
			website: "",
			linkedin: "",
			github: "",
			...partial?.personal
		},
		summary: partial?.summary ?? "",
		experience: partial?.experience ?? [{
			id: uid(),
			company: "",
			role: "",
			location: "",
			start: "",
			end: "",
			current: false,
			bullets: ["", ""]
		}],
		education: partial?.education ?? [{
			id: uid(),
			school: "",
			degree: "",
			field: "",
			start: "",
			end: "",
			details: ""
		}],
		projects: partial?.projects ?? [],
		skills: partial?.skills ?? [{
			id: uid(),
			category: "Core",
			items: ""
		}],
		extras: partial?.extras ?? []
	};
}
function cloneSample() {
	const raw = JSON.parse(JSON.stringify(SAMPLE_CV));
	raw.id = uid();
	raw.updatedAt = Date.now();
	return raw;
}
var useCvStore = create()(persist((set, get) => ({
	cvs: {},
	order: [],
	hydrated: false,
	setHydrated: () => set({ hydrated: true }),
	create: (seed = "blank") => {
		const cv = seed === "sample" ? cloneSample() : blankCv();
		set((s) => ({
			cvs: {
				...s.cvs,
				[cv.id]: cv
			},
			order: [cv.id, ...s.order.filter((id) => id !== cv.id)]
		}));
		return cv;
	},
	importCv: (incoming) => {
		const cv = {
			...incoming,
			id: uid(),
			updatedAt: Date.now()
		};
		set((s) => ({
			cvs: {
				...s.cvs,
				[cv.id]: cv
			},
			order: [cv.id, ...s.order]
		}));
		return cv;
	},
	update: (id, patch) => {
		const current = get().cvs[id];
		if (!current) return;
		const next = {
			...patch(current),
			id,
			updatedAt: Date.now()
		};
		set((s) => ({ cvs: {
			...s.cvs,
			[id]: next
		} }));
	},
	patch: (id, partial) => {
		const current = get().cvs[id];
		if (!current) return;
		set((s) => ({ cvs: {
			...s.cvs,
			[id]: {
				...current,
				...partial,
				id,
				updatedAt: Date.now()
			}
		} }));
	},
	remove: (id) => {
		set((s) => {
			const { [id]: _, ...rest } = s.cvs;
			return {
				cvs: rest,
				order: s.order.filter((x) => x !== id)
			};
		});
	},
	duplicate: (id) => {
		const current = get().cvs[id];
		if (!current) return null;
		const copy = {
			...JSON.parse(JSON.stringify(current)),
			id: uid(),
			name: `${current.name} copy`,
			updatedAt: Date.now()
		};
		set((s) => ({
			cvs: {
				...s.cvs,
				[copy.id]: copy
			},
			order: [copy.id, ...s.order]
		}));
		return copy;
	},
	setTemplate: (id, template) => {
		const current = get().cvs[id];
		if (!current) return;
		set((s) => ({ cvs: {
			...s.cvs,
			[id]: {
				...current,
				template,
				updatedAt: Date.now()
			}
		} }));
	}
}), {
	name: "folio-cvs-v1",
	partialize: (s) => ({
		cvs: s.cvs,
		order: s.order
	}),
	onRehydrateStorage: () => (state) => {
		state?.setHydrated();
	}
}));
function useCv(id) {
	return useCvStore((s) => id ? s.cvs[id] : void 0);
}
function CvHydration() {
	(0, import_react.useEffect)(() => {
		const done = () => useCvStore.getState().setHydrated();
		if (useCvStore.persist.hasHydrated()) done();
		return useCvStore.persist.onFinishHydration(done);
	}, []);
	return null;
}
var styles_default = "/assets/styles-CYkOCql-.css";
var APP_NAME = "Folio";
var Route$2 = createRootRoute({
	head: () => ({
		meta: [
			{ charSet: "utf-8" },
			{
				name: "viewport",
				content: "width=device-width, initial-scale=1"
			},
			{ title: APP_NAME },
			{
				name: "description",
				content: "Write, compile, and strengthen your CV."
			},
			{
				name: "theme-color",
				content: "#F1EDE4"
			}
		],
		links: [
			{
				rel: "icon",
				type: "image/svg+xml",
				href: "/favicon.svg"
			},
			{
				rel: "stylesheet",
				href: styles_default
			},
			{
				rel: "manifest",
				href: "/__grok/manifest.webmanifest"
			},
			{
				rel: "apple-touch-icon",
				href: "/__grok/icon-180.png"
			}
		]
	}),
	component: () => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("html", {
		lang: "en",
		className: "antialiased",
		suppressHydrationWarning: true,
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("head", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(HeadContent, {}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("body", {
			className: "min-h-dvh bg-background text-foreground",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PreviewHostBridge, {}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(AuthProvider, { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CvHydration, {}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Outlet, {}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Toaster, {
						position: "bottom-right",
						toastOptions: { className: "font-sans !bg-card !text-foreground !border-border" }
					})
				] }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Scripts, {})
			]
		})]
	})
});
var $$splitComponentImporter$1 = () => import("./routes-DZ4Avu5M.mjs");
var Route$1 = createFileRoute("/")({ component: lazyRouteComponent($$splitComponentImporter$1, "component") });
var $$splitComponentImporter = () => import("./editor._cvId-CVL5xxMZ.mjs");
var Route = createFileRoute("/editor/$cvId")({ component: lazyRouteComponent($$splitComponentImporter, "component") });
var rootRouteChildren = {
	IndexRoute: Route$1.update({
		id: "/",
		path: "/",
		getParentRoute: () => Route$2
	}),
	EditorCvIdRoute: Route.update({
		id: "/editor/$cvId",
		path: "/editor/$cvId",
		getParentRoute: () => Route$2
	})
};
var routeTree = Route$2._addFileChildren(rootRouteChildren)._addFileTypes();
var router_exports = /* @__PURE__ */ __exportAll({ getRouter: () => getRouter });
function getRouter() {
	return createRouter({
		routeTree,
		defaultErrorComponent: AppErrorComponent
	});
}
//#endregion
export { SAMPLE_CV as a, uid as c, useCvStore as i, Route as n, cn as o, useCv as r, formatEdited as s, router_exports as t };
