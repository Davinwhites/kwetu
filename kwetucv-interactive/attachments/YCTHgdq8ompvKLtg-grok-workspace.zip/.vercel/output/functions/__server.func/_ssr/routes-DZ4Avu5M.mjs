import { i as __toESM } from "../_runtime.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { v as useNavigate } from "../_libs/@tanstack/react-router+[...].mjs";
import { o as require_jsx_runtime } from "../_libs/@radix-ui/react-collection+[...].mjs";
import { m as Copy, r as Trash2, s as Plus, u as FileUp } from "../_libs/lucide-react.mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { a as SAMPLE_CV, i as useCvStore, s as formatEdited } from "./router-DS2lYPVv.mjs";
import { l as scoreCv, n as CvDocument, o as TEMPLATE_META, s as Wordmark, t as Button } from "./wordmark-W7BV8jVE.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-DZ4Avu5M.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function HomeStudio() {
	const navigate = useNavigate();
	const hydrated = useCvStore((s) => s.hydrated);
	const cvs = useCvStore((s) => s.order.map((id) => s.cvs[id]).filter(Boolean));
	const create = useCvStore((s) => s.create);
	const duplicate = useCvStore((s) => s.duplicate);
	const remove = useCvStore((s) => s.remove);
	const importCv = useCvStore((s) => s.importCv);
	const fileRef = (0, import_react.useRef)(null);
	function openNew(seed) {
		const cv = create(seed);
		navigate({
			to: "/editor/$cvId",
			params: { cvId: cv.id }
		});
	}
	function onImport(file) {
		const reader = new FileReader();
		reader.onload = () => {
			try {
				const parsed = JSON.parse(String(reader.result));
				if (!parsed || typeof parsed !== "object" || !parsed.personal) throw new Error("invalid");
				const cv = importCv(parsed);
				toast.success("Imported");
				navigate({
					to: "/editor/$cvId",
					params: { cvId: cv.id }
				});
			} catch {
				toast.error("That file is not a Folio CV.");
			}
		};
		reader.readAsText(file);
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "min-h-dvh bg-background text-foreground",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
			className: "mx-auto flex max-w-6xl items-center justify-between gap-3 px-4 py-5 sm:px-8",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Wordmark, {}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-center gap-2",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						ref: fileRef,
						type: "file",
						accept: "application/json",
						className: "hidden",
						onChange: (e) => {
							const file = e.target.files?.[0];
							if (file) onImport(file);
							e.target.value = "";
						}
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
						variant: "ghost",
						size: "sm",
						className: "hidden sm:inline-flex",
						onClick: () => fileRef.current?.click(),
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FileUp, {}), "Import"]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
						size: "sm",
						onClick: () => openNew("blank"),
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, {}), "New CV"]
					})
				]
			})]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
			className: "mx-auto max-w-6xl px-4 pb-24 sm:px-8",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
					className: "grid items-end gap-8 pb-12 pt-4 lg:grid-cols-[1.1fr_0.9fr] lg:pb-16",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-xs font-medium uppercase tracking-[0.2em] text-muted",
							children: "Write · compile · send"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
							className: "mt-3 max-w-xl font-display text-[2.35rem] font-medium leading-[1.12] tracking-[-0.03em] text-balance sm:text-5xl",
							children: "A quieter studio for a stronger CV."
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-4 max-w-lg text-pretty text-base leading-relaxed text-muted sm:text-lg",
							children: "Draft with a writing coach, compile onto a real page, and retarget wording with Grok — without inventing a career you do not have."
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-8 flex flex-wrap gap-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								size: "lg",
								onClick: () => openNew("blank"),
								children: "Start a blank CV"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								size: "lg",
								variant: "secondary",
								onClick: () => openNew("sample"),
								children: "Open a finished example"
							})]
						})
					] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "relative mx-auto w-full max-w-[420px]",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "pointer-events-none absolute inset-3 translate-x-2 translate-y-3 rounded-sm bg-card shadow-[var(--shadow-border)]" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "relative overflow-hidden rounded-sm bg-paper shadow-[var(--shadow-border)]",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "origin-top scale-[0.52] sm:scale-[0.58]",
								style: { height: 1123 * .42 },
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "w-[794px]",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CvDocument, { cv: SAMPLE_CV })
								})
							})
						})]
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mb-4 flex items-baseline justify-between gap-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "font-display text-2xl font-medium tracking-tight",
						children: "Your drafts"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm text-muted",
						children: "Saved on this device"
					})]
				}), !hydrated ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "grid gap-4 sm:grid-cols-2 lg:grid-cols-3",
					children: [
						0,
						1,
						2
					].map((i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "h-40 animate-pulse rounded-2xl bg-surface" }, i))
				}) : cvs.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "rounded-2xl border border-dashed border-border bg-card px-6 py-12 text-center",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "font-display text-xl",
						children: "No drafts yet"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mx-auto mt-2 max-w-md text-sm text-muted",
						children: "Start blank, or open the example to see how Folio compiles a one-page CV as you write."
					})]
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
					className: "grid gap-4 sm:grid-cols-2 lg:grid-cols-3",
					children: cvs.map((cv) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DraftCard, {
						cv,
						onOpen: () => void navigate({
							to: "/editor/$cvId",
							params: { cvId: cv.id }
						}),
						onCopy: () => {
							const copy = duplicate(cv.id);
							if (copy) navigate({
								to: "/editor/$cvId",
								params: { cvId: copy.id }
							});
						},
						onDelete: () => {
							remove(cv.id);
							toast.success("Deleted");
						}
					}, cv.id))
				})] }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
					className: "mt-16 grid gap-6 border-t border-border pt-10 sm:grid-cols-3",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Feature, {
							title: "Write with a coach",
							body: "Bullets are scored as you type: action verbs, numbers, length. Weak filler is flagged before a recruiter sees it."
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Feature, {
							title: "Compile a real page",
							body: "Four templates, live A4 preview, print-to-PDF. Editorial stays single-column for ATS parsers."
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Feature, {
							title: "Retarget with Grok",
							body: "Paste a job description. Folio rewrites wording to match the role without inventing experience."
						})
					]
				})
			]
		})]
	});
}
function Feature({ title, body }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
		className: "font-display text-lg font-medium",
		children: title
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
		className: "mt-2 text-sm leading-relaxed text-muted",
		children: body
	})] });
}
function DraftCard({ cv, onOpen, onCopy, onDelete }) {
	const score = scoreCv(cv);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
		className: "group rounded-2xl border border-border bg-card p-4 shadow-[var(--shadow-border)] transition-[box-shadow] duration-[var(--motion-quick)] hover:shadow-[var(--shadow-border-hover)]",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
			type: "button",
			onClick: onOpen,
			className: "w-full text-left",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "truncate font-display text-xl font-medium tracking-tight",
					children: cv.personal.fullName || cv.name || "Untitled"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-1 truncate text-sm text-muted",
					children: cv.personal.title || "No title yet"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mt-4 flex items-center gap-2 text-xs text-subtle",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "tabular-nums text-primary",
							children: score.total
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "·" }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: TEMPLATE_META[cv.template].label }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "·" }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: formatEdited(cv.updatedAt) })
					]
				})
			]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mt-4 flex gap-1",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
				size: "sm",
				variant: "ghost",
				onClick: onCopy,
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Copy, {}), "Duplicate"]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				size: "sm",
				variant: "ghost",
				onClick: onDelete,
				"aria-label": "Delete",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash2, {})
			})]
		})]
	});
}
function Home() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(HomeStudio, {});
}
//#endregion
export { Home as component };
