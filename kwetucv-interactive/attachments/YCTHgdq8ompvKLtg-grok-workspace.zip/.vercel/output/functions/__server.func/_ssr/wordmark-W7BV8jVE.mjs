import { i as __toESM } from "../_runtime.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { _ as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { o as require_jsx_runtime, r as Slot } from "../_libs/@radix-ui/react-collection+[...].mjs";
import { t as cva } from "../_libs/class-variance-authority+clsx.mjs";
import { o as cn } from "./router-DS2lYPVv.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/wordmark-W7BV8jVE.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var buttonVariants = cva("inline-flex items-center justify-center gap-2 whitespace-nowrap rounded-lg text-sm font-medium transition-[opacity,transform,background-color,box-shadow,color] duration-[var(--motion-quick)] ease-[var(--ease-out)] focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring/70 focus-visible:ring-offset-2 focus-visible:ring-offset-background disabled:pointer-events-none disabled:opacity-40 [&_svg]:pointer-events-none [&_svg]:size-4 [&_svg]:shrink-0 active:scale-[0.98]", {
	variants: {
		variant: {
			default: "bg-primary text-primary-foreground shadow-[var(--shadow-border)] hover:opacity-90",
			secondary: "bg-card text-foreground shadow-[var(--shadow-border)] hover:shadow-[var(--shadow-border-hover)]",
			outline: "border border-border bg-transparent text-foreground hover:bg-surface",
			ghost: "text-foreground hover:bg-surface",
			destructive: "bg-danger text-primary-foreground hover:opacity-90",
			link: "text-primary underline-offset-4 hover:underline"
		},
		size: {
			default: "h-11 px-4",
			sm: "h-9 rounded-md px-3 text-[0.8125rem]",
			lg: "h-12 rounded-xl px-5",
			icon: "size-11",
			"icon-sm": "size-9 rounded-md"
		}
	},
	defaultVariants: {
		variant: "default",
		size: "default"
	}
});
var Button = import_react.forwardRef(({ className, variant, size, asChild = false, ...props }, ref) => {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(asChild ? Slot : "button", {
		className: cn(buttonVariants({
			variant,
			size,
			className
		})),
		ref,
		...props
	});
});
Button.displayName = "Button";
var TEMPLATES = [
	"editorial",
	"compact",
	"modern",
	"executive"
];
var TEMPLATE_META = {
	editorial: {
		label: "Editorial",
		blurb: "Single column, serif name, safest for ATS parsers.",
		ats: true
	},
	compact: {
		label: "Compact",
		blurb: "Denser type for packing a long career onto one page.",
		ats: true
	},
	modern: {
		label: "Modern",
		blurb: "Two-column layout with a pine rail for contact and skills.",
		ats: false
	},
	executive: {
		label: "Executive",
		blurb: "Name-forward band, generous space, board-ready.",
		ats: true
	}
};
var SECTIONS = [
	{
		id: "profile",
		label: "Profile"
	},
	{
		id: "summary",
		label: "Summary"
	},
	{
		id: "experience",
		label: "Experience"
	},
	{
		id: "education",
		label: "Education"
	},
	{
		id: "projects",
		label: "Projects"
	},
	{
		id: "skills",
		label: "Skills"
	},
	{
		id: "extras",
		label: "More"
	}
];
var ACTION_VERBS = [
	"led",
	"owned",
	"built",
	"shipped",
	"designed",
	"launched",
	"drove",
	"cut",
	"grew",
	"reduced",
	"increased",
	"improved",
	"created",
	"delivered",
	"negotiated",
	"mentored",
	"hired",
	"scaled",
	"automated",
	"rewrote",
	"migrated",
	"architected",
	"introduced",
	"established",
	"secured",
	"closed",
	"won",
	"saved",
	"raised",
	"partnered",
	"replaced",
	"rebuilt",
	"streamlined",
	"standardised",
	"standardized",
	"authored",
	"published",
	"taught",
	"trained",
	"directed",
	"managed",
	"coordinated",
	"implemented",
	"developed",
	"engineered",
	"optimised",
	"optimized",
	"analysed",
	"analyzed",
	"researched",
	"presented",
	"facilitated",
	"founded",
	"spearheaded",
	"orchestrated",
	"transformed",
	"accelerated",
	"expanded",
	"consolidated"
];
var WEAK = [
	/responsible for/i,
	/helped (to )?/i,
	/worked on/i,
	/tasked with/i,
	/duties included/i,
	/assisted with/i,
	/\bvarious\b/i,
	/\bseveral\b/i,
	/participated in/i,
	/was involved/i,
	/\bi\b/i,
	/\bmy\b/i,
	/\bwe\b/i
];
function lintBullet(text) {
	const t = text.trim();
	if (!t) return [{
		code: "empty",
		hint: "Write the impact, not the task list."
	}];
	const issues = [];
	const first = t.split(/\s+/)[0]?.replace(/[^a-zA-Z]/g, "").toLowerCase() ?? "";
	if (!ACTION_VERBS.includes(first)) issues.push({
		code: "verb",
		hint: "Start with a sharp action verb (Led, Shipped, Cut)."
	});
	if (!/\d/.test(t)) issues.push({
		code: "metric",
		hint: "Add a number: %, $, time, people, or volume."
	});
	if (t.split(/\s+/).length > 32) issues.push({
		code: "length",
		hint: "Trim to one line — roughly 18–28 words."
	});
	if (WEAK.some((re) => re.test(t))) issues.push({
		code: "weak",
		hint: "Drop filler like “responsible for” or first person."
	});
	return issues;
}
function words(s) {
	return s.trim() ? s.trim().split(/\s+/).length : 0;
}
function scoreCv(cv) {
	const parts = [];
	const p = cv.personal;
	const identityHints = [];
	let identity = 0;
	if (p.fullName.trim()) identity += 5;
	else identityHints.push("Add your name.");
	if (p.title.trim()) identity += 4;
	else identityHints.push("Add a target title, not a vague headline.");
	if (p.email.trim()) identity += 4;
	else identityHints.push("Add a professional email.");
	if (p.location.trim()) identity += 3;
	else identityHints.push("City and remote/on-site helps recruiters.");
	if (p.phone.trim() || p.linkedin.trim() || p.website.trim()) identity += 4;
	else identityHints.push("Add phone, LinkedIn, or a site.");
	parts.push({
		id: "identity",
		label: "Identity",
		score: identity,
		max: 20,
		hints: identityHints
	});
	const w = words(cv.summary);
	const summaryHints = [];
	let summary = 0;
	if (w === 0) summaryHints.push("Write a 40–90 word pitch.");
	else {
		if (w >= 30 && w <= 100) summary += 10;
		else if (w >= 18) summary += 6;
		else summary += 3;
		if (w < 35) summaryHints.push("Give the reader a fuller pitch (aim 40–90 words).");
		if (w > 110) {
			summaryHints.push("Shorten the summary — three sentences is enough.");
			summary = Math.min(summary, 6);
		}
		if (!/\bI\b|\bmy\b/i.test(cv.summary)) summary += 5;
		else summaryHints.push("Write in implied first person, without “I” or “my”.");
	}
	parts.push({
		id: "summary",
		label: "Summary",
		score: summary,
		max: 15,
		hints: summaryHints
	});
	const roles = cv.experience.filter((e) => e.company.trim() || e.role.trim());
	const expHints = [];
	let exp = 0;
	if (roles.length >= 2) exp += 8;
	else if (roles.length === 1) {
		exp += 4;
		expHints.push("Two roles (or one plus projects) reads more complete.");
	} else expHints.push("Add at least one role with dates.");
	if (roles.filter((e) => e.start.trim()).length === roles.length && roles.length) exp += 4;
	else if (roles.length) expHints.push("Every role needs a start year.");
	const bulletCount = roles.reduce((n, e) => n + e.bullets.filter((b) => b.trim()).length, 0);
	if (bulletCount >= 6) exp += 8;
	else if (bulletCount >= 3) exp += 5;
	else expHints.push("Aim for 3 strong bullets per recent role.");
	parts.push({
		id: "experience",
		label: "Experience",
		score: exp,
		max: 20,
		hints: expHints
	});
	const allBullets = [...cv.experience.flatMap((e) => e.bullets), ...cv.projects.flatMap((e) => e.bullets)].filter((b) => b.trim());
	let evidence = 0;
	const evidenceHints = [];
	const withNum = allBullets.filter((b) => /\d/.test(b)).length;
	const withVerb = allBullets.filter((b) => {
		const first = b.trim().split(/\s+/)[0]?.replace(/[^a-zA-Z]/g, "").toLowerCase() ?? "";
		return ACTION_VERBS.includes(first);
	}).length;
	if (allBullets.length === 0) evidenceHints.push("Bullets should prove impact.");
	else {
		if (withNum / allBullets.length >= .6) evidence += 10;
		else if (withNum > 0) evidence += 5;
		else evidenceHints.push("Most bullets still lack a number.");
		if (withVerb / allBullets.length >= .7) evidence += 10;
		else if (withVerb > 0) evidence += 5;
		else evidenceHints.push("Lead bullets with action verbs.");
	}
	parts.push({
		id: "evidence",
		label: "Evidence",
		score: evidence,
		max: 20,
		hints: evidenceHints
	});
	const skillItems = cv.skills.flatMap((g) => g.items.split(/[,/•|]/)).map((s) => s.trim()).filter(Boolean);
	const skillHints = [];
	let skills = 0;
	if (skillItems.length >= 8) skills += 10;
	else if (skillItems.length >= 4) skills += 6;
	else skillHints.push("List 8–14 skills grouped by theme.");
	parts.push({
		id: "skills",
		label: "Skills",
		score: skills,
		max: 10,
		hints: skillHints
	});
	const eduOk = cv.education.some((e) => e.school.trim());
	parts.push({
		id: "education",
		label: "Education",
		score: eduOk ? 8 : 0,
		max: 8,
		hints: eduOk ? [] : ["Add school and degree — or “Independent study” if self-taught."]
	});
	const extrasOk = cv.projects.some((p) => p.name.trim()) || cv.extras.some((e) => e.value.trim());
	parts.push({
		id: "signal",
		label: "Signal",
		score: extrasOk ? 7 : 0,
		max: 7,
		hints: extrasOk ? [] : ["A project, language, or talk gives the page a second hook."]
	});
	const total = Math.round(parts.reduce((n, p) => n + p.score, 0) / parts.reduce((n, p) => n + p.max, 0) * 100);
	let bulletIssues = 0;
	for (const b of allBullets) bulletIssues += lintBullet(b).length;
	return {
		total,
		parts,
		bulletIssues
	};
}
function contactLine(cv) {
	const p = cv.personal;
	return [
		p.location,
		p.email,
		p.phone,
		p.website,
		p.linkedin,
		p.github
	].map((s) => s.trim()).filter(Boolean);
}
function dates(start, end, current) {
	const a = start.trim();
	const b = current ? "Present" : end.trim();
	if (!a && !b) return "";
	if (a && b) return `${a} – ${b}`;
	return a || b;
}
function hasText(s) {
	return Boolean(s && s.trim());
}
function Sec({ title, children, dense }) {
	if (!children) return null;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: cn("cv-sec", dense && "cv-sec-dense"),
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", { children: title }), children]
	});
}
function Bullets({ items }) {
	const list = items.map((b) => b.trim()).filter(Boolean);
	if (!list.length) return null;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", { children: list.map((b, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: b }, i)) });
}
function SummaryBlock({ cv }) {
	if (!hasText(cv.summary)) return null;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Sec, {
		title: "Summary",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "cv-summary",
			children: cv.summary
		})
	});
}
function ExperienceBlock({ cv }) {
	const items = cv.experience.filter((e) => hasText(e.company) || hasText(e.role));
	if (!items.length) return null;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Sec, {
		title: "Experience",
		children: items.map((e) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "cv-job",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "cv-job-head",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "cv-job-role",
					children: [e.role || "Role", hasText(e.company) ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "cv-job-co",
						children: [" · ", e.company]
					}) : null]
				}), hasText(e.location) ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "cv-meta",
					children: e.location
				}) : null] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "cv-dates",
					children: dates(e.start, e.end, e.current)
				})]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Bullets, { items: e.bullets })]
		}, e.id))
	});
}
function EducationBlock({ cv }) {
	const items = cv.education.filter((e) => hasText(e.school));
	if (!items.length) return null;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Sec, {
		title: "Education",
		children: items.map((e) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "cv-job",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "cv-job-head",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "cv-job-role",
					children: [e.school, hasText(e.degree) || hasText(e.field) ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "cv-job-co",
						children: [
							" ",
							"· ",
							[e.degree, e.field].filter((x) => hasText(x)).join(" ")
						]
					}) : null]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "cv-dates",
					children: dates(e.start, e.end, false)
				})]
			}), hasText(e.details) ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "cv-meta",
				children: e.details
			}) : null]
		}, e.id))
	});
}
function ProjectsBlock({ cv }) {
	const items = cv.projects.filter((p) => hasText(p.name));
	if (!items.length) return null;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Sec, {
		title: "Projects",
		children: items.map((p) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "cv-job",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "cv-job-role",
					children: [p.name, hasText(p.url) ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "cv-job-co",
						children: [" · ", p.url]
					}) : null]
				}),
				hasText(p.summary) ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "cv-meta",
					children: p.summary
				}) : null,
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Bullets, { items: p.bullets })
			]
		}, p.id))
	});
}
function SkillsBlock({ cv }) {
	const items = cv.skills.filter((s) => hasText(s.items));
	if (!items.length) return null;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Sec, {
		title: "Skills",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "cv-skills",
			children: items.map((s) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: [hasText(s.category) ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("strong", { children: [s.category, " · "] }) : null, s.items] }, s.id))
		})
	});
}
function ExtrasBlock({ cv }) {
	const items = cv.extras.filter((e) => hasText(e.value));
	if (!items.length) return null;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Sec, {
		title: "Additional",
		children: items.map((e) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
			className: "cv-extra",
			children: [hasText(e.label) ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("strong", { children: [e.label, " · "] }) : null, e.value]
		}, e.id))
	});
}
function Header({ cv, kicker }) {
	const line = contactLine(cv);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
		className: "cv-head",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: cn("cv-name", kicker && "cv-name-band"),
				children: cv.personal.fullName || "Your name"
			}),
			hasText(cv.personal.title) ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "cv-title",
				children: cv.personal.title
			}) : null,
			line.length ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "cv-contact",
				children: line.join("  ·  ")
			}) : null
		]
	});
}
function Body({ cv }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SummaryBlock, { cv }),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ExperienceBlock, { cv }),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(EducationBlock, { cv }),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ProjectsBlock, { cv }),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SkillsBlock, { cv }),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ExtrasBlock, { cv })
	] });
}
function CvDocument({ cv, className }) {
	const empty = !hasText(cv.personal.fullName) && !hasText(cv.summary) && !cv.experience.some((e) => hasText(e.role) || hasText(e.company));
	if (cv.template === "modern") {
		const line = contactLine(cv);
		const skills = cv.skills.filter((s) => hasText(s.items));
		const extras = cv.extras.filter((e) => hasText(e.value));
		return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
			className: cn("cv-sheet cv-modern", className),
			"data-template": "modern",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("aside", {
				className: "cv-rail",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "cv-name",
						children: cv.personal.fullName || "Your name"
					}),
					hasText(cv.personal.title) ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "cv-title",
						children: cv.personal.title
					}) : null,
					line.length ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
						className: "cv-rail-list",
						children: line.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: item }, item))
					}) : null,
					skills.length ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", { children: "Skills" }), skills.map((s) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: [hasText(s.category) ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", { children: s.category }) : null, /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: s.items })] }, s.id))] }) : null,
					extras.length ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", { children: "More" }), extras.map((e) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: [hasText(e.label) ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", { children: e.label }) : null, /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: e.value })] }, e.id))] }) : null
				]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "cv-main",
				children: [
					empty ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "cv-empty",
						children: "Start writing in the left panel. This page compiles as you go."
					}) : null,
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SummaryBlock, { cv }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ExperienceBlock, { cv }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(EducationBlock, { cv }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ProjectsBlock, { cv })
				]
			})]
		});
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
		className: cn("cv-sheet", `cv-${cv.template}`, className),
		"data-template": cv.template,
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Header, {
			cv,
			kicker: cv.template === "executive"
		}), empty ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "cv-empty",
			children: "Start writing in the left panel. This page compiles as you go."
		}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Body, { cv })]
	});
}
var PAGE_W = 794;
var PAGE_H = 1123;
function CvStage({ cv }) {
	const ref = (0, import_react.useRef)(null);
	const [scale, setScale] = (0, import_react.useState)(.55);
	(0, import_react.useEffect)(() => {
		const el = ref.current;
		if (!el) return;
		const fit = () => {
			const w = el.clientWidth;
			setScale(Math.max(.28, Math.min(1, (w - 8) / PAGE_W)));
		};
		fit();
		const ro = new ResizeObserver(fit);
		ro.observe(el);
		return () => ro.disconnect();
	}, []);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		ref,
		className: "cv-stage",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "cv-stage-inner",
			style: { height: PAGE_H * scale },
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "cv-stage-page",
				style: {
					width: PAGE_W,
					minHeight: PAGE_H,
					transform: `translateX(-50%) scale(${scale})`
				},
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CvDocument, { cv })
			})
		})
	});
}
function Wordmark({ className, to = "/" }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
		to,
		className: cn("inline-flex items-baseline gap-2 text-foreground no-underline", className),
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "font-display text-xl font-medium tracking-tight sm:text-2xl",
			children: "Folio"
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "hidden text-xs font-medium uppercase tracking-[0.18em] text-muted sm:inline",
			children: "CV studio"
		})]
	});
}
//#endregion
export { TEMPLATES as a, lintBullet as c, SECTIONS as i, scoreCv as l, CvDocument as n, TEMPLATE_META as o, CvStage as r, Wordmark as s, Button as t };
