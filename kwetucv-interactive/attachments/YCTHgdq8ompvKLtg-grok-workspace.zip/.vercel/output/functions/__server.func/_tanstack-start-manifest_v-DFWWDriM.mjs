//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-DFWWDriM.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspace/src/routes/__root.tsx",
		children: ["/", "/editor/$cvId"],
		preloads: ["/assets/index-DaFTMg6s.js"],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-DaFTMg6s.js"
		} }]
	},
	"/": {
		filePath: "/workspace/src/routes/index.tsx",
		children: void 0,
		preloads: ["/assets/routes-Cw6DSzu_.js", "/assets/wordmark-7k12LkH8.js"]
	},
	"/editor/$cvId": {
		filePath: "/workspace/src/routes/editor.$cvId.tsx",
		children: void 0,
		preloads: ["/assets/editor._cvId-CdgpvVCI.js", "/assets/wordmark-7k12LkH8.js"]
	}
} });
//#endregion
export { tsrStartManifest };
