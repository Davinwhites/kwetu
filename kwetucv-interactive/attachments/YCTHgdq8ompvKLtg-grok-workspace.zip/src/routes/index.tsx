import { createFileRoute } from "@tanstack/react-router";
import { HomeStudio } from "@/components/cv/home";

export const Route = createFileRoute("/")({ component: Home });

function Home() {
  return <HomeStudio />;
}
