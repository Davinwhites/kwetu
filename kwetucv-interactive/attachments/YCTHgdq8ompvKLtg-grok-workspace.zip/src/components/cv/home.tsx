import { useRef } from "react";
import { useNavigate } from "@tanstack/react-router";
import { Copy, FileUp, Plus, Trash2 } from "lucide-react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { CvDocument } from "@/components/cv/preview";
import { Wordmark } from "@/components/cv/wordmark";
import { SAMPLE_CV } from "@/lib/cv/sample";
import { scoreCv } from "@/lib/cv/score";
import { useCvStore } from "@/lib/cv/store";
import { TEMPLATE_META, type CV } from "@/lib/cv/types";
import { formatEdited } from "@/lib/utils";

export function HomeStudio() {
  const navigate = useNavigate();
  const hydrated = useCvStore((s) => s.hydrated);
  const order = useCvStore((s) => s.order);
  const cvMap = useCvStore((s) => s.cvs);
  const cvs = order.map((id) => cvMap[id]).filter((c): c is CV => Boolean(c));
  const create = useCvStore((s) => s.create);
  const duplicate = useCvStore((s) => s.duplicate);
  const remove = useCvStore((s) => s.remove);
  const importCv = useCvStore((s) => s.importCv);
  const fileRef = useRef<HTMLInputElement>(null);

  function openNew(seed: "blank" | "sample") {
    const cv = create(seed);
    void navigate({ to: "/editor/$cvId", params: { cvId: cv.id } });
  }

  function onImport(file: File) {
    const reader = new FileReader();
    reader.onload = () => {
      try {
        const parsed = JSON.parse(String(reader.result)) as CV;
        if (!parsed || typeof parsed !== "object" || !parsed.personal) {
          throw new Error("invalid");
        }
        const cv = importCv(parsed);
        toast.success("Imported");
        void navigate({ to: "/editor/$cvId", params: { cvId: cv.id } });
      } catch {
        toast.error("That file is not a Folio CV.");
      }
    };
    reader.readAsText(file);
  }

  return (
    <div className="min-h-dvh bg-background text-foreground">
      <header className="mx-auto flex max-w-6xl items-center justify-between gap-3 px-4 py-5 sm:px-8">
        <Wordmark />
        <div className="flex items-center gap-2">
          <input
            ref={fileRef}
            type="file"
            accept="application/json"
            className="hidden"
            onChange={(e) => {
              const file = e.target.files?.[0];
              if (file) onImport(file);
              e.target.value = "";
            }}
          />
          <Button variant="ghost" size="sm" className="hidden sm:inline-flex" onClick={() => fileRef.current?.click()}>
            <FileUp />
            Import
          </Button>
          <Button size="sm" onClick={() => openNew("blank")}>
            <Plus />
            New CV
          </Button>
        </div>
      </header>

      <main className="mx-auto max-w-6xl px-4 pb-24 sm:px-8">
        <section className="grid items-end gap-8 pb-12 pt-4 lg:grid-cols-[1.1fr_0.9fr] lg:pb-16">
          <div>
            <p className="text-xs font-medium uppercase tracking-[0.2em] text-muted">Write · compile · send</p>
            <h1 className="mt-3 max-w-xl font-display text-[2.35rem] font-medium leading-[1.12] tracking-[-0.03em] text-balance sm:text-5xl">
              A quieter studio for a stronger CV.
            </h1>
            <p className="mt-4 max-w-lg text-pretty text-base leading-relaxed text-muted sm:text-lg">
              Draft with a writing coach, compile onto a real page, and retarget wording with Grok — without inventing a career you do not have.
            </p>
            <div className="mt-8 flex flex-wrap gap-3">
              <Button size="lg" onClick={() => openNew("blank")}>
                Start a blank CV
              </Button>
              <Button size="lg" variant="secondary" onClick={() => openNew("sample")}>
                Open a finished example
              </Button>
            </div>
          </div>
          <div className="relative mx-auto w-full max-w-[420px]">
            <div className="pointer-events-none absolute inset-3 translate-x-2 translate-y-3 rounded-sm bg-card shadow-[var(--shadow-border)]" />
            <div className="relative overflow-hidden rounded-sm bg-paper shadow-[var(--shadow-border)]">
              <div className="folio-thumb">
                <div className="folio-thumb-page">
                  <CvDocument cv={SAMPLE_CV} />
                </div>
              </div>
            </div>
          </div>
        </section>

        <section>
          <div className="mb-4 flex items-baseline justify-between gap-3">
            <h2 className="font-display text-2xl font-medium tracking-tight">Your drafts</h2>
            <p className="text-sm text-muted">Saved on this device</p>
          </div>
          {!hydrated ? (
            <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
              {[0, 1, 2].map((i) => (
                <div key={i} className="h-40 animate-pulse rounded-2xl bg-surface" />
              ))}
            </div>
          ) : cvs.length === 0 ? (
            <div className="rounded-2xl border border-dashed border-border bg-card px-6 py-12 text-center">
              <p className="font-display text-xl">No drafts yet</p>
              <p className="mx-auto mt-2 max-w-md text-sm text-muted">
                Start blank, or open the example to see how Folio compiles a one-page CV as you write.
              </p>
            </div>
          ) : (
            <ul className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
              {cvs.map((cv) => (
                <DraftCard
                  key={cv.id}
                  cv={cv}
                  onOpen={() => void navigate({ to: "/editor/$cvId", params: { cvId: cv.id } })}
                  onCopy={() => {
                    const copy = duplicate(cv.id);
                    if (copy) void navigate({ to: "/editor/$cvId", params: { cvId: copy.id } });
                  }}
                  onDelete={() => {
                    remove(cv.id);
                    toast.success("Deleted");
                  }}
                />
              ))}
            </ul>
          )}
        </section>

        <section className="mt-16 grid gap-6 border-t border-border pt-10 sm:grid-cols-3">
          <Feature
            title="Write with a coach"
            body="Bullets are scored as you type: action verbs, numbers, length. Weak filler is flagged before a recruiter sees it."
          />
          <Feature
            title="Compile a real page"
            body="Four templates, live A4 preview, print-to-PDF. Editorial stays single-column for ATS parsers."
          />
          <Feature
            title="Retarget with Grok"
            body="Paste a job description. Folio rewrites wording to match the role without inventing experience."
          />
        </section>
      </main>
    </div>
  );
}

function Feature({ title, body }: { title: string; body: string }) {
  return (
    <div>
      <h3 className="font-display text-lg font-medium">{title}</h3>
      <p className="mt-2 text-sm leading-relaxed text-muted">{body}</p>
    </div>
  );
}

function DraftCard({
  cv,
  onOpen,
  onCopy,
  onDelete,
}: {
  cv: CV;
  onOpen: () => void;
  onCopy: () => void;
  onDelete: () => void;
}) {
  const score = scoreCv(cv);
  return (
    <li className="group rounded-2xl border border-border bg-card p-4 shadow-[var(--shadow-border)] transition-[box-shadow] duration-[var(--motion-quick)] hover:shadow-[var(--shadow-border-hover)]">
      <button type="button" onClick={onOpen} className="w-full text-left">
        <p className="truncate font-display text-xl font-medium tracking-tight">
          {cv.personal.fullName || cv.name || "Untitled"}
        </p>
        <p className="mt-1 truncate text-sm text-muted">{cv.personal.title || "No title yet"}</p>
        <div className="mt-4 flex items-center gap-2 text-xs text-subtle">
          <span className="tabular-nums text-primary">{score.total}</span>
          <span>·</span>
          <span>{TEMPLATE_META[cv.template].label}</span>
          <span>·</span>
          <span>{formatEdited(cv.updatedAt)}</span>
        </div>
      </button>
      <div className="mt-4 flex gap-1">
        <Button size="sm" variant="ghost" onClick={onCopy}>
          <Copy />
          Duplicate
        </Button>
        <Button size="sm" variant="ghost" onClick={onDelete} aria-label="Delete">
          <Trash2 />
        </Button>
      </div>
    </li>
  );
}
