import { useMemo, useState } from "react";
import { Loader2, Sparkles, Target } from "lucide-react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { runCvAi, type ReviewResult, type TailorResult } from "@/lib/ai";
import type { CV } from "@/lib/cv/types";
import { TEMPLATE_META } from "@/lib/cv/types";
import { scoreCv } from "@/lib/cv/score";
import { useCvStore } from "@/lib/cv/store";
import { cn } from "@/lib/utils";

function ScoreRing({ value }: { value: number }) {
  const r = 26;
  const c = 2 * Math.PI * r;
  const off = c * (1 - Math.max(0, Math.min(100, value)) / 100);
  return (
    <div className="relative size-[76px] shrink-0">
      <svg viewBox="0 0 72 72" className="size-full -rotate-90" aria-hidden="true">
        <circle cx="36" cy="36" r={r} fill="none" stroke="var(--color-border)" strokeWidth="6" />
        <circle
          cx="36"
          cy="36"
          r={r}
          fill="none"
          stroke="var(--color-primary)"
          strokeWidth="6"
          strokeDasharray={c}
          strokeDashoffset={off}
          strokeLinecap="round"
        />
      </svg>
      <span className="absolute inset-0 flex items-center justify-center font-display text-lg font-medium tabular-nums text-foreground">
        {value}
      </span>
    </div>
  );
}

export function CoachPanel({ cv }: { cv: CV }) {
  const score = useMemo(() => scoreCv(cv), [cv]);
  const update = useCvStore((s) => s.update);
  const [job, setJob] = useState("");
  const [busy, setBusy] = useState<"review" | "tailor" | null>(null);
  const [review, setReview] = useState<ReviewResult | null>(null);
  const [tailor, setTailor] = useState<TailorResult | null>(null);
  const meta = TEMPLATE_META[cv.template];

  async function reviewCv() {
    setBusy("review");
    try {
      const res = await runCvAi({ data: { task: "review", cv, job: job.trim() || undefined } });
      if (!res.ok) {
        toast.error(res.error);
        return;
      }
      if (res.kind !== "review") {
        toast.error("Unexpected response");
        return;
      }
      setReview(res.review);
    } catch {
      toast.error("Review failed. Try again.");
    } finally {
      setBusy(null);
    }
  }

  async function tailorCv() {
    if (!job.trim()) {
      toast.error("Paste a job description to tailor against.");
      return;
    }
    setBusy("tailor");
    try {
      const res = await runCvAi({ data: { task: "tailor", cv, job: job.trim() } });
      if (!res.ok) {
        toast.error(res.error);
        return;
      }
      if (res.kind !== "tailor") {
        toast.error("Unexpected response");
        return;
      }
      setTailor(res.tailor);
    } catch {
      toast.error("Tailor failed. Try again.");
    } finally {
      setBusy(null);
    }
  }

  function applySummary(text: string) {
    update(cv.id, (cur) => ({ ...cur, summary: text }));
    toast.success("Summary updated");
  }

  function applyBullet(id: string, index: number, suggested: string) {
    update(cv.id, (cur) => ({
      ...cur,
      experience: cur.experience.map((e) =>
        e.id === id
          ? {
              ...e,
              bullets: e.bullets.map((b, i) => (i === index ? suggested : b)),
            }
          : e,
      ),
    }));
    toast.success("Bullet updated");
  }

  return (
    <div className="flex flex-col gap-6">
      <div className="flex items-center gap-4 rounded-2xl bg-surface p-4">
        <ScoreRing value={score.total} />
        <div className="min-w-0">
          <p className="text-sm font-medium text-foreground">Writing score</p>
          <p className="text-sm text-muted">
            {score.bulletIssues
              ? `${score.bulletIssues} bullet ${score.bulletIssues === 1 ? "note" : "notes"} to tighten`
              : "Bullets look disciplined"}
          </p>
          <p className="mt-1 text-xs text-subtle">
            {meta.label} · {meta.ats ? "ATS-safer single column" : "Visual two-column — export Editorial for ATS"}
          </p>
        </div>
      </div>

      <div className="space-y-2">
        {score.parts.map((part) => (
          <div key={part.id}>
            <div className="mb-1 flex items-center justify-between gap-2 text-xs">
              <span className="font-medium text-foreground">{part.label}</span>
              <span className="tabular-nums text-muted">
                {part.score}/{part.max}
              </span>
            </div>
            <div className="h-1.5 overflow-hidden rounded-full bg-border">
              <div
                className="h-full rounded-full bg-primary transition-[width] duration-[var(--motion-fast)]"
                style={{ width: `${(part.score / part.max) * 100}%` }}
              />
            </div>
            {part.hints[0] ? <p className="mt-1 text-xs text-muted">{part.hints[0]}</p> : null}
          </div>
        ))}
      </div>

      <div className="space-y-2">
        <p className="text-sm font-medium">Target a role</p>
        <Textarea
          value={job}
          onChange={(e) => setJob(e.target.value)}
          placeholder="Paste a job description. Folio will review and retarget wording — it will not invent experience."
          className="min-h-[120px]"
        />
        <div className="flex flex-col gap-2">
          <Button onClick={() => void reviewCv()} disabled={busy !== null} className="w-full">
            {busy === "review" ? <Loader2 className="animate-spin" /> : <Sparkles />}
            Review with Grok
          </Button>
          <Button
            variant="secondary"
            onClick={() => void tailorCv()}
            disabled={busy !== null}
            className="w-full"
          >
            {busy === "tailor" ? <Loader2 className="animate-spin" /> : <Target />}
            Tailor wording
          </Button>
        </div>
      </div>

      {review ? (
        <div className="space-y-3 rounded-2xl border border-border bg-card p-4">
          <div className="flex items-center justify-between gap-2">
            <p className="text-sm font-medium">Grok review</p>
            <Badge variant="good" className="tabular-nums">
              {review.score}
            </Badge>
          </div>
          <p className="text-sm text-muted">{review.summary}</p>
          <ul className="space-y-2">
            {review.issues.map((issue, i) => (
              <li key={i} className="rounded-xl bg-surface p-3">
                <div className="mb-1 flex items-center gap-2">
                  <Badge
                    variant={issue.severity === "high" ? "danger" : issue.severity === "med" ? "warn" : "secondary"}
                  >
                    {issue.severity}
                  </Badge>
                  <p className="text-sm font-medium">{issue.title}</p>
                </div>
                <p className="text-sm text-muted">{issue.fix}</p>
              </li>
            ))}
          </ul>
        </div>
      ) : null}

      {tailor ? (
        <div className="space-y-3 rounded-2xl border border-border bg-card p-4">
          <p className="text-sm font-medium">Suggested retarget</p>
          {tailor.note ? <p className="text-sm text-muted">{tailor.note}</p> : null}
          {tailor.summary ? (
            <div className="rounded-xl bg-surface p-3">
              <p className="mb-2 text-xs font-medium uppercase tracking-wide text-subtle">Summary</p>
              <p className="text-sm">{tailor.summary}</p>
              <Button size="sm" className="mt-3" onClick={() => applySummary(tailor.summary)}>
                Apply summary
              </Button>
            </div>
          ) : null}
          {tailor.bullets.map((b, i) => (
            <div key={`${b.id}-${b.index}-${i}`} className="rounded-xl bg-surface p-3">
              <p className="text-sm">{b.suggested}</p>
              <Button
                size="sm"
                variant="secondary"
                className="mt-3"
                onClick={() => applyBullet(b.id, b.index, b.suggested)}
              >
                Apply bullet
              </Button>
            </div>
          ))}
        </div>
      ) : null}

      <p className={cn("text-xs text-subtle")}>
        Grok is called only when you press a button. Drafts stay on this device.
      </p>
    </div>
  );
}
