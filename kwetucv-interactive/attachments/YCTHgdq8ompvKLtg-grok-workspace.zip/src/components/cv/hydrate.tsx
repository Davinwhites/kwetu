import { useEffect } from "react";
import { useCvStore } from "@/lib/cv/store";

export function CvHydration() {
  useEffect(() => {
    const done = () => useCvStore.getState().setHydrated();
    const unsub = useCvStore.persist.onFinishHydration(done);
    void useCvStore.persist.rehydrate();
    if (useCvStore.persist.hasHydrated()) done();
    return unsub;
  }, []);
  return null;
}
