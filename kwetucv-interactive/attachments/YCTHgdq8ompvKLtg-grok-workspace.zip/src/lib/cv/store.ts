import { create } from "zustand";
import { persist } from "zustand/middleware";
import { uid } from "@/lib/utils";
import type { CV, TemplateId } from "./types";
import { SAMPLE_CV as SAMPLE } from "./sample";

export function blankCv(partial?: Partial<CV>): CV {
  const id = partial?.id ?? uid();
  return {
    id,
    name: partial?.name ?? "Untitled CV",
    template: partial?.template ?? "editorial",
    updatedAt: Date.now(),
    personal: {
      fullName: "",
      title: "",
      email: "",
      phone: "",
      location: "",
      website: "",
      linkedin: "",
      github: "",
      ...partial?.personal,
    },
    summary: partial?.summary ?? "",
    experience: partial?.experience ?? [
      {
        id: uid(),
        company: "",
        role: "",
        location: "",
        start: "",
        end: "",
        current: false,
        bullets: ["", ""],
      },
    ],
    education: partial?.education ?? [
      {
        id: uid(),
        school: "",
        degree: "",
        field: "",
        start: "",
        end: "",
        details: "",
      },
    ],
    projects: partial?.projects ?? [],
    skills: partial?.skills ?? [{ id: uid(), category: "Core", items: "" }],
    extras: partial?.extras ?? [],
  };
}

function cloneSample(): CV {
  const raw = JSON.parse(JSON.stringify(SAMPLE)) as CV;
  raw.id = uid();
  raw.updatedAt = Date.now();
  return raw;
}

type CvState = {
  cvs: Record<string, CV>;
  order: string[];
  hydrated: boolean;
  setHydrated: () => void;
  create: (seed?: "blank" | "sample") => CV;
  importCv: (cv: CV) => CV;
  update: (id: string, patch: (cv: CV) => CV) => void;
  patch: (id: string, partial: Partial<CV>) => void;
  remove: (id: string) => void;
  duplicate: (id: string) => CV | null;
  setTemplate: (id: string, template: TemplateId) => void;
};

export const useCvStore = create<CvState>()(
  persist(
    (set, get) => ({
      cvs: {},
      order: [],
      hydrated: false,
      setHydrated: () => {
        if (get().hydrated) return;
        set({ hydrated: true });
      },
      create: (seed = "blank") => {
        const cv = seed === "sample" ? cloneSample() : blankCv();
        set((s) => ({
          cvs: { ...s.cvs, [cv.id]: cv },
          order: [cv.id, ...s.order.filter((id) => id !== cv.id)],
        }));
        return cv;
      },
      importCv: (incoming) => {
        const cv: CV = { ...incoming, id: uid(), updatedAt: Date.now() };
        set((s) => ({
          cvs: { ...s.cvs, [cv.id]: cv },
          order: [cv.id, ...s.order],
        }));
        return cv;
      },
      update: (id, patch) => {
        const current = get().cvs[id];
        if (!current) return;
        const next = { ...patch(current), id, updatedAt: Date.now() };
        set((s) => ({ cvs: { ...s.cvs, [id]: next } }));
      },
      patch: (id, partial) => {
        const current = get().cvs[id];
        if (!current) return;
        set((s) => ({
          cvs: {
            ...s.cvs,
            [id]: { ...current, ...partial, id, updatedAt: Date.now() },
          },
        }));
      },
      remove: (id) => {
        set((s) => {
          const { [id]: _, ...rest } = s.cvs;
          return { cvs: rest, order: s.order.filter((x) => x !== id) };
        });
      },
      duplicate: (id) => {
        const current = get().cvs[id];
        if (!current) return null;
        const copy: CV = {
          ...(JSON.parse(JSON.stringify(current)) as CV),
          id: uid(),
          name: `${current.name} copy`,
          updatedAt: Date.now(),
        };
        set((s) => ({
          cvs: { ...s.cvs, [copy.id]: copy },
          order: [copy.id, ...s.order],
        }));
        return copy;
      },
      setTemplate: (id, template) => {
        const current = get().cvs[id];
        if (!current) return;
        set((s) => ({
          cvs: {
            ...s.cvs,
            [id]: { ...current, template, updatedAt: Date.now() },
          },
        }));
      },
    }),
    {
      name: "folio-cvs-v1",
      partialize: (s) => ({ cvs: s.cvs, order: s.order }),
      skipHydration: true,
    },
  ),
);

export function useCv(id: string | undefined) {
  return useCvStore((s) => (id ? s.cvs[id] : undefined));
}
