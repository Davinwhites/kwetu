import type { CV } from "./types";

export const SAMPLE_CV: CV = {
  id: "sample",
  name: "Leila Okonkwo — Staff Product Engineer",
  template: "editorial",
  updatedAt: Date.now(),
  personal: {
    fullName: "Leila Okonkwo",
    title: "Staff Product Engineer",
    email: "leila.okonkwo@pm.me",
    phone: "+254 711 482 190",
    location: "Nairobi · Remote",
    website: "leila.codes",
    linkedin: "linkedin.com/in/leilaokonkwo",
    github: "github.com/lokonkwo",
  },
  summary:
    "Staff product engineer who ships payment and logistics systems used by millions. Leads cross-functional squads from discovery through production, with a bias for measurable reliability, clear writing, and mentoring the next layer of staff talent.",
  experience: [
    {
      id: "exp-1",
      company: "Kibo Payments",
      role: "Staff Product Engineer",
      location: "Nairobi",
      start: "2022",
      end: "",
      current: true,
      bullets: [
        "Led a 9-person squad that rebuilt checkout, cutting failed payments 38% and lifting conversion 11% across 14 markets.",
        "Designed the merchant risk engine now scoring 4.2M transactions daily with p95 latency under 90ms.",
        "Wrote the incident review standard adopted company-wide; mean time to mitigate dropped from 3.4h to 48m in two quarters.",
        "Mentored four senior engineers to staff-track promotions; two now run their own product areas.",
      ],
    },
    {
      id: "exp-2",
      company: "Atlas Freight",
      role: "Senior Engineer",
      location: "London",
      start: "2019",
      end: "2022",
      current: false,
      bullets: [
        "Shipped a routing service that reduced empty miles 17% and saved $6.4M in annual carrier spend.",
        "Replaced a weekly ops spreadsheet with a live capacity board used by 120 dispatchers.",
        "Owned on-call for the tracking stack; drove a 99.95% monthly uptime after a year of 99.4%.",
      ],
    },
    {
      id: "exp-3",
      company: "Northwind Labs",
      role: "Product Engineer",
      location: "Lagos",
      start: "2016",
      end: "2019",
      current: false,
      bullets: [
        "Built the first self-serve onboarding for a B2B analytics product, shrinking time-to-value from 11 days to 9 hours.",
        "Partnered with design on a component library still in use across three product lines.",
      ],
    },
  ],
  education: [
    {
      id: "edu-1",
      school: "University of Lagos",
      degree: "B.Sc.",
      field: "Computer Science",
      start: "2012",
      end: "2016",
      details: "First class · Systems & HCI",
    },
  ],
  projects: [
    {
      id: "proj-1",
      name: "Ledgerlight",
      url: "ledgerlight.dev",
      summary: "Open-source reconciler for multi-currency ledgers.",
      bullets: [
        "Used by 800+ finance teams; 4.9k GitHub stars.",
        "Wrote the matching algorithm and the public audit trail format.",
      ],
    },
  ],
  skills: [
    {
      id: "sk-1",
      category: "Build",
      items: "TypeScript, React, Node, Go, Postgres, Kafka",
    },
    {
      id: "sk-2",
      category: "Lead",
      items: "Staff coaching, incident command, product discovery, RFC writing",
    },
    {
      id: "sk-3",
      category: "Domain",
      items: "Payments, risk, logistics, multi-region systems",
    },
  ],
  extras: [
    { id: "ex-1", label: "Languages", value: "English, Yoruba, French" },
    {
      id: "ex-2",
      label: "Speaking",
      value: "QCon London 2025 · Strange Loop 2023",
    },
  ],
};
