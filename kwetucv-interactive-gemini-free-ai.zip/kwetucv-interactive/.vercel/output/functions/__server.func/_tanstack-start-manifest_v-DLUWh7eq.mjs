//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-DLUWh7eq.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspace/src/routes/__root.tsx",
		children: [
			"/",
			"/about",
			"/account",
			"/checkout",
			"/login",
			"/pricing",
			"/privacy",
			"/studio",
			"/terms",
			"/editor/$cvId",
			"/api/auth/$"
		],
		preloads: [
			"/assets/index-_aKPV5CL.js",
			"/assets/rolldown-runtime-hePW80VL.js",
			"/assets/client-D9440YHn.js",
			"/assets/react-dom-CceGlRlm.js",
			"/assets/middleware-DptWnK5Z.js",
			"/assets/use-current-user-D2xw7wnc.js",
			"/assets/lazyRouteComponent-DbrpYzYW.js",
			"/assets/preload-helper--AnMGwJy.js",
			"/assets/documents-BV-RALsS.js",
			"/assets/login-Dv6MPUrO.js"
		],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-_aKPV5CL.js"
		} }]
	},
	"/": {
		filePath: "/workspace/src/routes/index.tsx",
		children: void 0,
		preloads: [
			"/assets/routes-DGXL9q4r.js",
			"/assets/sample-B3sOrnfR.js",
			"/assets/chrome-DlFmDkkt.js",
			"/assets/button-1HahnjoW.js",
			"/assets/plans-DsfjFPyQ.js",
			"/assets/categories-Da5UY8Y6.js",
			"/assets/preview-B2ep6Uh6.js"
		]
	},
	"/about": {
		filePath: "/workspace/src/routes/about.tsx",
		children: void 0,
		preloads: [
			"/assets/about-DMxeCgiw.js",
			"/assets/chrome-DlFmDkkt.js",
			"/assets/button-1HahnjoW.js"
		]
	},
	"/account": {
		filePath: "/workspace/src/routes/account.tsx",
		children: void 0,
		preloads: [
			"/assets/account-B3yjc2CU.js",
			"/assets/chrome-DlFmDkkt.js",
			"/assets/button-1HahnjoW.js",
			"/assets/plans-DsfjFPyQ.js",
			"/assets/billing-DfbezhLg.js"
		]
	},
	"/checkout": {
		filePath: "/workspace/src/routes/checkout.tsx",
		children: void 0,
		preloads: [
			"/assets/checkout-SSU3C1a6.js",
			"/assets/loader-circle-CtoQn3LM.js",
			"/assets/chrome-DlFmDkkt.js",
			"/assets/button-1HahnjoW.js",
			"/assets/plans-DsfjFPyQ.js",
			"/assets/billing-DfbezhLg.js",
			"/assets/input-BJBPsACt.js"
		]
	},
	"/login": {
		filePath: "/workspace/src/routes/login.tsx",
		children: void 0,
		preloads: [
			"/assets/login-C9RZ9s5t.js",
			"/assets/button-1HahnjoW.js",
			"/assets/input-BJBPsACt.js",
			"/assets/label-CBAcht-L.js"
		]
	},
	"/pricing": {
		filePath: "/workspace/src/routes/pricing.tsx",
		children: void 0,
		preloads: [
			"/assets/pricing-CMWD8-ll.js",
			"/assets/chrome-DlFmDkkt.js",
			"/assets/button-1HahnjoW.js",
			"/assets/plans-DsfjFPyQ.js"
		]
	},
	"/privacy": {
		filePath: "/workspace/src/routes/privacy.tsx",
		children: void 0,
		preloads: ["/assets/privacy-QH-AeR8u.js", "/assets/chrome-DlFmDkkt.js"]
	},
	"/studio": {
		filePath: "/workspace/src/routes/studio.tsx",
		children: void 0,
		preloads: [
			"/assets/studio-Bc9Bz8X1.js",
			"/assets/loader-circle-CtoQn3LM.js",
			"/assets/dist-BOKE7xwE.js",
			"/assets/chrome-DlFmDkkt.js",
			"/assets/button-1HahnjoW.js",
			"/assets/plans-DsfjFPyQ.js",
			"/assets/billing-DfbezhLg.js",
			"/assets/input-BJBPsACt.js",
			"/assets/categories-Da5UY8Y6.js"
		]
	},
	"/terms": {
		filePath: "/workspace/src/routes/terms.tsx",
		children: void 0,
		preloads: ["/assets/terms-CfQ-G664.js", "/assets/chrome-DlFmDkkt.js"]
	},
	"/editor/$cvId": {
		filePath: "/workspace/src/routes/editor.$cvId.tsx",
		children: void 0,
		preloads: [
			"/assets/editor._cvId-CwydsKff.js",
			"/assets/loader-circle-CtoQn3LM.js",
			"/assets/dist-BOKE7xwE.js",
			"/assets/chrome-DlFmDkkt.js",
			"/assets/button-1HahnjoW.js",
			"/assets/input-BJBPsACt.js",
			"/assets/categories-Da5UY8Y6.js",
			"/assets/dist-C49iwmbK.js",
			"/assets/label-CBAcht-L.js",
			"/assets/preview-B2ep6Uh6.js"
		]
	}
} });
//#endregion
export { tsrStartManifest };
