import { o as require_jsx_runtime } from "../_libs/@radix-ui/react-collection+[...].mjs";
import { i as SiteHeader, r as SiteFooter } from "./chrome-CMH7kCiq.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/terms-CQMUSO05.js
var import_jsx_runtime = require_jsx_runtime();
function TermsPage() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "min-h-dvh bg-background",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SiteHeader, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
				className: "mx-auto max-w-2xl px-4 py-14 sm:px-8",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
						className: "font-display text-4xl font-medium tracking-tight",
						children: "Terms of use"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-2 text-sm text-subtle",
						children: "Lawful personal use. Last updated September 2026."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-8 space-y-4 text-sm leading-relaxed text-muted",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "KwetuCV is professional software for writing your own curriculum vitae and cover letter. By creating an account you agree to use it only for lawful employment, study, and professional purposes. You must not use it to impersonate another person, forge identity documents, or mislead an employer." }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "You own the text you write. AI suggestions are a drafting aid. You must check every fact, date, grade, and NIN before you send a CV. KwetuCV is not a party to any job application and is not affiliated with the Ministry of Public Service, NIRA, NITA-U, or any employer." }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "Subscriptions and one-time Finish credits are priced in Ugandan shillings and charged through the payment channel you choose (MTN MoMo, Airtel Money, or card). Completing checkout attaches the plan to your saved account. Paid periods do not auto-extend in this studio unless you pay again." }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "Accounts are stored so you can return. Keep your password. If you sign in with Google or X, that provider’s terms also apply. We may suspend accounts used for fraud or abuse." }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "The software is provided as-is. We work to keep it available and among the most capable CV studios for Ugandan professionals, but we do not warrant that a particular application will succeed." })
						]
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SiteFooter, {})
		]
	});
}
//#endregion
export { TermsPage as component };
