import { _ as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { o as require_jsx_runtime } from "../_libs/@radix-ui/react-collection+[...].mjs";
import { t as Button } from "./button-L8IaURhk.mjs";
import { i as SiteHeader, r as SiteFooter } from "./chrome-CMH7kCiq.mjs";
import { a as formatUgx, l as periodLabel, n as CHECKOUT_PLANS, r as PLANS } from "./plans-DdYzqCRR.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/pricing-D3YVIPyw.js
var import_jsx_runtime = require_jsx_runtime();
function PricingPage() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "min-h-dvh bg-background",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SiteHeader, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
				className: "mx-auto max-w-6xl px-4 py-14 sm:px-8",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs font-medium uppercase tracking-[0.2em] text-muted",
						children: "UGX · MTN · Airtel · Card"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
						className: "mt-3 max-w-2xl font-display text-4xl font-medium tracking-tight",
						children: "Subscriptions for a finished CV — priced for Uganda."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-4 max-w-xl text-muted",
						children: "Starter is free forever. Writer unlocks the AI coach. Career Pro finishes a complete CV and cover letter from your notes. Pay in Ugandan shillings."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mt-10 grid gap-4 md:grid-cols-2 xl:grid-cols-4",
						children: ["free", ...CHECKOUT_PLANS].map((id) => {
							const plan = PLANS[id];
							return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
								className: "flex flex-col rounded-2xl border border-border bg-card p-5 shadow-[var(--shadow-border)]",
								children: [
									plan.featured ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "text-xs font-medium uppercase tracking-wide text-primary",
										children: "Most chosen"
									}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "text-xs font-medium uppercase tracking-wide text-subtle",
										children: periodLabel(plan)
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
										className: "mt-2 font-display text-2xl font-medium",
										children: plan.name
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "mt-2 font-display text-3xl font-medium tabular-nums",
										children: plan.priceUgx === 0 ? "UGX 0" : formatUgx(plan.priceUgx)
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "mt-1 text-sm text-muted",
										children: plan.tagline
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
										className: "mt-4 flex-1 space-y-2 text-sm text-muted",
										children: plan.features.map((f) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: f }, f))
									}),
									id === "free" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
										className: "mt-6",
										variant: "secondary",
										asChild: true,
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
											to: "/login",
											children: "Create account"
										})
									}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
										className: "mt-6",
										variant: plan.featured ? "default" : "secondary",
										asChild: true,
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
											to: "/checkout",
											search: { plan: id },
											children: "Continue"
										})
									})
								]
							}, id);
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-10 max-w-2xl text-sm text-subtle",
						children: "Checkout in this studio records the subscription on your KwetuCV account using MTN MoMo, Airtel Money, or card details you confirm. It is for lawful personal use: writing your own CV for employment. See Terms."
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SiteFooter, {})
		]
	});
}
//#endregion
export { PricingPage as component };
