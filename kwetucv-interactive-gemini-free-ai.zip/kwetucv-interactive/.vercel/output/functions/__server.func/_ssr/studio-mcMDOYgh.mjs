import { o as __toESM } from "../_runtime.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { _ as Link, y as useNavigate } from "../_libs/@tanstack/react-router+[...].mjs";
import { o as require_jsx_runtime } from "../_libs/@radix-ui/react-collection+[...].mjs";
import { n as useCurrentUserState } from "./use-current-user-DG6UNzh9.mjs";
import { n as formatEdited, r as uid, t as cn } from "./utils-iXVfomyn.mjs";
import { t as Button } from "./button-L8IaURhk.mjs";
import { i as SiteHeader, n as RedirectToSignIn, r as SiteFooter } from "./chrome-CMH7kCiq.mjs";
import { a as formatUgx, r as PLANS } from "./plans-DdYzqCRR.mjs";
import { r as fetchEntitlements } from "./billing-vzNwqE81.mjs";
import { n as categoryById, t as CATEGORIES } from "./categories-CugOKuXQ.mjs";
import { i as blankCv, r as TEMPLATE_META } from "./normalize-EG92hli-.mjs";
import { c as Plus, i as Trash2, o as Sparkles, t as X, u as LoaderCircle } from "../_libs/lucide-react.mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { l as useCvStore, o as deleteDocument, s as saveDocument } from "./router-C4JLTH4Y.mjs";
import { t as Input } from "./input-BQzPFyeT.mjs";
import { n as runCvAi, t as Textarea } from "./ai-DkID1Ae2.mjs";
import { i as scoreCv } from "./score-pC17jSkT.mjs";
import { a as DialogOverlay$1, i as DialogDescription$1, n as DialogClose, o as DialogPortal$1, r as DialogContent$1, s as DialogTitle$1, t as Dialog$1 } from "../_libs/@radix-ui/react-dialog+[...].mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/studio-mcMDOYgh.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var Dialog = Dialog$1;
var DialogPortal = DialogPortal$1;
var DialogOverlay = import_react.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogOverlay$1, {
	ref,
	className: cn("fixed inset-0 z-50 bg-ink/40 data-[state=open]:animate-in data-[state=closed]:animate-out data-[state=closed]:fade-out-0 data-[state=open]:fade-in-0", className),
	...props
}));
DialogOverlay.displayName = DialogOverlay$1.displayName;
var DialogContent = import_react.forwardRef(({ className, children, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogPortal, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogOverlay, {}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogContent$1, {
	ref,
	className: cn("fixed left-1/2 top-1/2 z-50 grid w-[calc(100%-2rem)] max-w-lg -translate-x-1/2 -translate-y-1/2 gap-4 rounded-2xl border border-border bg-card p-6 shadow-[var(--shadow-border)] duration-[var(--motion-fast)] data-[state=open]:animate-in data-[state=closed]:animate-out data-[state=closed]:fade-out-0 data-[state=open]:fade-in-0 data-[state=closed]:zoom-out-95 data-[state=open]:zoom-in-95", className),
	...props,
	children: [children, /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogClose, {
		className: "absolute right-3 top-3 rounded-md p-2 text-muted hover:bg-surface hover:text-foreground",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "size-4" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "sr-only",
			children: "Close"
		})]
	})]
})] }));
DialogContent.displayName = DialogContent$1.displayName;
function DialogHeader({ className, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: cn("flex flex-col gap-1.5 text-left", className),
		...props
	});
}
var DialogTitle = import_react.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogTitle$1, {
	ref,
	className: cn("font-display text-xl font-medium tracking-tight text-foreground", className),
	...props
}));
DialogTitle.displayName = DialogTitle$1.displayName;
var DialogDescription = import_react.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogDescription$1, {
	ref,
	className: cn("text-sm text-muted", className),
	...props
}));
DialogDescription.displayName = DialogDescription$1.displayName;
function StudioPage() {
	const { user, isPending } = useCurrentUserState();
	const hydrated = useCvStore((s) => s.hydrated);
	const order = useCvStore((s) => s.order);
	const cvMap = useCvStore((s) => s.cvs);
	const cvs = order.map((id) => cvMap[id]).filter((c) => Boolean(c));
	const create = useCvStore((s) => s.create);
	const importCv = useCvStore((s) => s.importCv);
	const remove = useCvStore((s) => s.remove);
	const navigate = useNavigate();
	const [ents, setEnts] = (0, import_react.useState)(null);
	const [finishOpen, setFinishOpen] = (0, import_react.useState)(false);
	(0, import_react.useEffect)(() => {
		if (!user) return;
		fetchEntitlements().then(setEnts).catch(() => setEnts(null));
	}, [user]);
	if (isPending) return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "min-h-dvh bg-background",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SiteHeader, { compact: true }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "mx-auto grid max-w-6xl gap-4 px-4 py-12 sm:grid-cols-3 sm:px-8",
			children: [
				0,
				1,
				2
			].map((i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "h-40 animate-pulse rounded-2xl bg-surface" }, i))
		})]
	});
	if (!user) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(RedirectToSignIn, { to: "/login" });
	async function openNew() {
		const cv = create("blank");
		try {
			await saveDocument({ data: cv });
		} catch {}
		navigate({
			to: "/editor/$cvId",
			params: { cvId: cv.id }
		});
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "min-h-dvh bg-background",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SiteHeader, { compact: true }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
				className: "mx-auto max-w-6xl px-4 py-10 sm:px-8",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex flex-col gap-4 sm:flex-row sm:items-end sm:justify-between",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-xs font-medium uppercase tracking-[0.18em] text-muted",
							children: "Your studio"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
							className: "mt-2 font-display text-3xl font-medium tracking-tight",
							children: user.displayName ? `Hello, ${user.displayName.split(" ")[0]}` : "Your CVs"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "mt-2 max-w-lg text-sm text-muted",
							children: [
								"Saved on your account — not only this browser.",
								" ",
								ents ? ents.plan === "free" ? `Starter · ${cvs.length}/${ents.maxCvs} drafts` : `${PLANS[ents.plan].name} · ${formatUgx(PLANS[ents.plan].priceUgx)}` : null
							]
						})
					] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex flex-wrap gap-2",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								variant: "secondary",
								asChild: true,
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
									to: "/account",
									children: "Account"
								})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
								variant: "outline",
								onClick: () => setFinishOpen(true),
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Sparkles, {}), "Finish with AI"]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
								onClick: () => void openNew(),
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, {}), "New CV"]
							})
						]
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mt-10",
					children: !hydrated ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "grid gap-4 sm:grid-cols-2 lg:grid-cols-3",
						children: [
							0,
							1,
							2
						].map((i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "h-40 animate-pulse rounded-2xl bg-surface" }, i))
					}) : cvs.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "rounded-2xl border border-dashed border-border bg-card px-6 py-14 text-center",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "font-display text-xl",
							children: "No drafts yet"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mx-auto mt-2 max-w-md text-sm text-muted",
							children: "Start blank, or finish a complete CV from notes with AI."
						})]
					}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
						className: "grid gap-4 sm:grid-cols-2 lg:grid-cols-3",
						children: cvs.map((cv) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
							className: "rounded-2xl border border-border bg-card p-4 shadow-[var(--shadow-border)]",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
								type: "button",
								className: "w-full text-left",
								onClick: () => void navigate({
									to: "/editor/$cvId",
									params: { cvId: cv.id }
								}),
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "truncate font-display text-xl font-medium tracking-tight",
										children: cv.personal.fullName || cv.name || "Untitled"
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "mt-1 truncate text-sm text-muted",
										children: cv.personal.title || categoryById(cv.category).label
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "mt-4 flex items-center gap-2 text-xs text-subtle",
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
												className: "tabular-nums text-primary",
												children: scoreCv(cv).total
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "·" }),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: TEMPLATE_META[cv.template].label }),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "·" }),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: formatEdited(cv.updatedAt) })
										]
									})
								]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "mt-4",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
									size: "sm",
									variant: "ghost",
									onClick: () => {
										remove(cv.id);
										deleteDocument({ data: cv.id });
										toast.success("Deleted");
									},
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash2, {}), "Delete"]
								})
							})]
						}, cv.id))
					})
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(FinishDialog, {
				open: finishOpen,
				onOpenChange: setFinishOpen,
				onCreated: (cv) => {
					const stored = importCv(cv);
					saveDocument({ data: stored });
					navigate({
						to: "/editor/$cvId",
						params: { cvId: stored.id }
					});
				}
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SiteFooter, {})
		]
	});
}
function FinishDialog({ open, onOpenChange, onCreated }) {
	const navigate = useNavigate();
	const [category, setCategory] = (0, import_react.useState)("ngo");
	const [title, setTitle] = (0, import_react.useState)("");
	const [fullName, setFullName] = (0, import_react.useState)("");
	const [notes, setNotes] = (0, import_react.useState)("");
	const [busy, setBusy] = (0, import_react.useState)(false);
	async function run() {
		setBusy(true);
		try {
			const res = await runCvAi({ data: {
				task: "compose",
				notes,
				category,
				title: title.trim() || void 0,
				fullName: fullName.trim() || void 0
			} });
			if (!res.ok) {
				if ("code" in res && res.code === "upgrade") {
					toast.error(res.error);
					onOpenChange(false);
					navigate({
						to: "/checkout",
						search: { plan: "finish" }
					});
					return;
				}
				toast.error(res.error);
				return;
			}
			if (res.kind !== "compose") return;
			const c = res.compose;
			const cat = categoryById(category);
			onCreated(blankCv({
				id: uid(),
				name: `${fullName || c.title || "Finished CV"}`,
				template: cat.template,
				category,
				personal: {
					fullName: fullName || "",
					title: c.title || title,
					email: "",
					phone: "",
					location: "Kampala, Uganda",
					website: "",
					linkedin: "",
					github: "",
					nationality: "Ugandan",
					dateOfBirth: "",
					nin: "",
					gender: "",
					photoDataUrl: ""
				},
				summary: c.summary,
				experience: c.experience.map((e) => ({
					...e,
					id: uid()
				})),
				education: c.education.map((e) => ({
					...e,
					id: uid()
				})),
				skills: c.skills.map((s) => ({
					...s,
					id: uid()
				})),
				extras: c.extras.map((x) => ({
					...x,
					id: uid()
				}))
			}));
			onOpenChange(false);
			toast.success("Draft compiled — review every fact before you send it.");
		} catch {
			toast.error("Could not finish that CV");
		} finally {
			setBusy(false);
		}
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Dialog, {
		open,
		onOpenChange,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogContent, {
			className: "max-h-[90dvh] overflow-y-auto sm:max-w-lg",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogHeader, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogTitle, { children: "Finish a complete CV with AI" }) }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid gap-3 px-1 pb-2",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "text-sm text-muted",
						children: [
							"Paste your history in your own words. The compiler will not invent employers or numbers. Career Pro or a one-time Finish credit required (",
							formatUgx(PLANS.finish.priceUgx),
							")."
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
						className: "grid gap-1.5 text-sm",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-xs font-medium uppercase tracking-wide text-muted",
							children: "Category"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
							value: category,
							onChange: (e) => setCategory(e.target.value),
							className: "flex h-11 w-full rounded-lg border border-border bg-card px-3 text-sm",
							children: CATEGORIES.map((c) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
								value: c.id,
								children: c.label
							}, c.id))
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
						className: "grid gap-1.5 text-sm",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-xs font-medium uppercase tracking-wide text-muted",
							children: "Your name"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							value: fullName,
							onChange: (e) => setFullName(e.target.value),
							placeholder: "Optional"
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
						className: "grid gap-1.5 text-sm",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-xs font-medium uppercase tracking-wide text-muted",
							children: "Target title"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							value: title,
							onChange: (e) => setTitle(e.target.value),
							placeholder: "e.g. Credit Officer"
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
						className: "grid gap-1.5 text-sm",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-xs font-medium uppercase tracking-wide text-muted",
							children: "Notes"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Textarea, {
							value: notes,
							onChange: (e) => setNotes(e.target.value),
							className: "min-h-[160px]",
							placeholder: "Roles, years, schools, skills, numbers you actually have…"
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
						onClick: () => void run(),
						disabled: busy,
						children: [busy ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoaderCircle, { className: "animate-spin" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Sparkles, {}), "Compile with AI"]
					})
				]
			})]
		})
	});
}
//#endregion
export { StudioPage as component };
