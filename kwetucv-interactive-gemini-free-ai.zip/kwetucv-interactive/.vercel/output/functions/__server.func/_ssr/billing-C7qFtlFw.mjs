import { r as createServerFn } from "./ssr.mjs";
import { t as createServerRpc } from "./createServerRpc-CcvdN_gc.mjs";
import { r as getSql } from "./db-DzXWfmCK.mjs";
import { r as uid } from "./utils-iXVfomyn.mjs";
import { c as periodKey, i as entitlementsFrom, n as CHECKOUT_PLANS, o as isPaidPlan, r as PLANS, s as normaliseUgPhone, t as CHANNELS, u as ugPhoneValid } from "./plans-DdYzqCRR.mjs";
import { t as authMiddleware } from "./middleware-C_SaWK1E.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/billing-C7qFtlFw.js
async function getEntitlements(userId) {
	const sql = await getSql();
	const sub = await sql`select plan, status, period_end, finish_credits from subscriptions where user_id = ${userId}`;
	const usage = await sql`select count from ai_usage where user_id = ${userId} and period = ${periodKey()}`;
	const row = sub[0];
	return entitlementsFrom({
		plan: row?.plan ?? "free",
		status: row?.status ?? "none",
		periodEnd: row?.period_end == null ? null : Number(row.period_end),
		finishCredits: Number(row?.finish_credits ?? 0),
		aiUsed: Number(usage[0]?.count ?? 0)
	});
}
var fetchEntitlements_createServerFn_handler = createServerRpc({
	id: "9db33cac680b62ca3e5fb41a9570cc80388392f38d4f46f762ac3f7035917496",
	name: "fetchEntitlements",
	filename: "src/lib/data/billing.ts"
}, (opts) => fetchEntitlements.__executeServer(opts));
var fetchEntitlements = createServerFn({ method: "GET" }).middleware([authMiddleware]).handler(fetchEntitlements_createServerFn_handler, async ({ context }) => getEntitlements(context.userId));
var listPayments_createServerFn_handler = createServerRpc({
	id: "63954ccf0902e0af77adf7d2d4e804fd336b7e7c451f2bbdc8b48b536ff76a1f",
	name: "listPayments",
	filename: "src/lib/data/billing.ts"
}, (opts) => listPayments.__executeServer(opts));
var listPayments = createServerFn({ method: "GET" }).middleware([authMiddleware]).handler(listPayments_createServerFn_handler, async ({ context }) => {
	return (await getSql())`select id, plan, amount_ugx, channel, phone, status, created_at from payments where user_id = ${context.userId} order by created_at desc limit 20`;
});
var completeCheckout_createServerFn_handler = createServerRpc({
	id: "8bda1e852f26bea0ff867e864479d639e711437188779e533105c1aea4e2fb3e",
	name: "completeCheckout",
	filename: "src/lib/data/billing.ts"
}, (opts) => completeCheckout.__executeServer(opts));
var completeCheckout = createServerFn({ method: "POST" }).validator((input) => input).middleware([authMiddleware]).handler(completeCheckout_createServerFn_handler, async ({ context, data }) => {
	if (!CHECKOUT_PLANS.includes(data.plan)) return {
		ok: false,
		error: "Unknown plan"
	};
	const channel = CHANNELS.find((c) => c.id === data.channel);
	if (!channel) return {
		ok: false,
		error: "Choose a payment channel"
	};
	let phone = null;
	if (channel.kind === "momo") {
		const raw = data.phone?.trim() ?? "";
		if (!ugPhoneValid(raw)) return {
			ok: false,
			error: "Enter a valid Ugandan mobile number"
		};
		phone = normaliseUgPhone(raw);
	}
	const plan = PLANS[data.plan];
	const now = Date.now();
	const paymentId = uid();
	const sql = await getSql();
	await sql`insert into payments (id, user_id, plan, amount_ugx, channel, phone, status, created_at) values (${paymentId}, ${context.userId}, ${plan.id}, ${plan.priceUgx}, ${channel.id}, ${phone}, ${"paid"}, ${now})`;
	const current = await sql`select plan, finish_credits, period_end from subscriptions where user_id = ${context.userId}`;
	const finishCredits = data.plan === "finish" ? Number(current[0]?.finish_credits ?? 0) + 1 : Number(current[0]?.finish_credits ?? 0);
	let nextPlan = current[0]?.plan ?? "free";
	let periodEnd = current[0]?.period_end == null ? null : Number(current[0].period_end);
	let status = "active";
	if (data.plan === "writer") {
		nextPlan = "writer";
		periodEnd = now + 2592e6;
	} else if (data.plan === "pro") {
		nextPlan = "pro";
		periodEnd = now + 2592e6;
	} else if (data.plan === "pro_year") {
		nextPlan = "pro_year";
		periodEnd = now + 31536e6;
	} else if (!isPaidPlan(nextPlan)) {
		nextPlan = "free";
		status = "active";
	}
	await sql`insert into subscriptions (user_id, plan, status, period_end, finish_credits, channel, updated_at)
      values (${context.userId}, ${nextPlan}, ${status}, ${periodEnd}, ${finishCredits}, ${channel.id}, ${now})
      on conflict (user_id) do update set
        plan = excluded.plan,
        status = excluded.status,
        period_end = excluded.period_end,
        finish_credits = excluded.finish_credits,
        channel = excluded.channel,
        updated_at = excluded.updated_at`;
	return {
		ok: true,
		paymentId,
		entitlements: await getEntitlements(context.userId)
	};
});
//#endregion
export { completeCheckout_createServerFn_handler, fetchEntitlements_createServerFn_handler, listPayments_createServerFn_handler };
