import { o as __toESM } from "../_runtime.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { _ as Link, y as useNavigate } from "../_libs/@tanstack/react-router+[...].mjs";
import { o as require_jsx_runtime } from "../_libs/@radix-ui/react-collection+[...].mjs";
import { n as useCurrentUserState } from "./use-current-user-DG6UNzh9.mjs";
import { t as cva } from "../_libs/class-variance-authority+clsx.mjs";
import { r as uid, t as cn } from "./utils-iXVfomyn.mjs";
import { n as Wordmark, t as Button } from "./button-L8IaURhk.mjs";
import { n as RedirectToSignIn, t as AuthSlot } from "./chrome-CMH7kCiq.mjs";
import { t as CATEGORIES } from "./categories-CugOKuXQ.mjs";
import { n as TEMPLATES, r as TEMPLATE_META, t as SECTIONS } from "./normalize-EG92hli-.mjs";
import { a as Target, c as Plus, d as Eye, f as Ellipsis, i as Trash2, l as PenLine, m as ArrowLeft, n as Upload, o as Sparkles, p as Download, s as Printer, t as X, u as LoaderCircle } from "../_libs/lucide-react.mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { a as useCvAutosave, c as useCv, l as useCvStore, n as Route$1, o as deleteDocument } from "./router-C4JLTH4Y.mjs";
import { t as Input } from "./input-BQzPFyeT.mjs";
import { n as runCvAi, t as Textarea } from "./ai-DkID1Ae2.mjs";
import { i as scoreCv, n as lintBullet } from "./score-pC17jSkT.mjs";
import { a as DialogOverlay, i as DialogDescription, n as DialogClose, o as DialogPortal, r as DialogContent, s as DialogTitle, t as Dialog } from "../_libs/@radix-ui/react-dialog+[...].mjs";
import { t as Label } from "./label-CplLAFh6.mjs";
import { n as CvStage, t as CvDocument } from "./preview-DcWSYbBA.mjs";
import { a as Root2, i as Portal2, n as Item2, o as Separator2, r as Label2, s as Trigger, t as Content2 } from "../_libs/@radix-ui/react-dropdown-menu+[...].mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/editor._cvId-RPnnuTOH.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var badgeVariants = cva("inline-flex items-center rounded-full border px-2.5 py-0.5 text-xs font-medium", {
	variants: { variant: {
		default: "border-transparent bg-primary text-primary-foreground",
		secondary: "border-border bg-surface text-muted",
		outline: "border-border text-foreground",
		good: "border-transparent bg-primary/12 text-primary",
		warn: "border-transparent bg-warn/15 text-warn",
		danger: "border-transparent bg-danger/12 text-danger"
	} },
	defaultVariants: { variant: "secondary" }
});
function Badge({ className, variant, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: cn(badgeVariants({ variant }), className),
		...props
	});
}
function ScoreRing({ value }) {
	const r = 26;
	const c = 2 * Math.PI * r;
	const off = c * (1 - Math.max(0, Math.min(100, value)) / 100);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "relative size-[76px] shrink-0",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("svg", {
			viewBox: "0 0 72 72",
			className: "size-full -rotate-90",
			"aria-hidden": "true",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
				cx: "36",
				cy: "36",
				r,
				fill: "none",
				stroke: "var(--color-border)",
				strokeWidth: "6"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
				cx: "36",
				cy: "36",
				r,
				fill: "none",
				stroke: "var(--color-primary)",
				strokeWidth: "6",
				strokeDasharray: c,
				strokeDashoffset: off,
				strokeLinecap: "round"
			})]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "absolute inset-0 flex items-center justify-center font-display text-lg font-medium tabular-nums text-foreground",
			children: value
		})]
	});
}
function CoachPanel({ cv }) {
	const navigate = useNavigate();
	const score = (0, import_react.useMemo)(() => scoreCv(cv), [cv]);
	const update = useCvStore((s) => s.update);
	const [job, setJob] = (0, import_react.useState)("");
	const [busy, setBusy] = (0, import_react.useState)(null);
	const [review, setReview] = (0, import_react.useState)(null);
	const [tailor, setTailor] = (0, import_react.useState)(null);
	const meta = TEMPLATE_META[cv.template];
	function onFail(res) {
		if (res.code === "upgrade") {
			toast.error(res.error);
			navigate({ to: "/pricing" });
			return;
		}
		toast.error(res.error);
	}
	async function reviewCv() {
		setBusy("review");
		try {
			const res = await runCvAi({ data: {
				task: "review",
				cv,
				job: job.trim() || void 0
			} });
			if (!res.ok) {
				onFail(res);
				return;
			}
			if (res.kind !== "review") {
				toast.error("Unexpected response");
				return;
			}
			setReview(res.review);
		} catch {
			toast.error("Review failed. Try again.");
		} finally {
			setBusy(null);
		}
	}
	async function tailorCv() {
		if (!job.trim()) {
			toast.error("Paste a job description to tailor against.");
			return;
		}
		setBusy("tailor");
		try {
			const res = await runCvAi({ data: {
				task: "tailor",
				cv,
				job: job.trim()
			} });
			if (!res.ok) {
				onFail(res);
				return;
			}
			if (res.kind !== "tailor") {
				toast.error("Unexpected response");
				return;
			}
			setTailor(res.tailor);
		} catch {
			toast.error("Tailor failed. Try again.");
		} finally {
			setBusy(null);
		}
	}
	function applySummary(text) {
		update(cv.id, (cur) => ({
			...cur,
			summary: text
		}));
		toast.success("Summary updated");
	}
	function applyBullet(id, index, suggested) {
		update(cv.id, (cur) => ({
			...cur,
			experience: cur.experience.map((e) => e.id === id ? {
				...e,
				bullets: e.bullets.map((b, i) => i === index ? suggested : b)
			} : e)
		}));
		toast.success("Bullet updated");
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex flex-col gap-6",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-center gap-4 rounded-2xl bg-surface p-4",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ScoreRing, { value: score.total }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "min-w-0",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-sm font-medium text-foreground",
							children: "Writing score"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-sm text-muted",
							children: score.bulletIssues ? `${score.bulletIssues} bullet ${score.bulletIssues === 1 ? "note" : "notes"} to tighten` : "Bullets look disciplined"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "mt-1 text-xs text-subtle",
							children: [
								meta.label,
								" · ",
								meta.ats ? "ATS-safer single column" : "Visual two-column — export Official or Editorial for ATS"
							]
						})
					]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "space-y-2",
				children: score.parts.map((part) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mb-1 flex items-center justify-between gap-2 text-xs",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "font-medium text-foreground",
							children: part.label
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "tabular-nums text-muted",
							children: [
								part.score,
								"/",
								part.max
							]
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "h-1.5 overflow-hidden rounded-full bg-border",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "h-full rounded-full bg-primary transition-[width] duration-[var(--motion-fast)]",
							style: { width: `${part.score / part.max * 100}%` }
						})
					}),
					part.hints[0] ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-1 text-xs text-muted",
						children: part.hints[0]
					}) : null
				] }, part.id))
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "space-y-2",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm font-medium",
						children: "Target a role"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Textarea, {
						value: job,
						onChange: (e) => setJob(e.target.value),
						placeholder: "Paste a job description from BrighterMonday, a ministry circular, or an NGO advert. We retarget wording — we do not invent experience.",
						className: "min-h-[120px]"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex flex-col gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
							onClick: () => void reviewCv(),
							disabled: busy !== null,
							className: "w-full",
							children: [busy === "review" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoaderCircle, { className: "animate-spin" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Sparkles, {}), "Review with AI"]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
							variant: "secondary",
							onClick: () => void tailorCv(),
							disabled: busy !== null,
							className: "w-full",
							children: [busy === "tailor" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoaderCircle, { className: "animate-spin" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Target, {}), "Tailor wording"]
						})]
					})
				]
			}),
			review ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "space-y-3 rounded-2xl border border-border bg-card p-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center justify-between gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-sm font-medium",
							children: "AI review"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
							variant: "good",
							className: "tabular-nums",
							children: review.score
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm text-muted",
						children: review.summary
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
						className: "space-y-2",
						children: review.issues.map((issue, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
							className: "rounded-xl bg-surface p-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "mb-1 flex items-center gap-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
									variant: issue.severity === "high" ? "danger" : issue.severity === "med" ? "warn" : "secondary",
									children: issue.severity
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-sm font-medium",
									children: issue.title
								})]
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-sm text-muted",
								children: issue.fix
							})]
						}, i))
					})
				]
			}) : null,
			tailor ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "space-y-3 rounded-2xl border border-border bg-card p-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm font-medium",
						children: "Suggested retarget"
					}),
					tailor.note ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm text-muted",
						children: tailor.note
					}) : null,
					tailor.summary ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "rounded-xl bg-surface p-3",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mb-2 text-xs font-medium uppercase tracking-wide text-subtle",
								children: "Summary"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-sm",
								children: tailor.summary
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								size: "sm",
								className: "mt-3",
								onClick: () => applySummary(tailor.summary),
								children: "Apply summary"
							})
						]
					}) : null,
					tailor.bullets.map((b, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "rounded-xl bg-surface p-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-sm",
							children: b.suggested
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							size: "sm",
							variant: "secondary",
							className: "mt-3",
							onClick: () => applyBullet(b.id, b.index, b.suggested),
							children: "Apply bullet"
						})]
					}, `${b.id}-${b.index}-${i}`))
				]
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: cn("text-xs text-subtle"),
				children: "AI runs only when you press a button. Drafts are saved to your KwetuCV account."
			})
		]
	});
}
async function compressImageFile(file, maxEdge = 640, quality = .82) {
	if (!file.type.startsWith("image/")) throw new Error("Please choose a photo or a scan of your ID.");
	if (file.size > 8388608) throw new Error("That file is larger than 8 MB.");
	const bitmap = await createImageBitmap(file);
	const scale = Math.min(1, maxEdge / Math.max(bitmap.width, bitmap.height));
	const w = Math.max(1, Math.round(bitmap.width * scale));
	const h = Math.max(1, Math.round(bitmap.height * scale));
	const canvas = document.createElement("canvas");
	canvas.width = w;
	canvas.height = h;
	const ctx = canvas.getContext("2d");
	if (!ctx) throw new Error("Could not read that image.");
	ctx.drawImage(bitmap, 0, 0, w, h);
	bitmap.close();
	const dataUrl = canvas.toDataURL("image/jpeg", quality);
	if (dataUrl.length > 35e4) return canvas.toDataURL("image/jpeg", .7);
	return dataUrl;
}
function Field({ label, children, className }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
		className: cn("grid gap-1.5", className),
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "text-xs font-medium uppercase tracking-wide text-muted",
			children: label
		}), children]
	});
}
function Block({ title, action, children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "rounded-2xl border border-border bg-card p-4 shadow-[var(--shadow-border)] sm:p-5",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mb-4 flex items-center justify-between gap-3",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "font-display text-lg font-medium tracking-tight",
				children: title
			}), action]
		}), children]
	});
}
function useUpgrade() {
	const navigate = useNavigate();
	return (message) => {
		toast.error(message || "This AI tool is on Writer and Career Pro.");
		navigate({ to: "/pricing" });
	};
}
function ImproveButton({ text, role, company, onApply }) {
	const [busy, setBusy] = (0, import_react.useState)(false);
	const upgrade = useUpgrade();
	async function run() {
		if (!text.trim()) {
			toast.error("Write a draft first.");
			return;
		}
		setBusy(true);
		try {
			const res = await runCvAi({ data: {
				task: "rewrite",
				text,
				role,
				company
			} });
			if (!res.ok) {
				if ("code" in res && res.code === "upgrade") upgrade(res.error);
				else toast.error(res.error);
				return;
			}
			if (res.kind !== "rewrite") {
				toast.error("Unexpected response");
				return;
			}
			onApply(res.text);
			toast.success("Rewritten");
		} catch {
			toast.error("Rewrite failed");
		} finally {
			setBusy(false);
		}
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
		type: "button",
		size: "sm",
		variant: "ghost",
		onClick: () => void run(),
		disabled: busy,
		children: [busy ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoaderCircle, { className: "animate-spin" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Sparkles, {}), "Improve"]
	});
}
function EditorForm({ cv, section }) {
	const update = useCvStore((s) => s.update);
	const set = (patch) => update(cv.id, patch);
	if (section === "profile") return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ProfileForm, {
		cv,
		set
	});
	if (section === "summary") {
		const count = cv.summary.trim() ? cv.summary.trim().split(/\s+/).length : 0;
		return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Block, {
			title: "Career objective",
			action: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ImproveButton, {
				text: cv.summary,
				role: cv.personal.title,
				onApply: (text) => set((cur) => ({
					...cur,
					summary: text
				}))
			}),
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Textarea, {
				value: cv.summary,
				onChange: (e) => set((cur) => ({
					...cur,
					summary: e.target.value
				})),
				className: "min-h-[160px]",
				placeholder: "Three sentences: who you are, the scale you operate at, the proof — written for a Ugandan hiring panel."
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-2 flex items-center justify-between text-xs text-muted",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
					className: "tabular-nums",
					children: [count, " words · aim 40–90"]
				}), /\bI\b|\bmy\b/i.test(cv.summary) ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: "Drop “I” and “my”." }) : null]
			})]
		});
	}
	if (section === "experience") return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-4",
		children: [cv.experience.map((item, idx) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ExperienceCard, {
			item,
			index: idx,
			onChange: (next) => set((cur) => ({
				...cur,
				experience: cur.experience.map((e) => e.id === item.id ? next : e)
			})),
			onRemove: () => set((cur) => ({
				...cur,
				experience: cur.experience.filter((e) => e.id !== item.id)
			}))
		}, item.id)), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
			variant: "secondary",
			className: "w-full",
			onClick: () => set((cur) => ({
				...cur,
				experience: [...cur.experience, {
					id: uid(),
					company: "",
					role: "",
					location: "",
					start: "",
					end: "",
					current: false,
					bullets: ["", ""]
				}]
			})),
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, {}), "Add role"]
		})]
	});
	if (section === "education") return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-4",
		children: [cv.education.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Block, {
			title: item.school || "School",
			action: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				size: "icon-sm",
				variant: "ghost",
				onClick: () => set((cur) => ({
					...cur,
					education: cur.education.filter((e) => e.id !== item.id)
				})),
				"aria-label": "Remove school",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash2, {})
			}),
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(EduFields, {
				item,
				onChange: (next) => set((cur) => ({
					...cur,
					education: cur.education.map((e) => e.id === item.id ? next : e)
				}))
			})
		}, item.id)), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
			variant: "secondary",
			className: "w-full",
			onClick: () => set((cur) => ({
				...cur,
				education: [...cur.education, {
					id: uid(),
					school: "",
					degree: "",
					field: "",
					start: "",
					end: "",
					details: ""
				}]
			})),
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, {}), "Add school"]
		})]
	});
	if (section === "skills") return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-4",
		children: [cv.skills.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Block, {
			title: item.category || "Group",
			action: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				size: "icon-sm",
				variant: "ghost",
				"aria-label": "Remove skill group",
				onClick: () => set((cur) => ({
					...cur,
					skills: cur.skills.filter((s) => s.id !== item.id)
				})),
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash2, {})
			}),
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SkillFields, {
				item,
				onChange: (next) => set((cur) => ({
					...cur,
					skills: cur.skills.map((s) => s.id === item.id ? next : s)
				}))
			})
		}, item.id)), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
			variant: "secondary",
			className: "w-full",
			onClick: () => set((cur) => ({
				...cur,
				skills: [...cur.skills, {
					id: uid(),
					category: "",
					items: ""
				}]
			})),
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, {}), "Add skill group"]
		})]
	});
	if (section === "letter") return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LetterForm, {
		cv,
		set
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(MoreForm, {
		cv,
		set
	});
}
function ProfileForm({ cv, set }) {
	const p = cv.personal;
	const setP = (key, value) => set((cur) => ({
		...cur,
		personal: {
			...cur.personal,
			[key]: value
		}
	}));
	const photoRef = (0, import_react.useRef)(null);
	const idRef = (0, import_react.useRef)(null);
	const [scanBusy, setScanBusy] = (0, import_react.useState)(false);
	const upgrade = useUpgrade();
	async function onPhoto(file) {
		try {
			const data = await compressImageFile(file, 480, .84);
			setP("photoDataUrl", data);
			toast.success("Photo added");
		} catch (err) {
			toast.error(err instanceof Error ? err.message : "Could not read that photo");
		}
	}
	async function onId(file) {
		setScanBusy(true);
		try {
			const data = await compressImageFile(file, 900, .78);
			if (!p.photoDataUrl) setP("photoDataUrl", data);
			const res = await runCvAi({ data: {
				task: "scan",
				image: data
			} });
			if (!res.ok) {
				if ("code" in res && res.code === "upgrade") upgrade(res.error);
				else toast.error(res.error);
				return;
			}
			if (res.kind !== "scan") return;
			const s = res.scan;
			if (s.fullName.startsWith("Not an ID")) {
				toast.error("That does not look like a National ID or passport.");
				return;
			}
			set((cur) => ({
				...cur,
				personal: {
					...cur.personal,
					fullName: s.fullName || cur.personal.fullName,
					dateOfBirth: s.dateOfBirth || cur.personal.dateOfBirth,
					nin: s.nin || cur.personal.nin,
					nationality: s.nationality || cur.personal.nationality,
					gender: s.gender || cur.personal.gender,
					photoDataUrl: cur.personal.photoDataUrl || data
				}
			}));
			toast.success("Details copied from the ID. Check every field.");
		} catch {
			toast.error("Could not read that ID");
		} finally {
			setScanBusy(false);
		}
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-4",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Block, {
			title: "Portrait & identity",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-col gap-4 sm:flex-row",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex shrink-0 flex-col items-center gap-2",
					children: [
						p.photoDataUrl ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
							src: p.photoDataUrl,
							alt: "Passport photo",
							className: "h-[132px] w-[108px] rounded-md object-cover shadow-[var(--shadow-border)]"
						}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "grid h-[132px] w-[108px] place-items-center rounded-md bg-surface text-center text-xs text-muted",
							children: "Passport photo"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							ref: photoRef,
							type: "file",
							accept: "image/*",
							className: "hidden",
							onChange: (e) => {
								const file = e.target.files?.[0];
								if (file) onPhoto(file);
								e.target.value = "";
							}
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
							size: "sm",
							variant: "secondary",
							onClick: () => photoRef.current?.click(),
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Upload, {}), "Photo"]
						})
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "min-w-0 flex-1 space-y-3",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-sm text-muted",
							children: "Ugandan public-service and NGO applications usually want a passport-style photo. You can also import a photo of your National ID — we copy name, NIN, and date of birth for you to confirm."
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							ref: idRef,
							type: "file",
							accept: "image/*",
							className: "hidden",
							onChange: (e) => {
								const file = e.target.files?.[0];
								if (file) onId(file);
								e.target.value = "";
							}
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
							variant: "outline",
							onClick: () => idRef.current?.click(),
							disabled: scanBusy,
							children: [scanBusy ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoaderCircle, { className: "animate-spin" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Upload, {}), "Import National ID"]
						})
					]
				})]
			})
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Block, {
			title: "Profile",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid gap-3 sm:grid-cols-2",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Full name",
						className: "sm:col-span-2",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							value: p.fullName,
							onChange: (e) => setP("fullName", e.target.value),
							placeholder: "Namukasa Rebecca"
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Target title",
						className: "sm:col-span-2",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							value: p.title,
							onChange: (e) => setP("title", e.target.value),
							placeholder: "Monitoring & Evaluation Officer"
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Category",
						className: "sm:col-span-2",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("select", {
							value: cv.category,
							onChange: (e) => set((cur) => ({
								...cur,
								category: e.target.value
							})),
							className: "flex h-11 w-full rounded-lg border border-border bg-card px-3 text-sm text-foreground shadow-[var(--shadow-border)]",
							children: CATEGORIES.map((c) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("option", {
								value: c.id,
								children: c.label
							}, c.id))
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Email",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							value: p.email,
							onChange: (e) => setP("email", e.target.value),
							placeholder: "you@email.com"
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Phone",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							value: p.phone,
							onChange: (e) => setP("phone", e.target.value),
							placeholder: "+256 772 …"
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Location",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							value: p.location,
							onChange: (e) => setP("location", e.target.value),
							placeholder: "Kampala, Uganda"
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Nationality",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							value: p.nationality,
							onChange: (e) => setP("nationality", e.target.value),
							placeholder: "Ugandan"
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Date of birth",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							value: p.dateOfBirth,
							onChange: (e) => setP("dateOfBirth", e.target.value),
							placeholder: "12 March 1994"
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Sex",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							value: p.gender,
							onChange: (e) => setP("gender", e.target.value),
							placeholder: "Optional"
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "National ID (NIN)",
						className: "sm:col-span-2",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							value: p.nin,
							onChange: (e) => setP("nin", e.target.value),
							placeholder: "As printed on the card — only if the advert asks"
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "LinkedIn",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							value: p.linkedin,
							onChange: (e) => setP("linkedin", e.target.value),
							placeholder: "linkedin.com/in/…"
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Website",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							value: p.website,
							onChange: (e) => setP("website", e.target.value),
							placeholder: "Optional"
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Draft name",
						className: "sm:col-span-2",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							value: cv.name,
							onChange: (e) => set((cur) => ({
								...cur,
								name: e.target.value
							})),
							placeholder: "Internal name for this draft"
						})
					})
				]
			})
		})]
	});
}
function LetterForm({ cv, set }) {
	const [job, setJob] = (0, import_react.useState)("");
	const [busy, setBusy] = (0, import_react.useState)(false);
	const upgrade = useUpgrade();
	async function write() {
		if (!job.trim()) {
			toast.error("Paste the job advert first.");
			return;
		}
		setBusy(true);
		try {
			const res = await runCvAi({ data: {
				task: "letter",
				cv,
				job: job.trim()
			} });
			if (!res.ok) {
				if ("code" in res && res.code === "upgrade") upgrade(res.error);
				else toast.error(res.error);
				return;
			}
			if (res.kind !== "letter") return;
			set((cur) => ({
				...cur,
				coverLetter: res.text
			}));
			toast.success("Cover letter drafted");
		} catch {
			toast.error("Could not write the letter");
		} finally {
			setBusy(false);
		}
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-4",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Block, {
			title: "Job advert",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Textarea, {
				value: job,
				onChange: (e) => setJob(e.target.value),
				className: "min-h-[120px]",
				placeholder: "Paste the advert. Career Pro writes a one-page letter from your CV — it will not invent experience."
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
				className: "mt-3",
				onClick: () => void write(),
				disabled: busy,
				children: [busy ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoaderCircle, { className: "animate-spin" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Sparkles, {}), "Write cover letter"]
			})]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Block, {
			title: "Letter",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Textarea, {
				value: cv.coverLetter,
				onChange: (e) => set((cur) => ({
					...cur,
					coverLetter: e.target.value
				})),
				className: "min-h-[280px]",
				placeholder: "The compiled letter prints after your CV."
			})
		})]
	});
}
function MoreForm({ cv, set }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-6",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "space-y-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "font-display text-xl font-medium",
						children: "Referees"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm text-muted",
						children: "Two named referees with a phone number is the Ugandan default."
					}),
					cv.referees.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Block, {
						title: item.name || "Referee",
						action: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							size: "icon-sm",
							variant: "ghost",
							"aria-label": "Remove referee",
							onClick: () => set((cur) => ({
								...cur,
								referees: cur.referees.filter((r) => r.id !== item.id)
							})),
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash2, {})
						}),
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(RefereeFields, {
							item,
							onChange: (next) => set((cur) => ({
								...cur,
								referees: cur.referees.map((r) => r.id === item.id ? next : r)
							}))
						})
					}, item.id)),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
						variant: "secondary",
						className: "w-full",
						onClick: () => set((cur) => ({
							...cur,
							referees: [...cur.referees, {
								id: uid(),
								name: "",
								title: "",
								organisation: "",
								phone: "",
								email: ""
							}]
						})),
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, {}), "Add referee"]
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "space-y-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "font-display text-xl font-medium",
						children: "Projects"
					}),
					cv.projects.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Block, {
						title: item.name || "Project",
						action: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							size: "icon-sm",
							variant: "ghost",
							"aria-label": "Remove project",
							onClick: () => set((cur) => ({
								...cur,
								projects: cur.projects.filter((p) => p.id !== item.id)
							})),
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash2, {})
						}),
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ProjectFields, {
							item,
							onChange: (next) => set((cur) => ({
								...cur,
								projects: cur.projects.map((p) => p.id === item.id ? next : p)
							}))
						})
					}, item.id)),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
						variant: "secondary",
						className: "w-full",
						onClick: () => set((cur) => ({
							...cur,
							projects: [...cur.projects, {
								id: uid(),
								name: "",
								url: "",
								summary: "",
								bullets: [""]
							}]
						})),
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, {}), "Add project"]
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "space-y-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "font-display text-xl font-medium",
						children: "Additional"
					}),
					cv.extras.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "grid gap-3 rounded-2xl border border-border bg-card p-4 sm:grid-cols-[1fr_2fr_auto]",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								value: item.label,
								placeholder: "Label",
								onChange: (e) => set((cur) => ({
									...cur,
									extras: cur.extras.map((x) => x.id === item.id ? {
										...x,
										label: e.target.value
									} : x)
								}))
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								value: item.value,
								placeholder: "Value",
								onChange: (e) => set((cur) => ({
									...cur,
									extras: cur.extras.map((x) => x.id === item.id ? {
										...x,
										value: e.target.value
									} : x)
								}))
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								size: "icon",
								variant: "ghost",
								"aria-label": "Remove",
								onClick: () => set((cur) => ({
									...cur,
									extras: cur.extras.filter((x) => x.id !== item.id)
								})),
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash2, {})
							})
						]
					}, item.id)),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
						variant: "secondary",
						className: "w-full",
						onClick: () => set((cur) => ({
							...cur,
							extras: [...cur.extras, {
								id: uid(),
								label: "",
								value: ""
							}]
						})),
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, {}), "Add line"]
					})
				]
			})
		]
	});
}
function ExperienceCard({ item, index, onChange, onRemove }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Block, {
		title: item.role || item.company || `Role ${index + 1}`,
		action: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
			size: "icon-sm",
			variant: "ghost",
			onClick: onRemove,
			"aria-label": "Remove role",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash2, {})
		}),
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "grid gap-3 sm:grid-cols-2",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "Role",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
						value: item.role,
						onChange: (e) => onChange({
							...item,
							role: e.target.value
						})
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "Organisation",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
						value: item.company,
						onChange: (e) => onChange({
							...item,
							company: e.target.value
						})
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "Location",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
						value: item.location,
						onChange: (e) => onChange({
							...item,
							location: e.target.value
						})
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "grid grid-cols-[1fr_1fr_auto] items-end gap-2",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							label: "Start",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								value: item.start,
								onChange: (e) => onChange({
									...item,
									start: e.target.value
								}),
								placeholder: "2022"
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							label: "End",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								value: item.end,
								onChange: (e) => onChange({
									...item,
									end: e.target.value
								}),
								placeholder: "2024",
								disabled: item.current
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
							className: "flex h-11 items-center gap-2 text-sm text-muted",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
								type: "checkbox",
								checked: item.current,
								onChange: (e) => onChange({
									...item,
									current: e.target.checked,
									end: e.target.checked ? "" : item.end
								}),
								className: "size-4 accent-[var(--color-primary)]"
							}), "Now"]
						})
					]
				})
			]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mt-4 space-y-3",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, {
					className: "text-xs uppercase tracking-wide text-muted",
					children: "Bullets"
				}),
				item.bullets.map((b, i) => {
					const issues = lintBullet(b);
					return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "space-y-1.5",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-start gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Textarea, {
								value: b,
								className: "min-h-[76px]",
								onChange: (e) => {
									const bullets = [...item.bullets];
									bullets[i] = e.target.value;
									onChange({
										...item,
										bullets
									});
								},
								placeholder: "Led … resulting in …"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex flex-col gap-1",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ImproveButton, {
									text: b,
									role: item.role,
									company: item.company,
									onApply: (text) => {
										const bullets = [...item.bullets];
										bullets[i] = text;
										onChange({
											...item,
											bullets
										});
									}
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
									size: "icon-sm",
									variant: "ghost",
									"aria-label": "Remove bullet",
									onClick: () => onChange({
										...item,
										bullets: item.bullets.filter((_, j) => j !== i)
									}),
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash2, {})
								})]
							})]
						}), b.trim() && issues[0] ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-xs text-warn",
							children: issues[0].hint
						}) : b.trim() ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-xs text-primary",
							children: "Tight."
						}) : null]
					}, i);
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
					size: "sm",
					variant: "outline",
					onClick: () => onChange({
						...item,
						bullets: [...item.bullets, ""]
					}),
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, {}), "Add bullet"]
				})
			]
		})]
	});
}
function EduFields({ item, onChange }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "grid gap-3 sm:grid-cols-2",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
				label: "School",
				className: "sm:col-span-2",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
					value: item.school,
					onChange: (e) => onChange({
						...item,
						school: e.target.value
					}),
					placeholder: "Makerere University"
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
				label: "Degree",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
					value: item.degree,
					onChange: (e) => onChange({
						...item,
						degree: e.target.value
					}),
					placeholder: "B.A."
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
				label: "Field",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
					value: item.field,
					onChange: (e) => onChange({
						...item,
						field: e.target.value
					})
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
				label: "Start",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
					value: item.start,
					onChange: (e) => onChange({
						...item,
						start: e.target.value
					})
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
				label: "End",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
					value: item.end,
					onChange: (e) => onChange({
						...item,
						end: e.target.value
					})
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
				label: "Note",
				className: "sm:col-span-2",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
					value: item.details,
					onChange: (e) => onChange({
						...item,
						details: e.target.value
					}),
					placeholder: "Class, dissertation, licence"
				})
			})
		]
	});
}
function ProjectFields({ item, onChange }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "grid gap-3",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid gap-3 sm:grid-cols-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "Name",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
						value: item.name,
						onChange: (e) => onChange({
							...item,
							name: e.target.value
						})
					})
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
					label: "URL",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
						value: item.url,
						onChange: (e) => onChange({
							...item,
							url: e.target.value
						})
					})
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
				label: "One line",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
					value: item.summary,
					onChange: (e) => onChange({
						...item,
						summary: e.target.value
					})
				})
			}),
			item.bullets.map((b, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Textarea, {
				value: b,
				className: "min-h-[68px]",
				placeholder: "Impact",
				onChange: (e) => {
					const bullets = [...item.bullets];
					bullets[i] = e.target.value;
					onChange({
						...item,
						bullets
					});
				}
			}, i)),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
				size: "sm",
				variant: "outline",
				onClick: () => onChange({
					...item,
					bullets: [...item.bullets, ""]
				}),
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, {}), "Add bullet"]
			})
		]
	});
}
function SkillFields({ item, onChange }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "grid gap-3",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
			label: "Category",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
				value: item.category,
				onChange: (e) => onChange({
					...item,
					category: e.target.value
				}),
				placeholder: "MEAL, Languages, Computer packages"
			})
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
			label: "Items",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Textarea, {
				value: item.items,
				className: "min-h-[80px]",
				onChange: (e) => onChange({
					...item,
					items: e.target.value
				}),
				placeholder: "Comma-separated"
			})
		})]
	});
}
function RefereeFields({ item, onChange }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "grid gap-3 sm:grid-cols-2",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
				label: "Name",
				className: "sm:col-span-2",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
					value: item.name,
					onChange: (e) => onChange({
						...item,
						name: e.target.value
					})
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
				label: "Title",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
					value: item.title,
					onChange: (e) => onChange({
						...item,
						title: e.target.value
					})
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
				label: "Organisation",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
					value: item.organisation,
					onChange: (e) => onChange({
						...item,
						organisation: e.target.value
					})
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
				label: "Phone",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
					value: item.phone,
					onChange: (e) => onChange({
						...item,
						phone: e.target.value
					}),
					placeholder: "+256 …"
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
				label: "Email",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
					value: item.email,
					onChange: (e) => onChange({
						...item,
						email: e.target.value
					})
				})
			})
		]
	});
}
var DropdownMenu = Root2;
var DropdownMenuTrigger = Trigger;
var DropdownMenuContent = import_react.forwardRef(({ className, sideOffset = 6, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Portal2, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Content2, {
	ref,
	sideOffset,
	className: cn("z-50 min-w-44 overflow-hidden rounded-xl border border-border bg-card p-1 text-foreground shadow-[var(--shadow-border)]", className),
	...props
}) }));
DropdownMenuContent.displayName = Content2.displayName;
var DropdownMenuItem = import_react.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Item2, {
	ref,
	className: cn("flex cursor-pointer select-none items-center gap-2 rounded-lg px-3 py-2 text-sm outline-none focus:bg-surface data-[disabled]:pointer-events-none data-[disabled]:opacity-40", className),
	...props
}));
DropdownMenuItem.displayName = Item2.displayName;
var DropdownMenuSeparator = import_react.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Separator2, {
	ref,
	className: cn("-mx-1 my-1 h-px bg-border", className),
	...props
}));
DropdownMenuSeparator.displayName = Separator2.displayName;
var DropdownMenuLabel = import_react.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label2, {
	ref,
	className: cn("px-3 py-1.5 text-xs font-medium text-muted", className),
	...props
}));
DropdownMenuLabel.displayName = Label2.displayName;
var Sheet = Dialog;
var SheetPortal = DialogPortal;
var SheetOverlay = import_react.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogOverlay, {
	ref,
	className: cn("fixed inset-0 z-50 bg-ink/40", className),
	...props
}));
SheetOverlay.displayName = DialogOverlay.displayName;
var SheetContent = import_react.forwardRef(({ className, children, side = "right", ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SheetPortal, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SheetOverlay, {}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogContent, {
	ref,
	className: cn("fixed z-50 flex flex-col bg-card shadow-[var(--shadow-border)]", side === "right" && "inset-y-0 right-0 h-full w-full max-w-md border-l border-border", side === "left" && "inset-y-0 left-0 h-full w-full max-w-md border-r border-border", side === "bottom" && "inset-x-0 bottom-0 max-h-[85vh] rounded-t-2xl border-t border-border", className),
	...props,
	children: [children, /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogClose, {
		className: "absolute right-3 top-3 rounded-md p-2 text-muted hover:bg-surface hover:text-foreground",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "size-4" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "sr-only",
			children: "Close"
		})]
	})]
})] }));
SheetContent.displayName = DialogContent.displayName;
function SheetHeader({ className, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: cn("flex flex-col gap-1.5 p-6 pb-2 pr-12", className),
		...props
	});
}
var SheetTitle = import_react.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogTitle, {
	ref,
	className: cn("font-display text-xl font-medium tracking-tight", className),
	...props
}));
SheetTitle.displayName = DialogTitle.displayName;
var SheetDescription = import_react.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogDescription, {
	ref,
	className: cn("text-sm text-muted", className),
	...props
}));
SheetDescription.displayName = DialogDescription.displayName;
function EditorWorkspace({ cv }) {
	const navigate = useNavigate();
	const setTemplate = useCvStore((s) => s.setTemplate);
	const remove = useCvStore((s) => s.remove);
	const [section, setSection] = (0, import_react.useState)("profile");
	const [pane, setPane] = (0, import_react.useState)("write");
	const [coachOpen, setCoachOpen] = (0, import_react.useState)(false);
	const score = (0, import_react.useMemo)(() => scoreCv(cv), [cv]);
	useCvAutosave(cv.id);
	function printCv() {
		window.print();
	}
	function exportJson() {
		const blob = new Blob([JSON.stringify(cv, null, 2)], { type: "application/json" });
		const url = URL.createObjectURL(blob);
		const a = document.createElement("a");
		a.href = url;
		a.download = `${(cv.personal.fullName || cv.name || "cv").replace(/\s+/g, "-").toLowerCase()}.json`;
		a.click();
		URL.revokeObjectURL(url);
		toast.success("JSON downloaded");
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "min-h-dvh bg-background text-foreground",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
				className: "no-print sticky top-0 z-30 border-b border-border bg-background/90 backdrop-blur-sm",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center gap-2 px-3 py-2.5 sm:px-5",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							variant: "ghost",
							size: "icon-sm",
							asChild: true,
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
								to: "/studio",
								"aria-label": "Back to studio",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowLeft, {})
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Wordmark, {
							className: "hidden sm:inline-flex",
							to: "/studio"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "hidden text-border sm:inline",
							children: "/"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "min-w-0 flex-1 truncate text-sm font-medium",
							children: cv.name || "Untitled CV"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
							variant: "good",
							className: "tabular-nums",
							children: score.total
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
							size: "sm",
							variant: "ghost",
							className: "hidden lg:inline-flex",
							onClick: () => setCoachOpen(true),
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Sparkles, {}), "Coach"]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
							size: "sm",
							variant: "secondary",
							className: "hidden sm:inline-flex",
							onClick: printCv,
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Printer, {}), "Compile PDF"]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DropdownMenu, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DropdownMenuTrigger, {
							asChild: true,
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								size: "icon-sm",
								variant: "ghost",
								"aria-label": "More",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Ellipsis, {})
							})
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DropdownMenuContent, {
							align: "end",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DropdownMenuItem, {
									className: "sm:hidden",
									onSelect: printCv,
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Printer, { className: "size-4" }), "Compile PDF"]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DropdownMenuItem, {
									onSelect: exportJson,
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Download, { className: "size-4" }), "Export JSON"]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DropdownMenuItem, {
									onSelect: () => setCoachOpen(true),
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Sparkles, { className: "size-4" }), "Writing coach"]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DropdownMenuSeparator, {}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DropdownMenuItem, {
									onSelect: () => {
										remove(cv.id);
										deleteDocument({ data: cv.id });
										toast.success("Draft deleted");
										navigate({ to: "/studio" });
									},
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash2, { className: "size-4" }), "Delete draft"]
								})
							]
						})] }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "hidden md:block",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AuthSlot, {})
						})
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "no-print flex gap-1 overflow-x-auto border-t border-border px-3 py-2 lg:hidden",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
						size: "sm",
						variant: pane === "write" ? "default" : "ghost",
						onClick: () => setPane("write"),
						className: "shrink-0",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PenLine, {}), "Write"]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
						size: "sm",
						variant: pane === "preview" ? "default" : "ghost",
						onClick: () => setPane("preview"),
						className: "shrink-0",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Eye, {}), "Preview"]
					})]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "no-print mx-auto grid max-w-[1600px] lg:grid-cols-[minmax(0,1fr)_minmax(340px,520px)] xl:grid-cols-[200px_minmax(0,1fr)_minmax(380px,560px)]",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("nav", {
						className: "hidden border-r border-border xl:block",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "sticky top-[57px] space-y-1 p-4",
							children: [
								SECTIONS.map((s) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									type: "button",
									onClick: () => setSection(s.id),
									className: cn("flex h-11 w-full items-center rounded-lg px-3 text-left text-sm font-medium transition-colors duration-[var(--motion-quick)]", section === s.id ? "bg-primary text-primary-foreground" : "text-muted hover:bg-surface hover:text-foreground"),
									children: s.label
								}, s.id)),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "px-3 pt-6 text-xs font-medium uppercase tracking-wide text-subtle",
									children: "Template"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TemplatePicker, {
									value: cv.template,
									onChange: (t) => setTemplate(cv.id, t)
								})
							]
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
						className: cn("min-w-0 border-r border-border", pane === "preview" ? "hidden lg:block" : "block"),
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "xl:hidden",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "flex gap-1 overflow-x-auto px-3 py-2",
								children: SECTIONS.map((s) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									type: "button",
									onClick: () => setSection(s.id),
									className: cn("h-11 shrink-0 rounded-full px-4 text-sm font-medium", section === s.id ? "bg-primary text-primary-foreground" : "bg-surface text-muted"),
									children: s.label
								}, s.id))
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "px-3 pb-2",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TemplatePicker, {
									value: cv.template,
									onChange: (t) => setTemplate(cv.id, t)
								})
							})]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "px-3 pb-24 pt-2 sm:px-6 sm:pt-5",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(EditorForm, {
								cv,
								section
							})
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("aside", {
						className: cn("min-w-0 bg-surface/60", pane === "write" ? "hidden lg:block" : "block"),
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "sticky top-[57px] max-h-[calc(100dvh-57px)] overflow-auto p-3 sm:p-5",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "mb-3 flex items-center justify-between",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "text-xs font-medium uppercase tracking-wide text-muted",
										children: "Compiled page"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
										size: "sm",
										variant: "outline",
										className: "lg:hidden",
										onClick: printCv,
										children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Printer, {}), "PDF"]
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CvStage, { cv }),
								cv.coverLetter.trim() ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
									className: "mt-6 rounded-xl bg-paper p-5 text-sm leading-relaxed shadow-[var(--shadow-border)]",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "mb-2 text-xs font-medium uppercase tracking-wide text-muted",
										children: "Cover letter"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("pre", {
										className: "whitespace-pre-wrap font-sans",
										children: cv.coverLetter
									})]
								}) : null
							]
						})
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Sheet, {
				open: coachOpen,
				onOpenChange: setCoachOpen,
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SheetContent, {
					className: "overflow-y-auto",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SheetHeader, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SheetTitle, { children: "Writing coach" }) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "px-6 pb-10",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CoachPanel, { cv })
					})]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "hidden print-only",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(CvDocument, { cv }), cv.coverLetter.trim() ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
					className: "cv-sheet",
					style: { marginTop: 24 },
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", { children: "Cover letter" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "whitespace-pre-wrap",
						children: cv.coverLetter
					})]
				}) : null]
			})
		]
	});
}
function TemplatePicker({ value, onChange }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "flex gap-1 overflow-x-auto xl:flex-col",
		children: TEMPLATES.map((id) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
			type: "button",
			onClick: () => onChange(id),
			className: cn("h-11 shrink-0 rounded-lg px-3 text-left text-sm transition-colors duration-[var(--motion-quick)] xl:h-auto xl:py-2", value === id ? "bg-card text-foreground shadow-[var(--shadow-border)]" : "text-muted hover:text-foreground"),
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "block font-medium",
				children: TEMPLATE_META[id].label
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "hidden text-xs text-subtle xl:block",
				children: TEMPLATE_META[id].blurb
			})]
		}, id))
	});
}
function EditorPage() {
	const { cvId } = Route$1.useParams();
	const { user, isPending } = useCurrentUserState();
	const hydrated = useCvStore((s) => s.hydrated);
	const cv = useCv(cvId);
	if (isPending || !hydrated) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("main", {
		className: "flex min-h-dvh items-center justify-center bg-background text-muted",
		children: "Opening draft…"
	});
	if (!user) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(RedirectToSignIn, { to: "/login" });
	if (!cv) return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		className: "flex min-h-dvh flex-col items-center justify-center gap-4 bg-background px-6 text-center",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "font-display text-2xl font-medium",
				children: "This draft is gone"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "max-w-sm text-sm text-muted",
				children: "It may have been deleted, or it lives on another account."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				asChild: true,
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
					to: "/studio",
					children: "Back to studio"
				})
			})
		]
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(EditorWorkspace, { cv });
}
//#endregion
export { EditorPage as component };
