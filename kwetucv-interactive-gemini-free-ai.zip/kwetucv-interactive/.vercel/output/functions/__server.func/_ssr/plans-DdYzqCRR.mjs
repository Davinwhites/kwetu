//#region node_modules/.nitro/vite/services/ssr/assets/plans-DdYzqCRR.js
var CHANNELS = [
	{
		id: "mtn",
		label: "MTN MoMo",
		hint: "Pay from any MTN line (077, 078, 076, 039).",
		kind: "momo"
	},
	{
		id: "airtel",
		label: "Airtel Money",
		hint: "Pay from any Airtel line (070, 075, 074, 020).",
		kind: "momo"
	},
	{
		id: "card",
		label: "Visa / Mastercard",
		hint: "Ugandan and international debit or credit cards.",
		kind: "card"
	}
];
var PLANS = {
	free: {
		id: "free",
		name: "Starter",
		priceUgx: 0,
		period: "forever",
		tagline: "Write and compile on one page, on us.",
		features: [
			"2 saved CVs on your account",
			"Official and Editorial templates",
			"Passport photo and National ID fields",
			"Writing score as you type",
			"Print to PDF"
		]
	},
	writer: {
		id: "writer",
		name: "Writer",
		priceUgx: 24900,
		period: "month",
		tagline: "AI that tightens wording without inventing a career.",
		features: [
			"10 saved CVs",
			"All five templates",
			"AI rewrite and review (60 / month)",
			"National ID scan into your profile",
			"Job categories for Uganda"
		]
	},
	pro: {
		id: "pro",
		name: "Career Pro",
		priceUgx: 59900,
		period: "month",
		featured: true,
		tagline: "Finish a complete CV and cover letter with AI.",
		features: [
			"Unlimited CVs on your account",
			"Unlimited AI writing, review, and tailor",
			"Finish a CV from notes",
			"Cover letters aimed at a job advert",
			"National ID scan and passport photo",
			"Every category and template"
		]
	},
	pro_year: {
		id: "pro_year",
		name: "Career Pro · year",
		priceUgx: 499e3,
		period: "year",
		tagline: "Two months free versus paying monthly.",
		features: [
			"Everything in Career Pro",
			"UGX 41,583 / month effective",
			"Account never lapses from inactivity"
		]
	},
	finish: {
		id: "finish",
		name: "Finish one CV",
		priceUgx: 14900,
		period: "once",
		tagline: "One complete AI pass — no subscription.",
		features: [
			"One Finish-with-AI credit",
			"20 AI rewrites",
			"Cover letter for that draft"
		]
	}
};
var CHECKOUT_PLANS = [
	"writer",
	"pro",
	"pro_year",
	"finish"
];
function formatUgx(amount) {
	return `UGX ${amount.toLocaleString("en-US")}`;
}
function periodLabel(plan) {
	if (plan.period === "forever") return "Free";
	if (plan.period === "once") return "one-time";
	if (plan.period === "year") return "/ year";
	return "/ month";
}
function periodKey(now = Date.now()) {
	const d = new Date(now);
	return `${d.getUTCFullYear()}-${String(d.getUTCMonth() + 1).padStart(2, "0")}`;
}
function isPaidPlan(plan) {
	return plan === "writer" || plan === "pro" || plan === "pro_year";
}
function entitlementsFrom(row) {
	const now = Date.now();
	const activePaid = row.status === "active" && isPaidPlan(row.plan) && (row.periodEnd == null || row.periodEnd > now);
	const plan = activePaid ? row.plan : "free";
	const pro = plan === "pro" || plan === "pro_year";
	const writer = plan === "writer";
	const finish = row.finishCredits > 0;
	const aiLimit = pro ? null : writer ? 60 : finish ? 20 : 0;
	const canAi = pro || writer || finish;
	return {
		plan,
		status: activePaid ? "active" : "none",
		periodEnd: row.periodEnd,
		finishCredits: row.finishCredits,
		aiUsed: row.aiUsed,
		aiLimit,
		maxCvs: pro ? 1e4 : writer ? 10 : 2,
		canRewrite: canAi,
		canReview: pro || writer,
		canTailor: pro,
		canCompose: pro || finish,
		canScan: pro || writer,
		canLetter: pro || finish,
		allTemplates: pro || writer
	};
}
function ugPhoneValid(raw) {
	const d = raw.replace(/[\s-]/g, "");
	if (/^\+256[7]\d{8}$/.test(d)) return true;
	if (/^0[7]\d{8}$/.test(d)) return true;
	if (/^256[7]\d{8}$/.test(d)) return true;
	return false;
}
function normaliseUgPhone(raw) {
	const d = raw.replace(/[\s-]/g, "");
	if (d.startsWith("+256")) return d;
	if (d.startsWith("256")) return `+${d}`;
	if (d.startsWith("0")) return `+256${d.slice(1)}`;
	return d;
}
//#endregion
export { formatUgx as a, periodKey as c, entitlementsFrom as i, periodLabel as l, CHECKOUT_PLANS as n, isPaidPlan as o, PLANS as r, normaliseUgPhone as s, CHANNELS as t, ugPhoneValid as u };
