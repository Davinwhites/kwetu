//#region node_modules/.nitro/vite/services/ssr/assets/categories-CugOKuXQ.js
var CATEGORIES = [
	{
		id: "public-service",
		label: "Public service",
		blurb: "Ministries, districts, commissions, and statutory bodies.",
		template: "official",
		skills: "Policy drafting, stakeholder engagement, procurement, reporting, PFMA",
		extras: ["Languages", "Computer packages"]
	},
	{
		id: "ngo",
		label: "NGO & development",
		blurb: "INGOs, CSOs, and donor-funded programmes.",
		template: "official",
		skills: "MEAL, proposal writing, safeguarding, community mobilisation, donor reporting",
		extras: ["Languages", "Referees available"]
	},
	{
		id: "banking",
		label: "Banking & microfinance",
		blurb: "Commercial banks, SACCOs, and MFIs.",
		template: "editorial",
		skills: "Credit analysis, KYC, Excel, customer service, risk",
		extras: ["Certifications"]
	},
	{
		id: "education",
		label: "Education & teaching",
		blurb: "Schools, universities, and TVET.",
		template: "official",
		skills: "Lesson planning, UNEB, classroom management, ICT in education",
		extras: ["Registration", "Languages"]
	},
	{
		id: "health",
		label: "Healthcare",
		blurb: "Hospitals, clinics, public health, and pharmacies.",
		template: "official",
		skills: "Clinical care, HMIS, counselling, infection prevention",
		extras: ["Licence", "Languages"]
	},
	{
		id: "ict",
		label: "ICT & software",
		blurb: "Product, engineering, support, and telecoms.",
		template: "editorial",
		skills: "TypeScript, SQL, cloud, support tickets, networks",
		extras: ["GitHub", "Certifications"]
	},
	{
		id: "engineering",
		label: "Engineering & construction",
		blurb: "Civil, electrical, oil & gas support, and sites.",
		template: "compact",
		skills: "AutoCAD, site supervision, HSE, BOQ, contract admin",
		extras: ["ERB / UIPE"]
	},
	{
		id: "agriculture",
		label: "Agriculture & agribusiness",
		blurb: "Extension, agronomy, cooperatives, and processing.",
		template: "official",
		skills: "Extension, value chains, farmer training, records",
		extras: ["Languages"]
	},
	{
		id: "hospitality",
		label: "Hospitality & tourism",
		blurb: "Hotels, lodges, airlines, and events.",
		template: "modern",
		skills: "Front office, F&B, guest relations, Opera / Fidelio",
		extras: ["Languages"]
	},
	{
		id: "legal",
		label: "Legal & compliance",
		blurb: "Chambers, in-house, and company secretarial.",
		template: "executive",
		skills: "Legal research, drafting, litigation support, compliance",
		extras: ["Enrolment"]
	},
	{
		id: "sales",
		label: "Sales, retail & FMCG",
		blurb: "Field sales, merchandising, and trade.",
		template: "compact",
		skills: "Route to market, negotiation, CRM, merchandising",
		extras: ["Languages"]
	},
	{
		id: "graduate",
		label: "Fresh graduate",
		blurb: "First role, internship, or national service.",
		template: "official",
		skills: "Microsoft Office, research, teamwork, communication",
		extras: ["Languages", "Interests"]
	},
	{
		id: "oil-gas",
		label: "Oil, gas & mining",
		blurb: "Albertine, Karamoja, and contractor roles.",
		template: "compact",
		skills: "HSE, logistics, community liaison, reporting",
		extras: ["Certifications"]
	},
	{
		id: "logistics",
		label: "Transport & logistics",
		blurb: "Freight, clearing, and last-mile.",
		template: "compact",
		skills: "Clearing & forwarding, fleet, warehousing, ASYCUDA",
		extras: ["Licence"]
	},
	{
		id: "media",
		label: "Media & communications",
		blurb: "Newsrooms, brand, and digital.",
		template: "modern",
		skills: "Writing, social, Adobe, media relations, Luganda / English",
		extras: ["Portfolio"]
	}
];
function categoryById(id) {
	return CATEGORIES.find((c) => c.id === id) ?? CATEGORIES[0];
}
//#endregion
export { categoryById as n, CATEGORIES as t };
