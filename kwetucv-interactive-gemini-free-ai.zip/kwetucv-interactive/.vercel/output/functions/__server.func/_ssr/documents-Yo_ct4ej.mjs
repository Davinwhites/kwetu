import { r as createServerFn } from "./ssr.mjs";
import { t as createServerRpc } from "./createServerRpc-CcvdN_gc.mjs";
import { r as getSql } from "./db-DzXWfmCK.mjs";
import { t as authMiddleware } from "./middleware-C_SaWK1E.mjs";
import { i as getEntitlements } from "./billing-vzNwqE81.mjs";
import { a as normalizeCv } from "./normalize-EG92hli-.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/documents-Yo_ct4ej.js
function rowToCv(row) {
	try {
		const parsed = JSON.parse(row.payload);
		const cv = normalizeCv(parsed);
		if (!cv) return null;
		cv.id = row.id;
		cv.name = row.name || cv.name;
		cv.updatedAt = Number(row.updated_at) || cv.updatedAt;
		return cv;
	} catch {
		return null;
	}
}
var listDocuments_createServerFn_handler = createServerRpc({
	id: "2fd81dbf0aed065e83b545148a22d741c2f91036ba35667588aee532c97879f2",
	name: "listDocuments",
	filename: "src/lib/data/documents.ts"
}, (opts) => listDocuments.__executeServer(opts));
var listDocuments = createServerFn({ method: "GET" }).middleware([authMiddleware]).handler(listDocuments_createServerFn_handler, async ({ context }) => {
	return (await (await getSql())`select id, name, payload, updated_at from cv_documents where user_id = ${context.userId} order by updated_at desc`).map(rowToCv).filter((c) => Boolean(c));
});
var saveDocument_createServerFn_handler = createServerRpc({
	id: "d09f938d00b044d948a62b9c964cac27122de59243aef899dc006468604b5a77",
	name: "saveDocument",
	filename: "src/lib/data/documents.ts"
}, (opts) => saveDocument.__executeServer(opts));
var saveDocument = createServerFn({ method: "POST" }).validator((input) => input).middleware([authMiddleware]).handler(saveDocument_createServerFn_handler, async ({ context, data }) => {
	const cv = normalizeCv(data);
	if (!cv) return {
		ok: false,
		error: "Invalid CV"
	};
	const sql = await getSql();
	if ((await sql`select id from cv_documents where id = ${cv.id} and user_id = ${context.userId}`).length === 0) {
		const ents = await getEntitlements(context.userId);
		const countRows = await sql`select count(*) as n from cv_documents where user_id = ${context.userId}`;
		if (Number(countRows[0]?.n ?? 0) >= ents.maxCvs) return {
			ok: false,
			error: `Starter keeps ${ents.maxCvs} CVs. Upgrade to save more.`,
			code: "upgrade"
		};
		await sql`insert into cv_documents (id, user_id, name, payload, updated_at, created_at) values (${cv.id}, ${context.userId}, ${cv.name}, ${JSON.stringify(cv)}, ${cv.updatedAt}, ${cv.updatedAt})`;
	} else await sql`update cv_documents set name = ${cv.name}, payload = ${JSON.stringify(cv)}, updated_at = ${cv.updatedAt} where id = ${cv.id} and user_id = ${context.userId}`;
	return { ok: true };
});
var deleteDocument_createServerFn_handler = createServerRpc({
	id: "f852af3930713fead4b61b3f6fb366795b2e1f01362f89543003b7e4718bbca9",
	name: "deleteDocument",
	filename: "src/lib/data/documents.ts"
}, (opts) => deleteDocument.__executeServer(opts));
var deleteDocument = createServerFn({ method: "POST" }).validator((id) => id).middleware([authMiddleware]).handler(deleteDocument_createServerFn_handler, async ({ context, data: id }) => {
	await (await getSql())`delete from cv_documents where id = ${id} and user_id = ${context.userId}`;
	return { ok: true };
});
//#endregion
export { deleteDocument_createServerFn_handler, listDocuments_createServerFn_handler, saveDocument_createServerFn_handler };
