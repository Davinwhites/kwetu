import { _ as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { o as require_jsx_runtime } from "../_libs/@radix-ui/react-collection+[...].mjs";
import { t as Button } from "./button-L8IaURhk.mjs";
import { i as SiteHeader, r as SiteFooter } from "./chrome-CMH7kCiq.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/about-aboog4K7.js
var import_jsx_runtime = require_jsx_runtime();
function AboutPage() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "min-h-dvh bg-background",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SiteHeader, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
				className: "mx-auto max-w-2xl px-4 py-14 sm:px-8",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs font-medium uppercase tracking-[0.2em] text-muted",
						children: "Kampala"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
						className: "mt-3 font-display text-4xl font-medium tracking-tight",
						children: "Advanced CV software, written for Uganda."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-6 space-y-4 text-base leading-relaxed text-muted",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "KwetuCV is a professional writing studio for curricula vitae. It compiles a real A4 page as you type, scores wording the way a hiring panel reads it, and — on Writer and Career Pro — uses AI to rewrite, review, tailor, scan a National ID, and finish a complete CV from your notes." }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "It is built around how Uganda actually hires: passport photos, nationality, NIN when asked, named referees, Makerere and Kyambogo on the education line, UGX in your impact bullets, and job categories from public service to oil and gas. Prices are in Ugandan shillings. You pay with MTN MoMo, Airtel Money, or card." }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "KwetuCV is software for individuals. It is not a ministry, not NIRA, not NITA-U, and not an employer. We do not submit applications on your behalf. You remain responsible for every fact on the page you send. Use it only for lawful employment, study, and professional purposes." }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "Accounts are first-class. Create one with email and a password, or continue with Google or X. Drafts and the plan you paid for are stored against that account so they are not forgotten when you change phones." }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "We designed KwetuCV to stand among the most complete CV products available to Ugandan professionals — compile, coach, identity import, cover letters, and local payments in one studio — without pretending to a government licence we do not hold." })
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-8 flex flex-wrap gap-3",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							asChild: true,
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
								to: "/login",
								children: "Create an account"
							})
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							variant: "secondary",
							asChild: true,
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
								to: "/pricing",
								children: "UGX pricing"
							})
						})]
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SiteFooter, {})
		]
	});
}
//#endregion
export { AboutPage as component };
