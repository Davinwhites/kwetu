import { o as __toESM } from "../_runtime.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { _ as Link, y as useNavigate } from "../_libs/@tanstack/react-router+[...].mjs";
import { o as require_jsx_runtime } from "../_libs/@radix-ui/react-collection+[...].mjs";
import { n as useCurrentUserState } from "./use-current-user-DG6UNzh9.mjs";
import { t as cn } from "./utils-iXVfomyn.mjs";
import { t as Button } from "./button-L8IaURhk.mjs";
import { i as SiteHeader, n as RedirectToSignIn, r as SiteFooter } from "./chrome-CMH7kCiq.mjs";
import { a as formatUgx, l as periodLabel, n as CHECKOUT_PLANS, r as PLANS, t as CHANNELS } from "./plans-DdYzqCRR.mjs";
import { t as completeCheckout } from "./billing-vzNwqE81.mjs";
import { u as LoaderCircle } from "../_libs/lucide-react.mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { i as Route$7 } from "./router-C4JLTH4Y.mjs";
import { t as Input } from "./input-BQzPFyeT.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/checkout-BtgIBg8q.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function CheckoutPage() {
	const { user, isPending } = useCurrentUserState();
	const { plan: planParam } = Route$7.useSearch();
	const navigate = useNavigate();
	const planId = CHECKOUT_PLANS.includes(planParam) ? planParam : "pro";
	const plan = PLANS[planId];
	const [channel, setChannel] = (0, import_react.useState)("mtn");
	const [phone, setPhone] = (0, import_react.useState)("");
	const [busy, setBusy] = (0, import_react.useState)(false);
	const channelMeta = (0, import_react.useMemo)(() => CHANNELS.find((c) => c.id === channel), [channel]);
	if (isPending) return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "min-h-dvh bg-background",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SiteHeader, {}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "mx-auto max-w-lg px-4 py-20",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "h-64 animate-pulse rounded-2xl bg-surface" })
		})]
	});
	if (!user) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(RedirectToSignIn, { to: "/login" });
	async function pay() {
		setBusy(true);
		try {
			const res = await completeCheckout({ data: {
				plan: planId,
				channel,
				phone: phone.trim() || void 0
			} });
			if (!res.ok) {
				toast.error(res.error);
				return;
			}
			toast.success("Payment received. Your plan is on this account.");
			navigate({ to: "/studio" });
		} catch {
			toast.error("Payment could not be completed.");
		} finally {
			setBusy(false);
		}
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "min-h-dvh bg-background",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SiteHeader, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
				className: "mx-auto grid max-w-5xl gap-8 px-4 py-12 lg:grid-cols-[1fr_0.9fr] sm:px-8",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs font-medium uppercase tracking-[0.18em] text-muted",
						children: "Checkout · UGX"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
						className: "mt-3 font-display text-3xl font-medium tracking-tight",
						children: plan.name
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-2 text-muted",
						children: plan.tagline
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "mt-4 font-display text-4xl font-medium tabular-nums",
						children: [
							formatUgx(plan.priceUgx),
							" ",
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-lg text-muted",
								children: periodLabel(plan)
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
						className: "mt-6 space-y-2 text-sm text-muted",
						children: plan.features.map((f) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: f }, f))
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "mt-8 text-sm",
						children: [
							"Switch plan:",
							" ",
							CHECKOUT_PLANS.map((id) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
								to: "/checkout",
								search: { plan: id },
								className: cn("mr-3 underline-offset-4 hover:underline", id === planId && "text-primary"),
								children: PLANS[id].name
							}, id))
						]
					})
				] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "rounded-2xl border border-border bg-card p-5 shadow-[var(--shadow-border)] sm:p-6",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "font-display text-xl font-medium",
							children: "Payment channel"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-1 text-sm text-muted",
							children: "Choose how you want to pay in Uganda."
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "mt-4 grid gap-2",
							children: CHANNELS.map((c) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
								type: "button",
								onClick: () => setChannel(c.id),
								className: cn("rounded-xl border px-4 py-3 text-left transition-colors duration-[var(--motion-quick)]", channel === c.id ? "border-primary bg-primary/8 text-foreground" : "border-border bg-background text-muted hover:text-foreground"),
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "block font-medium",
									children: c.label
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "block text-xs text-subtle",
									children: c.hint
								})]
							}, c.id))
						}),
						channelMeta.kind === "momo" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
							className: "mt-5 grid gap-1.5",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "text-xs font-medium uppercase tracking-wide text-muted",
								children: "Mobile number"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								value: phone,
								onChange: (e) => setPhone(e.target.value),
								placeholder: "+256 772 000 000",
								inputMode: "tel"
							})]
						}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "mt-5 text-sm text-muted",
							children: [
								"Card payments are confirmed on your account without collecting a full card number in this studio (PCI). Confirm below to attach ",
								formatUgx(plan.priceUgx),
								" to this KwetuCV account."
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
							className: "mt-6 w-full",
							onClick: () => void pay(),
							disabled: busy,
							children: [
								busy ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(LoaderCircle, { className: "animate-spin" }) : null,
								"Pay ",
								formatUgx(plan.priceUgx),
								" with ",
								channelMeta.label
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "mt-3 text-xs text-subtle",
							children: [
								"By paying you agree to the",
								" ",
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
									to: "/terms",
									className: "underline-offset-4 hover:underline",
									children: "Terms"
								}),
								". The plan is stored on ",
								user.primaryEmail ?? "your account",
								" and remains until it ends — it is not forgotten when you leave this page."
							]
						})
					]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SiteFooter, {})
		]
	});
}
//#endregion
export { CheckoutPage as component };
