import { _ as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { o as require_jsx_runtime } from "../_libs/@radix-ui/react-collection+[...].mjs";
import { t as Button } from "./button-L8IaURhk.mjs";
import { i as SiteHeader, r as SiteFooter } from "./chrome-CMH7kCiq.mjs";
import { a as formatUgx, r as PLANS } from "./plans-DdYzqCRR.mjs";
import { t as CATEGORIES } from "./categories-CugOKuXQ.mjs";
import { t as SAMPLE_CV } from "./sample-zjk0Oyic.mjs";
import { t as CvDocument } from "./preview-DcWSYbBA.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-CskRnpE4.js
var import_jsx_runtime = require_jsx_runtime();
function Home() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "min-h-dvh bg-background",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SiteHeader, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
					className: "mx-auto grid max-w-6xl items-end gap-10 px-4 pb-16 pt-10 sm:px-8 lg:grid-cols-[1.05fr_0.95fr] lg:pt-16",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-xs font-medium uppercase tracking-[0.2em] text-muted",
							children: "Kampala · UGX · Mobile money"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
							className: "mt-4 max-w-xl font-display text-[2.4rem] font-medium leading-[1.1] tracking-[-0.03em] sm:text-5xl",
							children: "The CV studio built for Uganda."
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-4 max-w-lg text-base leading-relaxed text-muted sm:text-lg",
							children: "Write, compile onto a real A4 page, and finish with AI — photo, National ID, referees, and a cover letter included. Your account is saved. Prices are in Ugandan shillings."
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-8 flex flex-wrap gap-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								size: "lg",
								asChild: true,
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
									to: "/login",
									children: "Create a free account"
								})
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								size: "lg",
								variant: "secondary",
								asChild: true,
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
									to: "/pricing",
									children: "See UGX prices"
								})
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-4 text-xs text-subtle",
							children: "For lawful job applications. Not a government service. You own every word you submit."
						})
					] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "relative mx-auto w-full max-w-[420px]",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "pointer-events-none absolute inset-3 translate-x-2 translate-y-3 rounded-sm bg-card shadow-[var(--shadow-border)]" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "relative overflow-hidden rounded-sm bg-paper shadow-[var(--shadow-border)]",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "folio-thumb",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "folio-thumb-page",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CvDocument, { cv: SAMPLE_CV })
								})
							})
						})]
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
					className: "border-y border-border bg-card/60",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mx-auto grid max-w-6xl gap-8 px-4 py-12 sm:grid-cols-3 sm:px-8",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Step, {
								n: "01",
								title: "Create an account",
								body: "Email and password, Google, or X. Drafts live on your account so they are not forgotten when you change phones."
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Step, {
								n: "02",
								title: "Write or finish with AI",
								body: "Import a National ID photo, pick a Ugandan job category, and let the coach compile a complete page from your notes."
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Step, {
								n: "03",
								title: "Compile and send",
								body: "Print to PDF. Official template carries photo, particulars, and referees the way panels in Kampala expect."
							})
						]
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
					className: "mx-auto max-w-6xl px-4 py-16 sm:px-8",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "mb-8 flex items-end justify-between gap-4",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "font-display text-3xl font-medium tracking-tight",
							children: "Categories that match how Uganda hires"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-2 max-w-xl text-muted",
							children: "Each category suggests skills, extras, and a template — public service, NGO, bank, hospital, ICT, and more."
						})] })
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
						className: "grid gap-3 sm:grid-cols-2 lg:grid-cols-3",
						children: CATEGORIES.map((c) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
							className: "rounded-2xl border border-border bg-card p-4 shadow-[var(--shadow-border)]",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "font-medium",
								children: c.label
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-1 text-sm text-muted",
								children: c.blurb
							})]
						}, c.id))
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
					className: "mx-auto max-w-6xl px-4 pb-20 sm:px-8",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "font-display text-3xl font-medium tracking-tight",
							children: "Priced in Ugandan shillings"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-2 max-w-xl text-muted",
							children: "Pay with MTN MoMo, Airtel Money, or Visa / Mastercard. No dollar conversion at checkout."
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "mt-8 grid gap-4 md:grid-cols-3",
							children: [
								"free",
								"writer",
								"pro"
							].map((id) => {
								const plan = PLANS[id];
								return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
									className: "flex flex-col rounded-2xl border border-border bg-card p-5 shadow-[var(--shadow-border)]",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "text-sm font-medium text-muted",
											children: plan.name
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "mt-2 font-display text-3xl font-medium tabular-nums",
											children: plan.priceUgx === 0 ? "Free" : formatUgx(plan.priceUgx)
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "text-sm text-subtle",
											children: plan.period === "month" ? "per month" : plan.tagline
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
											className: "mt-4 flex-1 space-y-2 text-sm text-muted",
											children: plan.features.slice(0, 4).map((f) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: f }, f))
										}),
										id === "free" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
											className: "mt-6",
											variant: "secondary",
											asChild: true,
											children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
												to: "/login",
												children: "Start free"
											})
										}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
											className: "mt-6",
											variant: id === "pro" ? "default" : "secondary",
											asChild: true,
											children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
												to: "/checkout",
												search: { plan: id },
												children: "Subscribe"
											})
										})
									]
								}, id);
							})
						})
					]
				})
			] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SiteFooter, {})
		]
	});
}
function Step({ n, title, body }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "font-display text-sm tabular-nums text-primary",
			children: n
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
			className: "mt-2 font-display text-xl font-medium",
			children: title
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mt-2 text-sm leading-relaxed text-muted",
			children: body
		})
	] });
}
//#endregion
export { Home as component };
