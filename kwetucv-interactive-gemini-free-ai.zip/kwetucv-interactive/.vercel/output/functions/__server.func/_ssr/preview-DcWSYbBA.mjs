import { o as __toESM } from "../_runtime.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { o as require_jsx_runtime } from "../_libs/@radix-ui/react-collection+[...].mjs";
import { t as cn } from "./utils-iXVfomyn.mjs";
import { r as particulars, t as contactLine } from "./score-pC17jSkT.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/preview-DcWSYbBA.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function dates(start, end, current) {
	const a = start.trim();
	const b = current ? "Present" : end.trim();
	if (!a && !b) return "";
	if (a && b) return `${a} – ${b}`;
	return a || b;
}
function hasText(s) {
	return Boolean(s && s.trim());
}
function Sec({ title, children, dense }) {
	if (!children) return null;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: cn("cv-sec", dense && "cv-sec-dense"),
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", { children: title }), children]
	});
}
function Bullets({ items }) {
	const list = items.map((b) => b.trim()).filter(Boolean);
	if (!list.length) return null;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", { children: list.map((b, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: b }, i)) });
}
function SummaryBlock({ cv, title = "Summary" }) {
	if (!hasText(cv.summary)) return null;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Sec, {
		title,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "cv-summary",
			children: cv.summary
		})
	});
}
function ExperienceBlock({ cv }) {
	const items = cv.experience.filter((e) => hasText(e.company) || hasText(e.role));
	if (!items.length) return null;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Sec, {
		title: "Experience",
		children: items.map((e) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "cv-job",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "cv-job-head",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "cv-job-role",
					children: [e.role || "Role", hasText(e.company) ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "cv-job-co",
						children: [" · ", e.company]
					}) : null]
				}), hasText(e.location) ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "cv-meta",
					children: e.location
				}) : null] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "cv-dates",
					children: dates(e.start, e.end, e.current)
				})]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Bullets, { items: e.bullets })]
		}, e.id))
	});
}
function EducationBlock({ cv }) {
	const items = cv.education.filter((e) => hasText(e.school));
	if (!items.length) return null;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Sec, {
		title: "Education",
		children: items.map((e) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "cv-job",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "cv-job-head",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "cv-job-role",
					children: [e.school, hasText(e.degree) || hasText(e.field) ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "cv-job-co",
						children: [
							" ",
							"· ",
							[e.degree, e.field].filter((x) => hasText(x)).join(" ")
						]
					}) : null]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "cv-dates",
					children: dates(e.start, e.end, false)
				})]
			}), hasText(e.details) ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "cv-meta",
				children: e.details
			}) : null]
		}, e.id))
	});
}
function ProjectsBlock({ cv }) {
	const items = cv.projects.filter((p) => hasText(p.name));
	if (!items.length) return null;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Sec, {
		title: "Projects",
		children: items.map((p) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "cv-job",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "cv-job-role",
					children: [p.name, hasText(p.url) ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "cv-job-co",
						children: [" · ", p.url]
					}) : null]
				}),
				hasText(p.summary) ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "cv-meta",
					children: p.summary
				}) : null,
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Bullets, { items: p.bullets })
			]
		}, p.id))
	});
}
function SkillsBlock({ cv }) {
	const items = cv.skills.filter((s) => hasText(s.items));
	if (!items.length) return null;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Sec, {
		title: "Skills",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "cv-skills",
			children: items.map((s) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: [hasText(s.category) ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("strong", { children: [s.category, " · "] }) : null, s.items] }, s.id))
		})
	});
}
function ExtrasBlock({ cv }) {
	const items = cv.extras.filter((e) => hasText(e.value));
	if (!items.length) return null;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Sec, {
		title: "Additional",
		children: items.map((e) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
			className: "cv-extra",
			children: [hasText(e.label) ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("strong", { children: [e.label, " · "] }) : null, e.value]
		}, e.id))
	});
}
function RefereesBlock({ cv }) {
	const items = cv.referees.filter((r) => hasText(r.name));
	if (!items.length) return null;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Sec, {
		title: "Referees",
		children: items.map((r) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "cv-referee",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "cv-job-role",
					children: r.name
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "cv-meta",
					children: [r.title, r.organisation].filter((x) => hasText(x)).join(" · ")
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "cv-meta",
					children: [r.phone, r.email].filter((x) => hasText(x)).join(" · ")
				})
			]
		}, r.id))
	});
}
function Photo({ cv }) {
	if (hasText(cv.personal.photoDataUrl)) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
		src: cv.personal.photoDataUrl,
		alt: "",
		className: "cv-photo"
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "cv-photo cv-photo-empty",
		children: "Photo"
	});
}
function Particulars({ cv }) {
	const rows = particulars(cv);
	if (!rows.length) return null;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "cv-particulars",
		children: rows.map((row) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [row.label, ": "] }), row.value] }, row.label))
	});
}
function Header({ cv, kicker }) {
	const line = contactLine(cv);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
		className: "cv-head",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: cn("cv-name", kicker && "cv-name-band"),
				children: cv.personal.fullName || "Your name"
			}),
			hasText(cv.personal.title) ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "cv-title",
				children: cv.personal.title
			}) : null,
			line.length ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "cv-contact",
				children: line.join("  ·  ")
			}) : null
		]
	});
}
function Body({ cv }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SummaryBlock, { cv }),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ExperienceBlock, { cv }),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(EducationBlock, { cv }),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ProjectsBlock, { cv }),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SkillsBlock, { cv }),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ExtrasBlock, { cv }),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(RefereesBlock, { cv })
	] });
}
function CvDocument({ cv, className }) {
	const empty = !hasText(cv.personal.fullName) && !hasText(cv.summary) && !cv.experience.some((e) => hasText(e.role) || hasText(e.company));
	if (cv.template === "official") return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
		className: cn("cv-sheet cv-official", className),
		"data-template": "official",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
			className: "cv-head-official",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "cv-name",
					children: cv.personal.fullName || "Your name"
				}),
				hasText(cv.personal.title) ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "cv-title",
					children: cv.personal.title
				}) : null,
				contactLine(cv).length ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "cv-contact",
					children: contactLine(cv).join("  ·  ")
				}) : null,
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Particulars, { cv })
			] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Photo, { cv })]
		}), empty ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "cv-empty",
			children: "Start writing in the left panel. This page compiles as you go."
		}) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SummaryBlock, {
				cv,
				title: "Career objective"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ExperienceBlock, { cv }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(EducationBlock, { cv }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SkillsBlock, { cv }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ProjectsBlock, { cv }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ExtrasBlock, { cv }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(RefereesBlock, { cv })
		] })]
	});
	if (cv.template === "modern") {
		const line = contactLine(cv);
		const skills = cv.skills.filter((s) => hasText(s.items));
		const extras = cv.extras.filter((e) => hasText(e.value));
		return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
			className: cn("cv-sheet cv-modern", className),
			"data-template": "modern",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("aside", {
				className: "cv-rail",
				children: [
					hasText(cv.personal.photoDataUrl) ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
						src: cv.personal.photoDataUrl,
						alt: "",
						className: "cv-photo"
					}) : null,
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "cv-name",
						children: cv.personal.fullName || "Your name"
					}),
					hasText(cv.personal.title) ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "cv-title",
						children: cv.personal.title
					}) : null,
					line.length ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
						className: "cv-rail-list",
						children: line.map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", { children: item }, item))
					}) : null,
					skills.length ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", { children: "Skills" }), skills.map((s) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: [hasText(s.category) ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", { children: s.category }) : null, /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: s.items })] }, s.id))] }) : null,
					extras.length ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", { children: "More" }), extras.map((e) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", { children: [hasText(e.label) ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("strong", { children: e.label }) : null, /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: e.value })] }, e.id))] }) : null
				]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "cv-main",
				children: [
					empty ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "cv-empty",
						children: "Start writing in the left panel. This page compiles as you go."
					}) : null,
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SummaryBlock, { cv }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ExperienceBlock, { cv }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(EducationBlock, { cv }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ProjectsBlock, { cv }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(RefereesBlock, { cv })
				]
			})]
		});
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
		className: cn("cv-sheet", `cv-${cv.template}`, className),
		"data-template": cv.template,
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Header, {
			cv,
			kicker: cv.template === "executive"
		}), empty ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "cv-empty",
			children: "Start writing in the left panel. This page compiles as you go."
		}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Body, { cv })]
	});
}
var PAGE_W = 794;
var PAGE_H = 1123;
function CvStage({ cv }) {
	const ref = (0, import_react.useRef)(null);
	const [scale, setScale] = (0, import_react.useState)(.55);
	(0, import_react.useEffect)(() => {
		const el = ref.current;
		if (!el) return;
		const fit = () => {
			const w = el.clientWidth;
			setScale(Math.max(.28, Math.min(1, (w - 8) / PAGE_W)));
		};
		fit();
		const ro = new ResizeObserver(fit);
		ro.observe(el);
		return () => ro.disconnect();
	}, []);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		ref,
		className: "cv-stage",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "cv-stage-inner",
			style: { height: PAGE_H * scale },
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "cv-stage-page",
				style: {
					width: PAGE_W,
					minHeight: PAGE_H,
					transform: `translateX(-50%) scale(${scale})`
				},
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CvDocument, { cv })
			})
		})
	});
}
//#endregion
export { CvStage as n, CvDocument as t };
