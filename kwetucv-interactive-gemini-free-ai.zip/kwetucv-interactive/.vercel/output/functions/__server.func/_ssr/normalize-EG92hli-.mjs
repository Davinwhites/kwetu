import { r as uid } from "./utils-iXVfomyn.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/normalize-EG92hli-.js
var TEMPLATES = [
	"official",
	"editorial",
	"compact",
	"modern",
	"executive"
];
var TEMPLATE_META = {
	official: {
		label: "Official",
		blurb: "Passport photo, particulars, referees — the Uganda public-service page.",
		ats: true
	},
	editorial: {
		label: "Editorial",
		blurb: "Single column, serif name, safest for ATS parsers.",
		ats: true
	},
	compact: {
		label: "Compact",
		blurb: "Denser type for packing a long career onto one page.",
		ats: true
	},
	modern: {
		label: "Modern",
		blurb: "Two-column layout with a pine rail for contact and skills.",
		ats: false
	},
	executive: {
		label: "Executive",
		blurb: "Name-forward band, generous space, board-ready.",
		ats: true
	}
};
var SECTIONS = [
	{
		id: "profile",
		label: "Profile"
	},
	{
		id: "summary",
		label: "Summary"
	},
	{
		id: "experience",
		label: "Experience"
	},
	{
		id: "education",
		label: "Education"
	},
	{
		id: "skills",
		label: "Skills"
	},
	{
		id: "more",
		label: "More"
	},
	{
		id: "letter",
		label: "Letter"
	}
];
function emptyPersonal() {
	return {
		fullName: "",
		title: "",
		email: "",
		phone: "",
		location: "",
		website: "",
		linkedin: "",
		github: "",
		nationality: "Ugandan",
		dateOfBirth: "",
		nin: "",
		gender: "",
		photoDataUrl: ""
	};
}
function blankCv(partial) {
	return {
		id: partial?.id ?? uid(),
		name: partial?.name ?? "Untitled CV",
		template: partial?.template ?? "official",
		category: partial?.category ?? "graduate",
		updatedAt: partial?.updatedAt ?? Date.now(),
		personal: {
			...emptyPersonal(),
			...partial?.personal
		},
		summary: partial?.summary ?? "",
		experience: partial?.experience ?? [{
			id: uid(),
			company: "",
			role: "",
			location: "",
			start: "",
			end: "",
			current: false,
			bullets: ["", ""]
		}],
		education: partial?.education ?? [{
			id: uid(),
			school: "",
			degree: "",
			field: "",
			start: "",
			end: "",
			details: ""
		}],
		projects: partial?.projects ?? [],
		skills: partial?.skills ?? [{
			id: uid(),
			category: "Core",
			items: ""
		}],
		extras: partial?.extras ?? [],
		referees: partial?.referees ?? [{
			id: uid(),
			name: "",
			title: "",
			organisation: "",
			phone: "",
			email: ""
		}],
		coverLetter: partial?.coverLetter ?? ""
	};
}
function normalizeCv(raw) {
	if (!raw || typeof raw !== "object") return null;
	const r = raw;
	if (!r.personal || typeof r.personal !== "object") return null;
	const template = TEMPLATES.includes(r.template) ? r.template : "official";
	const referees = Array.isArray(r.referees) ? r.referees : [];
	return blankCv({
		id: typeof r.id === "string" ? r.id : uid(),
		name: typeof r.name === "string" ? r.name : "Untitled CV",
		template,
		category: typeof r.category === "string" ? r.category : "graduate",
		updatedAt: typeof r.updatedAt === "number" ? r.updatedAt : Date.now(),
		personal: {
			...emptyPersonal(),
			...r.personal
		},
		summary: typeof r.summary === "string" ? r.summary : "",
		experience: Array.isArray(r.experience) ? r.experience : void 0,
		education: Array.isArray(r.education) ? r.education : void 0,
		projects: Array.isArray(r.projects) ? r.projects : [],
		skills: Array.isArray(r.skills) ? r.skills : void 0,
		extras: Array.isArray(r.extras) ? r.extras : [],
		referees,
		coverLetter: typeof r.coverLetter === "string" ? r.coverLetter : ""
	});
}
//#endregion
export { normalizeCv as a, blankCv as i, TEMPLATES as n, TEMPLATE_META as r, SECTIONS as t };
