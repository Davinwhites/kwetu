import { r as createServerFn } from "./ssr.mjs";
import { t as createServerRpc } from "./createServerRpc-CcvdN_gc.mjs";
import { t as authMiddleware } from "./middleware-C_SaWK1E.mjs";
import { n as consumeAi } from "./billing-vzNwqE81.mjs";
import { t as CATEGORIES } from "./categories-CugOKuXQ.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/ai-d0wMCJ20.js
function compactCv(cv) {
	return {
		name: cv.personal.fullName,
		title: cv.personal.title,
		location: cv.personal.location,
		nationality: cv.personal.nationality,
		summary: cv.summary.slice(0, 800),
		category: cv.category,
		experience: cv.experience.slice(0, 5).map((e) => ({
			id: e.id,
			role: e.role,
			company: e.company,
			dates: `${e.start}–${e.current ? "now" : e.end}`,
			bullets: e.bullets.filter(Boolean).slice(0, 6)
		})),
		education: cv.education.slice(0, 3).map((e) => ({
			school: e.school,
			degree: `${e.degree} ${e.field}`.trim()
		})),
		skills: cv.skills.map((s) => `${s.category}: ${s.items}`).slice(0, 6),
		referees: cv.referees.filter((r) => r.name).map((r) => r.name).slice(0, 3)
	};
}
async function chat(system, user, maxTokens, image) {
	const apiKey = process.env.XAI_API_KEY;
	if (!apiKey) return {
		ok: false,
		error: "AI is not available in this environment"
	};
	const userContent = image ? [{
		type: "text",
		text: user
	}, {
		type: "image_url",
		image_url: { url: image }
	}] : user;
	const res = await fetch("https://api.x.ai/v1/chat/completions", {
		method: "POST",
		headers: {
			"Content-Type": "application/json",
			Authorization: `Bearer ${apiKey}`
		},
		body: JSON.stringify({
			model: "grok-4.5",
			temperature: .4,
			max_tokens: maxTokens,
			messages: [{
				role: "system",
				content: system
			}, {
				role: "user",
				content: userContent
			}]
		})
	});
	if (!res.ok) return {
		ok: false,
		error: `AI error ${res.status}`
	};
	const text = (await res.json()).choices?.[0]?.message?.content?.trim() ?? "";
	if (!text) return {
		ok: false,
		error: "Empty model response"
	};
	return {
		ok: true,
		text
	};
}
function extractJson(text) {
	const raw = (text.match(/```(?:json)?\s*([\s\S]*?)```/)?.[1] ?? text).trim();
	const start = raw.indexOf("{");
	const end = raw.lastIndexOf("}");
	if (start < 0 || end < start) throw new Error("No JSON object");
	return JSON.parse(raw.slice(start, end + 1));
}
var UG_SYSTEM = "You write CVs for the Ugandan job market (Kampala, districts, NGOs, public service, banks, hospitals). Use UGX not USD unless the source used dollars. Prefer Makerere, Kyambogo, MUBS, UCU, Ndejje spelling. Never invent employers, dates, grades, or numbers that are not in the source. British English. No first person. No quotes around the answer.";
var runCvAi_createServerFn_handler = createServerRpc({
	id: "1be6176a60b3d029b1ed2bec0355ddf85206076a341c5c4e83928505bba3c3c7",
	name: "runCvAi",
	filename: "src/lib/ai.ts"
}, (opts) => runCvAi.__executeServer(opts));
var runCvAi = createServerFn({ method: "POST" }).validator((input) => input).middleware([authMiddleware]).handler(runCvAi_createServerFn_handler, async ({ context, data }) => {
	const gate = await consumeAi(context.userId, data.task === "scan" ? "scan" : data.task);
	if (!gate.ok) return gate;
	if (data.task === "rewrite") {
		const text = data.text.trim().slice(0, 600);
		if (!text) return {
			ok: false,
			error: "Nothing to rewrite"
		};
		const job = data.job?.trim().slice(0, 800) ?? "";
		const result = await chat(`${UG_SYSTEM} Rewrite one bullet or summary. Start with a strong action verb; quantify only using numbers already present; one or two sentences max; return only the rewritten text.`, [
			data.role ? `Role: ${data.role}` : "",
			data.company ? `Company: ${data.company}` : "",
			job ? `Target role notes: ${job}` : "",
			`Text:\n${text}`
		].filter(Boolean).join("\n"), 220);
		if (!result.ok) return result;
		return {
			ok: true,
			kind: "rewrite",
			text: result.text.replace(/^["']|["']$/g, "")
		};
	}
	if (data.task === "review") {
		const job = data.job?.trim().slice(0, 1200) ?? "";
		const result = await chat(`${UG_SYSTEM} You are a hiring manager in Uganda and an ATS coach. Return JSON only: {"score":0-100,"summary":"2 sentences","issues":[{"severity":"high|med|low","title":"short","fix":"actionable"}]} . Be specific to this CV. Max 6 issues. Flag missing referees, missing passport photo, missing nationality when the target is public service or NGO.`, JSON.stringify({
			cv: compactCv(data.cv),
			job: job || void 0
		}), 900);
		if (!result.ok) return result;
		try {
			const parsed = extractJson(result.text);
			return {
				ok: true,
				kind: "review",
				review: {
					score: Math.max(0, Math.min(100, Number(parsed.score) || 0)),
					summary: String(parsed.summary ?? "").slice(0, 600),
					issues: Array.isArray(parsed.issues) ? parsed.issues.slice(0, 6).map((i) => ({
						severity: i.severity === "high" || i.severity === "low" ? i.severity : "med",
						title: String(i.title ?? "").slice(0, 80),
						fix: String(i.fix ?? "").slice(0, 240)
					})) : []
				}
			};
		} catch {
			return {
				ok: false,
				error: "Could not parse the review"
			};
		}
	}
	if (data.task === "tailor") {
		const job = data.job.trim().slice(0, 1400);
		if (!job) return {
			ok: false,
			error: "Paste a job description first"
		};
		const result = await chat(`${UG_SYSTEM} Retarget a CV toward a job without inventing experience. Return JSON only: {"note":"1 sentence","summary":"rewritten summary","bullets":[{"id":"experience id","index":0,"suggested":"bullet"}]} . Only rewrite existing bullets (use their id and 0-based index). Max 8 bullets. Keep true facts.`, JSON.stringify({
			cv: compactCv(data.cv),
			job
		}), 1100);
		if (!result.ok) return result;
		try {
			const parsed = extractJson(result.text);
			return {
				ok: true,
				kind: "tailor",
				tailor: {
					note: String(parsed.note ?? "").slice(0, 280),
					summary: String(parsed.summary ?? "").slice(0, 700),
					bullets: Array.isArray(parsed.bullets) ? parsed.bullets.slice(0, 8).map((b) => ({
						id: String(b.id ?? ""),
						index: Number(b.index) || 0,
						suggested: String(b.suggested ?? "").slice(0, 280)
					})) : []
				}
			};
		} catch {
			return {
				ok: false,
				error: "Could not parse the tailor result"
			};
		}
	}
	if (data.task === "letter") {
		const job = data.job.trim().slice(0, 1600);
		if (!job) return {
			ok: false,
			error: "Paste the job advert first"
		};
		const result = await chat(`${UG_SYSTEM} Write a one-page cover letter for a Ugandan application. Address it to The Hiring Manager if no name is given. Structure: opening with the role, two proof paragraphs from the CV, close with availability and referees on request. No invented facts. Return only the letter text.`, JSON.stringify({
			cv: compactCv(data.cv),
			job
		}), 900);
		if (!result.ok) return result;
		return {
			ok: true,
			kind: "letter",
			text: result.text.slice(0, 4e3)
		};
	}
	if (data.task === "scan") {
		const image = data.image.trim();
		if (!image.startsWith("data:image/")) return {
			ok: false,
			error: "Upload a photo of the ID"
		};
		if (image.length > 4e5) return {
			ok: false,
			error: "That scan is too large — try a closer crop."
		};
		const result = await chat("You read Ugandan National IDs (NIRA), East African passports, and similar identity documents. Return JSON only: {\"fullName\":\"\",\"dateOfBirth\":\"\",\"nin\":\"\",\"nationality\":\"\",\"gender\":\"\",\"cardNumber\":\"\"}. Use empty strings when a field is unreadable. Never guess a NIN. If this is not an identity document, return empty strings and put a short reason in fullName prefixed with \"Not an ID: \".", "Extract the identity fields from this image.", 400, image);
		if (!result.ok) return result;
		try {
			const parsed = extractJson(result.text);
			return {
				ok: true,
				kind: "scan",
				scan: {
					fullName: String(parsed.fullName ?? "").slice(0, 80),
					dateOfBirth: String(parsed.dateOfBirth ?? "").slice(0, 40),
					nin: String(parsed.nin ?? "").slice(0, 24),
					nationality: String(parsed.nationality ?? "").slice(0, 40),
					gender: String(parsed.gender ?? "").slice(0, 24),
					cardNumber: String(parsed.cardNumber ?? "").slice(0, 32)
				}
			};
		} catch {
			return {
				ok: false,
				error: "Could not read that ID. Try a clearer photo."
			};
		}
	}
	const notes = data.notes.trim().slice(0, 4e3);
	if (notes.length < 40) return {
		ok: false,
		error: "Add more of your work history — at least a few sentences."
	};
	const cat = CATEGORIES.find((c) => c.id === data.category);
	const result = await chat(`${UG_SYSTEM} Build a structured CV from the applicant's notes. Return JSON only: {"title":"","summary":"","experience":[{"company":"","role":"","location":"","start":"","end":"","current":false,"bullets":[""]}],"education":[{"school":"","degree":"","field":"","start":"","end":"","details":""}],"skills":[{"category":"","items":""}],"extras":[{"label":"","value":""}]}. 2–4 roles, 2–4 bullets each. Do not invent employers or numbers. If a year is missing, leave it blank. Location default Kampala, Uganda when implied.`, JSON.stringify({
		notes,
		category: cat?.label ?? data.category,
		targetTitle: data.title ?? "",
		fullName: data.fullName ?? ""
	}), 1600);
	if (!result.ok) return result;
	try {
		const parsed = extractJson(result.text);
		return {
			ok: true,
			kind: "compose",
			compose: {
				title: String(parsed.title ?? data.title ?? "").slice(0, 80),
				summary: String(parsed.summary ?? "").slice(0, 800),
				experience: Array.isArray(parsed.experience) ? parsed.experience.slice(0, 6).map((e) => ({
					company: String(e.company ?? "").slice(0, 80),
					role: String(e.role ?? "").slice(0, 80),
					location: String(e.location ?? "").slice(0, 80),
					start: String(e.start ?? "").slice(0, 20),
					end: String(e.end ?? "").slice(0, 20),
					current: Boolean(e.current),
					bullets: Array.isArray(e.bullets) ? e.bullets.map((b) => String(b).slice(0, 280)).slice(0, 5) : []
				})) : [],
				education: Array.isArray(parsed.education) ? parsed.education.slice(0, 4).map((e) => ({
					school: String(e.school ?? "").slice(0, 80),
					degree: String(e.degree ?? "").slice(0, 40),
					field: String(e.field ?? "").slice(0, 80),
					start: String(e.start ?? "").slice(0, 20),
					end: String(e.end ?? "").slice(0, 20),
					details: String(e.details ?? "").slice(0, 120)
				})) : [],
				skills: Array.isArray(parsed.skills) ? parsed.skills.slice(0, 5).map((s) => ({
					category: String(s.category ?? "").slice(0, 40),
					items: String(s.items ?? "").slice(0, 240)
				})) : [],
				extras: Array.isArray(parsed.extras) ? parsed.extras.slice(0, 6).map((x) => ({
					label: String(x.label ?? "").slice(0, 40),
					value: String(x.value ?? "").slice(0, 160)
				})) : []
			}
		};
	} catch {
		return {
			ok: false,
			error: "Could not compile that draft. Try shorter notes."
		};
	}
});
//#endregion
export { runCvAi_createServerFn_handler };
