import { o as require_jsx_runtime } from "../_libs/@radix-ui/react-collection+[...].mjs";
import { i as SiteHeader, r as SiteFooter } from "./chrome-CMH7kCiq.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/privacy-Bx-u127M.js
var import_jsx_runtime = require_jsx_runtime();
function PrivacyPage() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "min-h-dvh bg-background",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SiteHeader, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
				className: "mx-auto max-w-2xl px-4 py-14 sm:px-8",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
						className: "font-display text-4xl font-medium tracking-tight",
						children: "Privacy notice"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-2 text-sm text-subtle",
						children: "For users in Uganda. Last updated September 2026."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-8 space-y-4 text-sm leading-relaxed text-muted",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "KwetuCV processes personal data to provide CV software: your name, email, account sign-in, CV contents, passport photo, optional National ID fields, and payment records. We handle this under the Data Protection and Privacy Act, 2019, as a data controller for your account." }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "We use your data to keep your account, save drafts, run AI tools you start, and record subscriptions you pay for. We do not sell CVs. We do not use a National ID image to identify you to anyone else. Scan results stay on your CV until you delete them." }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "AI requests are sent to the model provider only when you press an AI button. Do not put other people’s sensitive data into notes unless you have a lawful reason." }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "You may request access, correction, or deletion of your account data. Sign in from the same email to reach your drafts. We do not expire accounts for inactivity." }),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "This notice is information, not legal advice. If you are under 18, use KwetuCV only with a parent or guardian for lawful school or work applications." })
						]
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SiteFooter, {})
		]
	});
}
//#endregion
export { PrivacyPage as component };
