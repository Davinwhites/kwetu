import { r as createServerFn } from "./ssr.mjs";
import { r as getSql } from "./db-DzXWfmCK.mjs";
import { c as periodKey, i as entitlementsFrom } from "./plans-DdYzqCRR.mjs";
import { t as authMiddleware } from "./middleware-C_SaWK1E.mjs";
import { t as createSsrRpc } from "./createSsrRpc-B2Izd0c7.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/billing-vzNwqE81.js
async function getEntitlements(userId) {
	const sql = await getSql();
	const sub = await sql`select plan, status, period_end, finish_credits from subscriptions where user_id = ${userId}`;
	const usage = await sql`select count from ai_usage where user_id = ${userId} and period = ${periodKey()}`;
	const row = sub[0];
	return entitlementsFrom({
		plan: row?.plan ?? "free",
		status: row?.status ?? "none",
		periodEnd: row?.period_end == null ? null : Number(row.period_end),
		finishCredits: Number(row?.finish_credits ?? 0),
		aiUsed: Number(usage[0]?.count ?? 0)
	});
}
var fetchEntitlements = createServerFn({ method: "GET" }).middleware([authMiddleware]).handler(createSsrRpc("9db33cac680b62ca3e5fb41a9570cc80388392f38d4f46f762ac3f7035917496"));
var listPayments = createServerFn({ method: "GET" }).middleware([authMiddleware]).handler(createSsrRpc("63954ccf0902e0af77adf7d2d4e804fd336b7e7c451f2bbdc8b48b536ff76a1f"));
var completeCheckout = createServerFn({ method: "POST" }).validator((input) => input).middleware([authMiddleware]).handler(createSsrRpc("8bda1e852f26bea0ff867e864479d639e711437188779e533105c1aea4e2fb3e"));
async function consumeAi(userId, kind) {
	const ents = await getEntitlements(userId);
	if (!(kind === "rewrite" && ents.canRewrite || kind === "review" && ents.canReview || kind === "tailor" && ents.canTailor || kind === "compose" && ents.canCompose || kind === "scan" && ents.canScan || kind === "letter" && ents.canLetter)) return {
		ok: false,
		error: "Upgrade to use this AI tool.",
		code: "upgrade"
	};
	if (ents.aiLimit != null && ents.aiUsed >= ents.aiLimit) return {
		ok: false,
		error: "This month’s AI allowance is used. Upgrade Career Pro for unlimited.",
		code: "upgrade"
	};
	const sql = await getSql();
	const key = periodKey();
	if ((await sql`select count from ai_usage where user_id = ${userId} and period = ${key}`).length === 0) await sql`insert into ai_usage (user_id, period, count) values (${userId}, ${key}, 1)`;
	else await sql`update ai_usage set count = count + 1 where user_id = ${userId} and period = ${key}`;
	if (kind === "compose") {
		if (ents.plan !== "pro" && ents.plan !== "pro_year" && ents.finishCredits > 0) await sql`update subscriptions set finish_credits = finish_credits - 1, updated_at = ${Date.now()} where user_id = ${userId}`;
	}
	return { ok: true };
}
//#endregion
export { listPayments as a, getEntitlements as i, consumeAi as n, fetchEntitlements as r, completeCheckout as t };
